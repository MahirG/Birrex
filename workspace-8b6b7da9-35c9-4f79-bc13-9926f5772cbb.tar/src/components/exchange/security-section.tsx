"use client";

import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Shield, Lock, KeyRound, FingerprintPattern, FileCheck, AlertTriangle, CheckCircle2, type LucideIcon } from "lucide-react";
import { PAYMENT_PROVIDERS, TRUST_BADGES } from "@/lib/exchange-data";

const SECURITY_FEATURES: Array<{ icon: LucideIcon; title: string; description: string }> = [
  {
    icon: KeyRound,
    title: "RSA-256 Encryption",
    description: "All PII (TOTP secrets, bank accounts, KYC documents) encrypted at rest with hybrid RSA-OAEP-SHA256 + AES-256-GCM.",
  },
  {
    icon: FingerprintPattern,
    title: "TOTP 2FA",
    description: "Time-based one-time passwords via Google Authenticator / Authy. ±1 step window tolerates clock drift.",
  },
  {
    icon: Shield,
    title: "Double-Submit CSRF",
    description: "SameSite=Strict cookies + X-CSRF-Token header verification on every state-changing request.",
  },
  {
    icon: Lock,
    title: "ACID Escrow",
    description: "PostgreSQL SERIALIZABLE transactions with SELECT FOR UPDATE on wallets. Zero double-spend incidents.",
  },
  {
    icon: FileCheck,
    title: "NBE Compliance",
    description: "Automated daily reports at 22:00 Addis Ababa. Suspicious transaction flagging (large cash, frequent trader, rapid-fire).",
  },
  {
    icon: AlertTriangle,
    title: "Account Lockout",
    description: "5 failed logins triggers 15-minute lock. Constant-time password verification prevents timing attacks.",
  },
];

export function SecuritySection() {
  return (
    <section id="security" className="py-20 sm:py-24 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-emerald-500/5 via-transparent to-transparent" aria-hidden />
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Left — copy + trust badges */}
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full glass text-xs text-muted-foreground mb-4">
              <Shield className="w-3 h-3 text-emerald-400" />
              Bank-Grade Security
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight">
              Your funds are <span className="text-gold-gradient">safe</span> with us
            </h2>
            <p className="mt-4 text-muted-foreground leading-relaxed">
              We&rsquo;ve architected BirrEX with the same security standards used by global exchanges like Binance and Bybit,
              adapted to meet the National Bank of Ethiopia&rsquo;s regulatory requirements. Every layer of our stack — from
              the matching engine to the KYC queue — is hardened against fraud, double-spend, and tampering.
            </p>

            {/* Trust badges */}
            <div className="mt-8 flex flex-wrap gap-2">
              {TRUST_BADGES.map((badge) => (
                <Badge
                  key={badge.label}
                  variant="outline"
                  className="glass border-border/50 px-3 py-1.5 text-xs"
                >
                  <CheckCircle2 className="w-3 h-3 text-emerald-400 mr-1.5" />
                  {badge.label}
                </Badge>
              ))}
            </div>

            {/* Reserve ratio visualization */}
            <Card className="glass border-border/50 p-6 mt-8">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div className="text-sm font-semibold">Proof of Reserves</div>
                  <div className="text-xs text-muted-foreground">Audited quarterly by independent third party</div>
                </div>
                <div className="text-2xl font-bold text-emerald-400">102%</div>
              </div>
              <div className="h-3 rounded-full bg-secondary overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  whileInView={{ width: "102%" }}
                  viewport={{ once: true }}
                  transition={{ duration: 1.2, ease: "easeOut" }}
                  className="h-full bg-gradient-to-r from-emerald-500 to-emerald-400 rounded-full"
                />
              </div>
              <div className="flex justify-between text-xs text-muted-foreground mt-2">
                <span>0%</span>
                <span className="text-emerald-400 font-medium">100% (fully backed)</span>
                <span>110%</span>
              </div>
            </Card>
          </div>

          {/* Right — security features grid */}
          <div className="grid sm:grid-cols-2 gap-3">
            {SECURITY_FEATURES.map((feat, i) => (
              <motion.div
                key={feat.title}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.05 }}
              >
                <Card className="glass border-border/50 p-4 h-full hover:border-emerald-500/30 transition-colors">
                  <feat.icon className="w-5 h-5 text-emerald-400 mb-2" />
                  <div className="font-semibold text-sm mb-1">{feat.title}</div>
                  <div className="text-xs text-muted-foreground leading-relaxed">{feat.description}</div>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Payment providers */}
        <div className="mt-20">
          <div className="text-center mb-8">
            <h3 className="text-2xl sm:text-3xl font-bold">
              5 local payment methods, <span className="text-gold-gradient">one platform</span>
            </h3>
            <p className="mt-2 text-muted-foreground">Pay or get paid in ETB via your preferred Ethiopian provider.</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
            {PAYMENT_PROVIDERS.map((provider, i) => (
              <motion.div
                key={provider.name}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.3, delay: i * 0.08 }}
              >
                <Card className="glass border-border/50 p-5 text-center hover:scale-105 transition-transform h-full">
                  <div
                    className="w-12 h-12 mx-auto rounded-xl flex items-center justify-center text-white font-bold text-lg mb-3"
                    style={{ backgroundColor: provider.color }}
                  >
                    {provider.name.charAt(0)}
                  </div>
                  <div className="font-semibold text-sm">{provider.name}</div>
                  <div className="text-xs text-muted-foreground mt-0.5">{provider.description}</div>
                  <div className="text-[10px] text-emerald-400 mt-2">{provider.coverage}</div>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
