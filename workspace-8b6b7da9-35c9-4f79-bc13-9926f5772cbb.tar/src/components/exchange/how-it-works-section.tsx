"use client";

import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Zap, Shield, FileCheck, Lock, MousePointerClick, CheckCircle, type LucideIcon } from "lucide-react";
import { STEPS, FEATURE_HIGHLIGHTS } from "@/lib/exchange-data";

const ICONS: Record<string, LucideIcon> = {
  zap: Zap,
  shield: Shield,
  "file-check": FileCheck,
  lock: Lock,
  "mouse-pointer-click": MousePointerClick,
  "check-circle": CheckCircle,
};

export function HowItWorksSection() {
  return (
    <section id="how" className="py-20 sm:py-24 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full glass text-xs text-muted-foreground mb-4">
            <Zap className="w-3 h-3 text-primary" />
            Trade in 3 Simple Steps
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight">
            How <span className="text-gold-gradient">BirrEX</span> works
          </h2>
          <p className="mt-3 text-muted-foreground max-w-2xl mx-auto">
            From order placement to crypto release — typically under 30 minutes,
            fully escrow-protected end-to-end.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 relative">
          {/* Connecting line */}
          <div className="hidden md:block absolute top-16 left-[16.66%] right-[16.66%] h-0.5 bg-gradient-to-r from-primary/0 via-primary/40 to-primary/0" />

          {STEPS.map((step, i) => {
            const Icon = ICONS[step.icon] ?? MousePointerClick;
            return (
              <motion.div
                key={step.number}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.5, delay: i * 0.15 }}
              >
                <Card className="glass border-border/50 p-6 h-full hover:border-primary/40 transition-colors group">
                  <div className="relative w-14 h-14 mb-4">
                    <div className="absolute inset-0 bg-primary/10 rounded-xl rotate-6 group-hover:rotate-12 transition-transform" />
                    <div className="relative w-full h-full bg-gradient-to-br from-primary/20 to-primary/5 rounded-xl flex items-center justify-center border border-primary/20">
                      <Icon className="w-7 h-7 text-primary" />
                    </div>
                    <div className="absolute -top-2 -right-2 w-7 h-7 rounded-full bg-primary text-primary-foreground text-xs font-bold flex items-center justify-center">
                      {step.number}
                    </div>
                  </div>
                  <h3 className="text-lg font-semibold mb-2">{step.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{step.description}</p>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Features grid */}
        <div className="mt-20">
          <div className="text-center mb-10">
            <h3 className="text-2xl sm:text-3xl font-bold">
              Why traders choose <span className="text-gold-gradient">BirrEX</span>
            </h3>
            <p className="mt-2 text-muted-foreground">Built for the Ethiopian market, by Ethiopian engineers.</p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {FEATURE_HIGHLIGHTS.map((feat, i) => {
              const Icon = ICONS[feat.icon] ?? Shield;
              return (
                <motion.div
                  key={feat.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: i * 0.1 }}
                >
                  <Card className="glass border-border/50 p-5 h-full hover:border-primary/40 hover:shadow-lg hover:shadow-primary/5 transition-all">
                    <div className="flex items-start justify-between mb-3">
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                        <Icon className="w-5 h-5 text-primary" />
                      </div>
                      <div className="text-right">
                        <div className="text-lg font-bold text-gold-gradient">{feat.metric}</div>
                        <div className="text-[10px] text-muted-foreground uppercase tracking-wider">{feat.metricLabel}</div>
                      </div>
                    </div>
                    <h4 className="font-semibold mb-1">{feat.title}</h4>
                    <p className="text-xs text-muted-foreground leading-relaxed">{feat.description}</p>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
