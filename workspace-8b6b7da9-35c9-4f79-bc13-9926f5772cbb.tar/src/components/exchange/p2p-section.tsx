"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Search, Star, Clock, Shield, ChevronRight } from "lucide-react";
import { generateP2PListings, type P2PListing } from "@/lib/exchange-data";
import { cn } from "@/lib/utils";

const PAYMENT_ICONS: Record<string, { bg: string; fg: string; abbr: string }> = {
  "Telebirr": { bg: "bg-red-500/20", fg: "text-red-400", abbr: "Tb" },
  "M-PESA": { bg: "bg-emerald-500/20", fg: "text-emerald-400", abbr: "Mp" },
  "CBE Bank": { bg: "bg-blue-500/20", fg: "text-blue-400", abbr: "CB" },
  "Awash Bank": { bg: "bg-orange-500/20", fg: "text-orange-400", abbr: "Aw" },
  "Dashen Bank": { bg: "bg-teal-500/20", fg: "text-teal-400", abbr: "Ds" },
};

export function P2PSection() {
  const [mounted, setMounted] = useState(false);
  const [listings, setListings] = useState<P2PListing[]>([]);
  const [side, setSide] = useState<"BUY" | "SELL">("SELL");
  const [asset, setAsset] = useState<"USD" | "USDT">("USD");
  const [search, setSearch] = useState("");

  // Generate listings client-side only to avoid hydration mismatches.
  useEffect(() => {
    setMounted(true);
    setListings(generateP2PListings(30));
    const id = setInterval(() => {
      setListings(generateP2PListings(30));
    }, 12_000);
    return () => clearInterval(id);
  }, []);

  // When user clicks "Buy", they want to BUY → show SELL listings (advertisers selling).
  // When user clicks "Sell", they want to SELL → show BUY listings (advertisers buying).
  const targetSide = side === "BUY" ? "SELL" : "BUY";
  const filtered = listings.filter(
    (l) => l.side === targetSide && l.asset === asset &&
      (search === "" || l.advertiser.toLowerCase().includes(search.toLowerCase()))
  );

  if (!mounted) {
    return (
      <section id="p2p" className="py-20 sm:py-24 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full glass text-xs text-muted-foreground mb-4">
              <Shield className="w-3 h-3 text-primary" />
              Loading P2P market...
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight">
              Browse <span className="text-gold-gradient">P2P offers</span> from verified traders
            </h2>
          </div>
          <Card className="glass border-border/50 p-4 h-96 animate-pulse" />
        </div>
      </section>
    );
  }

  return (
    <section id="p2p" className="py-20 sm:py-24 relative">
      <div className="absolute inset-0 grid-pattern opacity-20" aria-hidden />
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full glass text-xs text-muted-foreground mb-4">
            <Shield className="w-3 h-3 text-primary" />
            Escrow-Protected P2P Market
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight">
            Browse <span className="text-gold-gradient">P2P offers</span> from verified traders
          </h2>
          <p className="mt-3 text-muted-foreground max-w-2xl mx-auto">
            Every advertiser is KYC-verified. Crypto is locked in escrow before you send a single Birr.
            Choose from 5 local payment methods.
          </p>
        </div>

        {/* Controls */}
        <Card className="glass border-border/50 p-4 mb-4">
          <div className="flex flex-col lg:flex-row gap-4 items-stretch lg:items-center justify-between">
            <div className="flex gap-2">
              <div className="inline-flex glass rounded-lg p-1">
                <button
                  onClick={() => setSide("BUY")}
                  className={cn(
                    "px-4 py-2 rounded-md text-sm font-semibold transition-colors",
                    side === "BUY" ? "bg-emerald-500 text-white" : "text-muted-foreground hover:text-foreground"
                  )}
                >
                  Buy
                </button>
                <button
                  onClick={() => setSide("SELL")}
                  className={cn(
                    "px-4 py-2 rounded-md text-sm font-semibold transition-colors",
                    side === "SELL" ? "bg-red-500 text-white" : "text-muted-foreground hover:text-foreground"
                  )}
                >
                  Sell
                </button>
              </div>
              <div className="inline-flex glass rounded-lg p-1">
                {(["USD", "USDT"] as const).map((a) => (
                  <button
                    key={a}
                    onClick={() => setAsset(a)}
                    className={cn(
                      "px-4 py-2 rounded-md text-sm font-semibold transition-colors",
                      asset === a ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
                    )}
                  >
                    {a}
                  </button>
                ))}
              </div>
            </div>

            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search advertiser..."
                className="w-full pl-10 pr-4 py-2 rounded-lg glass border border-border/50 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30"
              />
            </div>
          </div>
        </Card>

        {/* Listings table (desktop) */}
        <Card className="glass border-border/50 overflow-hidden hidden lg:block">
          <div className="grid grid-cols-12 gap-2 px-4 py-3 text-xs font-medium text-muted-foreground border-b border-border/50">
            <div className="col-span-3">Advertiser</div>
            <div className="col-span-2 text-right">Price</div>
            <div className="col-span-2 text-right">Available / Limit</div>
            <div className="col-span-3">Payment Methods</div>
            <div className="col-span-1 text-center">Trading</div>
            <div className="col-span-1 text-right">Action</div>
          </div>
          <div className="max-h-[560px] overflow-y-auto">
            {filtered.map((l, idx) => (
              <P2PRow key={l.id} listing={l} index={idx} />
            ))}
          </div>
        </Card>

        {/* Mobile cards */}
        <div className="lg:hidden space-y-3">
          {filtered.slice(0, 8).map((l, idx) => (
            <P2PMobileCard key={l.id} listing={l} index={idx} />
          ))}
        </div>

        <div className="text-center mt-6">
          <Button variant="outline" className="glass border-border/50">
            View all {filtered.length} offers
            <ChevronRight className="ml-1 w-4 h-4" />
          </Button>
        </div>
      </div>
    </section>
  );
}

function P2PRow({ listing, index }: { listing: P2PListing; index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 5 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: Math.min(index * 0.02, 0.5) }}
      className="grid grid-cols-12 gap-2 px-4 py-3 items-center hover:bg-secondary/40 border-b border-border/30 text-sm"
    >
      <div className="col-span-3">
        <div className="flex items-center gap-2">
          <div className="relative">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary/30 to-primary/10 flex items-center justify-center text-xs font-bold text-primary">
              {listing.advertiser.slice(0, 2).toUpperCase()}
            </div>
            {listing.online && (
              <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-background" />
            )}
          </div>
          <div>
            <div className="font-medium flex items-center gap-1">
              {listing.advertiser}
              <Star className="w-3 h-3 text-primary fill-primary" />
            </div>
            <div className="text-xs text-muted-foreground">
              {listing.advertiserTrades} trades · {listing.completionRate}% completion
            </div>
          </div>
        </div>
      </div>
      <div className="col-span-2 text-right">
        <div className="font-bold tabular-nums">{listing.price.toFixed(2)}</div>
        <div className="text-xs text-muted-foreground">ETB / {listing.asset}</div>
      </div>
      <div className="col-span-2 text-right">
        <div className="tabular-nums">{listing.available.toLocaleString()} {listing.asset}</div>
        <div className="text-xs text-muted-foreground">
          {listing.limitMin.toLocaleString()} - {listing.limitMax.toLocaleString()} ETB
        </div>
      </div>
      <div className="col-span-3 flex flex-wrap gap-1">
        {listing.paymentMethods.map((pm) => {
          const icon = PAYMENT_ICONS[pm];
          return (
            <span
              key={pm}
              className={cn("inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-xs", icon?.bg, icon?.fg)}
            >
              <span className="font-bold">{icon?.abbr}</span>
              {pm}
            </span>
          );
        })}
      </div>
      <div className="col-span-1 text-center">
        <div className="text-xs font-semibold text-emerald-400">{listing.completionRate}%</div>
        <div className="text-[10px] text-muted-foreground">complete</div>
      </div>
      <div className="col-span-1 text-right">
        <Button
          size="sm"
          className={cn(
            listing.side === "BUY" ? "bg-emerald-500 hover:bg-emerald-600" : "bg-red-500 hover:bg-red-600",
            "text-white"
          )}
        >
          {listing.side === "BUY" ? "Sell" : "Buy"}
        </Button>
      </div>
    </motion.div>
  );
}

function P2PMobileCard({ listing, index }: { listing: P2PListing; index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 5 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: Math.min(index * 0.03, 0.4) }}
    >
      <Card className="glass border-border/50 p-4">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <div className="relative">
              <div className="w-9 h-9 rounded-full bg-gradient-to-br from-primary/30 to-primary/10 flex items-center justify-center text-xs font-bold text-primary">
                {listing.advertiser.slice(0, 2).toUpperCase()}
              </div>
              {listing.online && (
                <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-background" />
              )}
            </div>
            <div>
              <div className="font-medium text-sm flex items-center gap-1">
                {listing.advertiser}
                <Star className="w-3 h-3 text-primary fill-primary" />
              </div>
              <div className="text-xs text-muted-foreground">{listing.advertiserTrades} trades</div>
            </div>
          </div>
          <div className="text-right">
            <div className="font-bold tabular-nums">{listing.price.toFixed(2)}</div>
            <div className="text-xs text-muted-foreground">ETB</div>
          </div>
        </div>
        <div className="flex flex-wrap gap-1 mb-3">
          {listing.paymentMethods.map((pm) => {
            const icon = PAYMENT_ICONS[pm];
            return (
              <Badge key={pm} variant="secondary" className={cn("text-xs", icon?.bg, icon?.fg)}>
                {pm}
              </Badge>
            );
          })}
        </div>
        <div className="flex items-center justify-between text-xs text-muted-foreground mb-3">
          <span>Limit: {listing.limitMin.toLocaleString()} - {listing.limitMax.toLocaleString()} ETB</span>
          <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> ~{Math.floor(Math.random() * 10) + 3} min</span>
        </div>
        <Button
          size="sm"
          className={cn(
            "w-full text-white",
            listing.side === "BUY" ? "bg-emerald-500 hover:bg-emerald-600" : "bg-red-500 hover:bg-red-600"
          )}
        >
          {listing.side === "BUY" ? "Sell" : "Buy"} {listing.asset}
        </Button>
      </Card>
    </motion.div>
  );
}
