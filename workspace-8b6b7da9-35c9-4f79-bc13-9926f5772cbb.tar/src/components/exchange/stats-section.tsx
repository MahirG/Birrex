"use client";

import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Activity, Users, TrendingUp, Clock, Globe, Award } from "lucide-react";
import { PLATFORM_STATS } from "@/lib/exchange-data";

const LIVE_STATS = [
  { icon: Users, label: "Active Traders", value: PLATFORM_STATS.totalUsers, color: "text-primary" },
  { icon: TrendingUp, label: "24h Volume", value: "ETB 84.7M", color: "text-emerald-400" },
  { icon: Activity, label: "Trades / 24h", value: "3,482", color: "text-blue-400" },
  { icon: Clock, label: "Avg Settlement", value: `${PLATFORM_STATS.avgSettlementMinutes} min`, color: "text-orange-400" },
  { icon: Globe, label: "Countries", value: PLATFORM_STATS.countriesServed, color: "text-purple-400" },
  { icon: Award, label: "Dispute Resolution", value: `${PLATFORM_STATS.disputeResolutionHours}h avg`, color: "text-pink-400" },
];

export function StatsSection() {
  return (
    <section id="about" className="py-16 sm:py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Card className="glass border-border/50 p-6 sm:p-8">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 sm:gap-6">
            {LIVE_STATS.map((stat, i) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.06 }}
                className="text-center"
              >
                <stat.icon className={`w-6 h-6 mx-auto mb-2 ${stat.color}`} />
                <div className="text-xl sm:text-2xl font-bold tabular-nums">{stat.value}</div>
                <div className="text-[10px] sm:text-xs text-muted-foreground mt-1 uppercase tracking-wider">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </Card>
      </div>
    </section>
  );
}
