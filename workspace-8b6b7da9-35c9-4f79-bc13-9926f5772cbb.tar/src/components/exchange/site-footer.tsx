"use client";

import Link from "next/link";
import { Bitcoin, Send, AtSign, MessageCircle, Globe, MapPin } from "lucide-react";

const FOOTER_LINKS: Record<string, Array<{ label: string; href: string }>> = {
  Trade: [
    { label: "Spot Trading", href: "#trade" },
    { label: "P2P Market", href: "#p2p" },
    { label: "Order Book", href: "#trade" },
    { label: "Price Chart", href: "#trade" },
  ],
  Company: [
    { label: "About Us", href: "#about" },
    { label: "Careers", href: "#" },
    { label: "Press Kit", href: "#" },
    { label: "Blog", href: "#" },
  ],
  Resources: [
    { label: "How It Works", href: "#how" },
    { label: "Fee Schedule", href: "#" },
    { label: "API Documentation", href: "#" },
    { label: "Trading Guide", href: "#" },
  ],
  Support: [
    { label: "Help Center", href: "#" },
    { label: "Dispute Resolution", href: "#" },
    { label: "Contact Us", href: "#" },
    { label: "Report a Bug", href: "#" },
  ],
  Legal: [
    { label: "Terms of Service", href: "#" },
    { label: "Privacy Policy", href: "#" },
    { label: "Cookie Policy", href: "#" },
    { label: "NBE Compliance", href: "#security" },
  ],
};

export function SiteFooter() {
  return (
    <footer className="mt-auto border-t border-border/50 bg-card/30 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid lg:grid-cols-12 gap-8">
          {/* Brand column */}
          <div className="lg:col-span-3">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center">
                <Bitcoin className="w-5 h-5 text-primary-foreground" />
              </div>
              <div className="flex flex-col leading-none">
                <span className="text-lg font-bold tracking-tight">BirrEX</span>
                <span className="text-[10px] text-muted-foreground">Ethiopia&rsquo;s #1 P2P Exchange</span>
              </div>
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed mb-4 max-w-xs">
              BirrEX is Ethiopia&rsquo;s first ACID-compliant P2P crypto/fiat exchange.
              Trade USD and USDT against the Ethiopian Birr with Telebirr-grade settlement speed.
            </p>
            <div className="flex items-center gap-2 mb-4">
              <SocialIcon icon={Send} />
              <SocialIcon icon={MessageCircle} />
              <SocialIcon icon={Globe} />
              <SocialIcon icon={AtSign} />
            </div>
            <div className="text-xs text-muted-foreground flex items-start gap-1.5">
              <MapPin className="w-3 h-3 mt-0.5 flex-shrink-0" />
              <span>
                Bole Road, Addis Ababa
                <br />
                Ethiopia · East Africa
              </span>
            </div>
          </div>

          {/* Link columns */}
          <div className="lg:col-span-9 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-6">
            {Object.entries(FOOTER_LINKS).map(([heading, links]) => (
              <div key={heading}>
                <h4 className="text-xs font-semibold text-foreground uppercase tracking-wider mb-3">{heading}</h4>
                <ul className="space-y-2">
                  {links.map((link) => (
                    <li key={link.label}>
                      <Link
                        href={link.href}
                        className="text-xs text-muted-foreground hover:text-primary transition-colors"
                      >
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* Compliance + risk warning */}
        <div className="mt-10 pt-6 border-t border-border/50 space-y-3">
          <div className="rounded-lg glass p-4">
            <p className="text-[11px] text-muted-foreground leading-relaxed">
              <strong className="text-foreground">Risk Warning:</strong> Trading cryptocurrencies
              involves significant risk and can result in the loss of your invested capital.
              You should not invest more than you can afford to lose. Past performance is not
              indicative of future results. Before trading, please ensure you fully understand
              the risks involved and seek independent advice if necessary.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-muted-foreground">
            <div>© {new Date().getFullYear()} BirrEX Technologies PLC. All rights reserved.</div>
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 pulse-glow" />
                All systems operational
              </span>
              <span>v3.0.0</span>
            </div>
          </div>
          <div className="text-[10px] text-muted-foreground text-center">
            BirrEX is registered with the National Bank of Ethiopia (NBE) as a Forex Bureau
            (License No. NBE-FB-2026-0142). Operations are conducted in compliance with
            NBE Directive No. ONR-FX/01/2023.
          </div>
        </div>
      </div>
    </footer>
  );
}

function SocialIcon({ icon: Icon }: { icon: React.ComponentType<{ className?: string }> }) {
  return (
    <a
      href="#"
      className="w-8 h-8 rounded-lg glass border-border/50 flex items-center justify-center text-muted-foreground hover:text-primary hover:border-primary/40 transition-colors"
    >
      <Icon className="w-4 h-4" />
    </a>
  );
}
