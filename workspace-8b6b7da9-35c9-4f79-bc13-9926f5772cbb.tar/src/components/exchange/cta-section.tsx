"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { ArrowRight, Sparkles } from "lucide-react";

export function CtaSection() {
  return (
    <section id="register" className="py-20 sm:py-24 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="relative gradient-border rounded-3xl p-8 sm:p-12 lg:p-16 text-center overflow-hidden"
        >
          {/* Background glow */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-primary/20 rounded-full blur-[120px] pointer-events-none" aria-hidden />

          <div className="relative">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full glass text-xs text-muted-foreground mb-6">
              <Sparkles className="w-3 h-3 text-primary" />
              Join 184,520+ Ethiopian traders
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight max-w-3xl mx-auto leading-tight">
              Start trading <span className="text-gold-gradient">USD ⇄ ETB</span> in 5 minutes
            </h2>
            <p className="mt-4 text-muted-foreground max-w-xl mx-auto">
              Sign up, complete KYC with your Ethiopian ID or passport, deposit Birr via Telebirr — and place your first trade today.
              Zero maker fees. 0.5% taker fee. No hidden costs.
            </p>

            <div className="mt-8 flex flex-col sm:flex-row gap-3 justify-center">
              <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 shadow-xl shadow-primary/25 group" asChild>
                <Link href="#register">
                  Create Free Account
                  <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="glass border-border/50" asChild>
                <Link href="#how">Learn How It Works</Link>
              </Button>
            </div>

            <div className="mt-8 flex flex-wrap justify-center gap-x-6 gap-y-2 text-xs text-muted-foreground">
              <span>✓ No deposit fees</span>
              <span>✓ 30-min payment window</span>
              <span>✓ 24/7 dispute resolution</span>
              <span>✓ Amharic + English support</span>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
