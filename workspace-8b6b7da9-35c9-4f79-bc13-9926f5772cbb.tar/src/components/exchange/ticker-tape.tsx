"use client";

import { TrendingUp, TrendingDown } from "lucide-react";

// Static market data — no client-side state to avoid hydration issues.
const MARKETS: Array<{ pair: string; price: number; change: number }> = [
  { pair: "BTC/USD", price: 67_842.50, change: 2.34 },
  { pair: "ETH/USD", price: 3_521.80, change: 1.45 },
  { pair: "USD/ETB", price: 128.45, change: 1.34 },
  { pair: "USDT/ETB", price: 128.12, change: 0.92 },
  { pair: "BNB/USD", price: 612.30, change: -0.85 },
  { pair: "SOL/USD", price: 178.42, change: 3.21 },
  { pair: "XAU/USD", price: 2_345.60, change: 0.45 },
  { pair: "EUR/USD", price: 1.0842, change: -0.12 },
  { pair: "GBP/USD", price: 1.2710, change: 0.18 },
];

function formatPrice(price: number): string {
  if (price < 10) return price.toFixed(4);
  return price.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export function TickerTape() {
  // Duplicate the list so the marquee can loop seamlessly.
  const looped = [...MARKETS, ...MARKETS];

  return (
    <div className="relative border-y border-border/50 bg-card/50 overflow-hidden py-2.5">
      <div className="flex animate-ticker whitespace-nowrap">
        {looped.map((t, i) => {
          const isUp = t.change >= 0;
          return (
            <div
              key={`${t.pair}-${i}`}
              className="inline-flex items-center gap-2 px-6 text-sm"
            >
              <span className="text-muted-foreground font-medium">{t.pair}</span>
              <span className="tabular-nums font-semibold">{formatPrice(t.price)}</span>
              <span
                className={`inline-flex items-center text-xs font-semibold tabular-nums ${
                  isUp ? "text-emerald-400" : "text-red-400"
                }`}
              >
                {isUp ? <TrendingUp className="w-3 h-3 mr-0.5" /> : <TrendingDown className="w-3 h-3 mr-0.5" />}
                {isUp ? "+" : ""}{t.change.toFixed(2)}%
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
