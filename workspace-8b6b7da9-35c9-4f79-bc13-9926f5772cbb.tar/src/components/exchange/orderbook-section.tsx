"use client";

import { useEffect, useState, useMemo } from "react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger } from "@radix-ui/react-tabs";
import { generateOrderbook, generateCandles, type OrderbookSnapshot, type Candle, type TradingPair } from "@/lib/exchange-data";
import { cn } from "@/lib/utils";

export function OrderbookSection() {
  const [pair, setPair] = useState<TradingPair>("USD_ETB");
  // Don't generate random data during SSR — wait until mounted on the client
  // to avoid hydration mismatches.
  const [mounted, setMounted] = useState(false);
  const [book, setBook] = useState<OrderbookSnapshot | null>(null);
  const [candles, setCandles] = useState<Candle[]>([]);
  const [tick, setTick] = useState(0);

  // Generate initial book + candles once mounted.
  useEffect(() => {
    setMounted(true);
    setBook(generateOrderbook(pair));
    setCandles(generateCandles(pair));
    const id = setInterval(() => {
      setBook(generateOrderbook(pair));
      setTick((t) => t + 1);
    }, 1800);
    return () => clearInterval(id);
  }, [pair]);

  if (!mounted || !book) {
    return (
      <section id="trade" className="py-20 sm:py-24 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full glass text-xs text-muted-foreground mb-4">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
              </span>
              Loading live order book...
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight">
              Trade on a <span className="text-gold-gradient">real-time</span> order book
            </h2>
          </div>
          <div className="grid lg:grid-cols-3 gap-4">
            <Card className="lg:col-span-2 glass border-border/50 p-4 h-96 animate-pulse" />
            <Card className="glass border-border/50 p-4 h-96 animate-pulse" />
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="trade" className="py-20 sm:py-24 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full glass text-xs text-muted-foreground mb-4">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
            </span>
            Live Order Book
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight">
            Trade on a <span className="text-gold-gradient">real-time</span> order book
          </h2>
          <p className="mt-3 text-muted-foreground max-w-2xl mx-auto">
            Price-time priority matching. Sub-50ms updates. Per-pair distributed locks
            keep your orders safe even under heavy load.
          </p>
        </div>

        {/* Pair selector */}
        <div className="flex justify-center mb-6">
          <Tabs value={pair} onValueChange={(v) => setPair(v as TradingPair)}>
            <TabsList className="glass rounded-lg p-1 inline-flex gap-1">
              <TabsTrigger
                value="USD_ETB"
                className={cn(
                  "px-4 py-2 rounded-md text-sm font-medium transition-colors",
                  pair === "USD_ETB" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
                )}
              >
                USD / ETB
              </TabsTrigger>
              <TabsTrigger
                value="USDT_ETB"
                className={cn(
                  "px-4 py-2 rounded-md text-sm font-medium transition-colors",
                  pair === "USDT_ETB" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
                )}
              >
                USDT / ETB
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        <div className="grid lg:grid-cols-3 gap-4">
          {/* Chart spans 2 cols */}
          <Card className="lg:col-span-2 glass border-border/50 p-4 overflow-hidden">
            <div className="flex items-center justify-between mb-3">
              <div>
                <div className="text-sm text-muted-foreground">Price Chart · 1H</div>
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl font-bold tabular-nums">
                    {book.asks[0]!.price.toFixed(2)}
                  </span>
                  <span className="text-xs text-emerald-400">ETB</span>
                </div>
              </div>
              <div className="flex gap-1 text-xs">
                {["1H", "4H", "1D", "1W"].map((tf, i) => (
                  <button
                    key={tf}
                    className={cn(
                      "px-2 py-1 rounded font-medium",
                      i === 0 ? "bg-primary/20 text-primary" : "text-muted-foreground hover:text-foreground"
                    )}
                  >
                    {tf}
                  </button>
                ))}
              </div>
            </div>
            <CandleChart candles={candles} />
          </Card>

          {/* Order book */}
          <Card className="glass border-border/50 p-4 overflow-hidden">
            <div className="flex items-center justify-between mb-3">
              <div className="text-sm font-semibold">Order Book</div>
              <div className="text-xs text-muted-foreground">Depth · 14 levels</div>
            </div>
            <OrderbookTable book={book} />
          </Card>
        </div>

        {/* Recent trades + pair stats */}
        <div className="grid lg:grid-cols-3 gap-4 mt-4">
          <Card className="lg:col-span-2 glass border-border/50 p-4">
            <RecentTrades pair={pair} tick={tick} />
          </Card>
          <Card className="glass border-border/50 p-4">
            <MarketStats pair={pair} book={book} />
          </Card>
        </div>
      </div>
    </section>
  );
}

// ---------------------------------------------------------------------------
// Candle chart (custom SVG, no chart library dependency)
// ---------------------------------------------------------------------------

function CandleChart({ candles }: { candles: Candle[] }) {
  const { paths, highs, lows, wicks } = useMemo(() => {
    const width = 800;
    const height = 280;
    const padding = { top: 10, right: 10, bottom: 20, left: 10 };
    const chartW = width - padding.left - padding.right;
    const chartH = height - padding.top - padding.bottom;

    const allHighs = candles.map((c) => c.high);
    const allLows = candles.map((c) => c.low);
    const max = Math.max(...allHighs);
    const min = Math.min(...allLows);
    const range = max - min || 1;

    const candleWidth = chartW / candles.length;
    const bodyWidth = candleWidth * 0.6;

    const wicks: string[] = [];
    const upBodies: string[] = [];
    const downBodies: string[] = [];

    candles.forEach((c, i) => {
      const x = padding.left + i * candleWidth + candleWidth / 2;
      const yHigh = padding.top + ((max - c.high) / range) * chartH;
      const yLow = padding.top + ((max - c.low) / range) * chartH;
      const yOpen = padding.top + ((max - c.open) / range) * chartH;
      const yClose = padding.top + ((max - c.close) / range) * chartH;

      wicks.push(`M${x},${yHigh} L${x},${yLow}`);
      const bodyTop = Math.min(yOpen, yClose);
      const bodyH = Math.max(Math.abs(yClose - yOpen), 1);
      const bodyX = x - bodyWidth / 2;
      const isUp = c.close >= c.open;
      const rect = `M${bodyX},${bodyTop} L${bodyX + bodyWidth},${bodyTop} L${bodyX + bodyWidth},${bodyTop + bodyH} L${bodyX},${bodyTop + bodyH} Z`;
      if (isUp) upBodies.push(rect);
      else downBodies.push(rect);
    });

    return {
      paths: { up: upBodies.join(" "), down: downBodies.join(" ") },
      highs: max,
      lows: min,
      wicks: wicks.join(" "),
    };
  }, [candles]);

  return (
    <svg viewBox="0 0 800 280" className="w-full h-64" preserveAspectRatio="none">
      <defs>
        <linearGradient id="upGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="rgb(16, 185, 129)" />
          <stop offset="100%" stopColor="rgb(5, 150, 105)" />
        </linearGradient>
        <linearGradient id="downGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="rgb(239, 68, 68)" />
          <stop offset="100%" stopColor="rgb(220, 38, 38)" />
        </linearGradient>
      </defs>
      {/* Horizontal grid lines */}
      {[0, 0.25, 0.5, 0.75, 1].map((p) => (
        <line
          key={p}
          x1="0"
          y1={10 + p * 250}
          x2="800"
          y2={10 + p * 250}
          stroke="rgba(255,255,255,0.05)"
          strokeWidth="1"
        />
      ))}
      {/* Wicks */}
      <path d={wicks} stroke="rgba(255,255,255,0.4)" strokeWidth="1" fill="none" />
      {/* Up candles */}
      <path d={paths.up} fill="url(#upGrad)" />
      {/* Down candles */}
      <path d={paths.down} fill="url(#downGrad)" />
      {/* Price labels */}
      <text x="790" y="15" fill="rgba(255,255,255,0.4)" fontSize="10" textAnchor="end">
        {highs.toFixed(2)}
      </text>
      <text x="790" y="270" fill="rgba(255,255,255,0.4)" fontSize="10" textAnchor="end">
        {lows.toFixed(2)}
      </text>
    </svg>
  );
}

// ---------------------------------------------------------------------------
// Order book table
// ---------------------------------------------------------------------------

function OrderbookTable({ book }: { book: OrderbookSnapshot }) {
  const maxTotal = Math.max(
    ...book.bids.map((b) => b.total),
    ...book.asks.map((a) => a.total)
  );

  return (
    <div className="text-xs">
      <div className="grid grid-cols-3 gap-1 px-1 pb-2 text-muted-foreground font-medium border-b border-border/50">
        <div>Price (ETB)</div>
        <div className="text-right">Amount</div>
        <div className="text-right">Total</div>
      </div>
      {/* Asks (reversed so lowest ask is at bottom, near the spread) */}
      <div className="max-h-48 overflow-y-auto scrollbar-hide">
        {[...book.asks].reverse().map((ask, i) => (
          <OrderbookRow key={`ask-${i}`} level={ask} side="ask" maxTotal={maxTotal} />
        ))}
      </div>
      {/* Spread */}
      <div className="my-2 py-2 px-1 flex items-center justify-between border-y border-border/50">
        <span className="text-sm font-bold text-primary tabular-nums">
          {book.asks[0]!.price.toFixed(2)}
        </span>
        <span className="text-[10px] text-muted-foreground">
          Spread {(book.spreadPercent * 100).toFixed(2)} bps
        </span>
      </div>
      {/* Bids */}
      <div className="max-h-48 overflow-y-auto scrollbar-hide">
        {book.bids.map((bid, i) => (
          <OrderbookRow key={`bid-${i}`} level={bid} side="bid" maxTotal={maxTotal} />
        ))}
      </div>
    </div>
  );
}

function OrderbookRow({
  level,
  side,
  maxTotal,
}: {
  level: { price: number; quantity: number; total: number };
  side: "bid" | "ask";
  maxTotal: number;
}) {
  const fillPercent = (level.total / maxTotal) * 100;
  return (
    <motion.div
      layout
      className="relative grid grid-cols-3 gap-1 px-1 py-0.5 tabular-nums hover:bg-secondary/40"
    >
      <div
        className={`absolute inset-y-0 right-0 ${side === "bid" ? "bg-emerald-500/10" : "bg-red-500/10"}`}
        style={{ width: `${fillPercent}%` }}
      />
      <div className={`relative ${side === "bid" ? "text-emerald-400" : "text-red-400"}`}>
        {level.price.toFixed(2)}
      </div>
      <div className="relative text-right">{level.quantity.toFixed(2)}</div>
      <div className="relative text-right text-muted-foreground">{level.total.toFixed(0)}</div>
    </motion.div>
  );
}

// ---------------------------------------------------------------------------
// Recent trades
// ---------------------------------------------------------------------------

function RecentTrades({ pair, tick }: { pair: TradingPair; tick: number }) {
  const [trades, setTrades] = useState<Array<{ id: string; price: number; qty: number; side: "BUY" | "SELL"; time: string }>>([]);

  useEffect(() => {
    // Generate a fresh batch of trades every tick.
    const newTrades = Array.from({ length: 8 }, (_, i) => {
      const basePrice = pair === "USD_ETB" ? 128.45 : 128.12;
      return {
        id: `${tick}-${i}-${Math.random()}`,
        price: basePrice + (Math.random() - 0.5) * 0.5,
        qty: Math.random() * 500,
        side: Math.random() > 0.5 ? ("BUY" as const) : ("SELL" as const),
        time: new Date().toLocaleTimeString("en-US", { hour12: false }),
      };
    });
    setTrades(newTrades);
  }, [tick, pair]);

  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <div className="text-sm font-semibold">Recent Trades</div>
        <div className="text-xs text-muted-foreground">{pair.replace("_", " / ")}</div>
      </div>
      <div className="grid grid-cols-4 gap-1 px-1 pb-2 text-xs text-muted-foreground font-medium border-b border-border/50">
        <div>Price</div>
        <div className="text-right">Amount</div>
        <div className="text-right">Side</div>
        <div className="text-right">Time</div>
      </div>
      <div className="max-h-64 overflow-y-auto">
        {trades.map((t) => (
          <motion.div
            key={t.id}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            className="grid grid-cols-4 gap-1 px-1 py-1 text-xs tabular-nums hover:bg-secondary/40"
          >
            <div className={t.side === "BUY" ? "text-emerald-400" : "text-red-400"}>
              {t.price.toFixed(2)}
            </div>
            <div className="text-right">{t.qty.toFixed(2)}</div>
            <div className={`text-right ${t.side === "BUY" ? "text-emerald-400" : "text-red-400"}`}>
              {t.side}
            </div>
            <div className="text-right text-muted-foreground">{t.time}</div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Market stats sidebar
// ---------------------------------------------------------------------------

function MarketStats({ pair, book }: { pair: TradingPair; book: OrderbookSnapshot }) {
  const stats = [
    { label: "24h High", value: "129.20" },
    { label: "24h Low", value: "126.80" },
    { label: "24h Volume (USD)", value: "248,540" },
    { label: "24h Volume (ETB)", value: "31.89M" },
    { label: "Best Bid", value: book.bids[0]!.price.toFixed(2) },
    { label: "Best Ask", value: book.asks[0]!.price.toFixed(2) },
    { label: "Spread (bps)", value: (book.spreadPercent * 100).toFixed(2) },
    { label: "Last Update", value: new Date(book.timestamp).toLocaleTimeString("en-US", { hour12: false }) },
  ];
  return (
    <div>
      <div className="text-sm font-semibold mb-3">Market Stats</div>
      <div className="space-y-2">
        {stats.map((s) => (
          <div key={s.label} className="flex items-center justify-between text-xs">
            <span className="text-muted-foreground">{s.label}</span>
            <span className="font-medium tabular-nums">{s.value}</span>
          </div>
        ))}
      </div>
      <div className="mt-4 pt-4 border-t border-border/50">
        <div className="text-xs text-muted-foreground mb-2">Reserve Ratio</div>
        <div className="flex items-center gap-2">
          <div className="flex-1 h-2 rounded-full bg-secondary overflow-hidden">
            <div className="h-full bg-emerald-500 rounded-full" style={{ width: "102%" }} />
          </div>
          <span className="text-xs font-semibold text-emerald-400">102%</span>
        </div>
        <div className="text-[10px] text-muted-foreground mt-1">
          Fully-backed 1:1 reserve, audited quarterly
        </div>
      </div>
    </div>
  );
}
