"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { ArrowRight, Shield, Zap, TrendingUp, PlayCircle } from "lucide-react";
import { PLATFORM_STATS } from "@/lib/exchange-data";

export function HeroSection() {
  return (
    <section className="relative pt-32 pb-16 sm:pt-40 sm:pb-24 overflow-hidden">
      {/* Animated background grid */}
      <div className="absolute inset-0 grid-pattern opacity-40" aria-hidden />
      {/* Gold radial glow */}
      <div className="absolute top-1/3 -left-32 w-96 h-96 bg-primary/20 rounded-full blur-[120px] pointer-events-none" aria-hidden />
      <div className="absolute top-1/2 -right-32 w-96 h-96 bg-emerald-500/10 rounded-full blur-[120px] pointer-events-none" aria-hidden />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left — copy */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center lg:text-left"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.1 }}
              className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass text-xs font-medium text-muted-foreground mb-6"
            >
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
              </span>
              Live · 184,520 traders online
            </motion.div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight leading-[1.05]">
              Trade <span className="text-gold-gradient">USD ⇄ ETB</span>
              <br />
              with Telebirr speed
            </h1>

            <p className="mt-6 text-lg text-muted-foreground max-w-xl mx-auto lg:mx-0">
              Ethiopia&rsquo;s most trusted P2P crypto exchange. Instant escrow,
              30-minute payment windows, and bank-grade security on every trade.
            </p>

            <div className="mt-8 flex flex-col sm:flex-row gap-3 justify-center lg:justify-start">
              <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 shadow-xl shadow-primary/25 group" asChild>
                <Link href="#register">
                  Start Trading
                  <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="glass border-border/50 hover:bg-secondary/80" asChild>
                <Link href="#demo">
                  <PlayCircle className="mr-2 w-5 h-5" />
                  Watch Demo
                </Link>
              </Button>
            </div>

            {/* Trust badges row */}
            <div className="mt-10 grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-2xl mx-auto lg:mx-0">
              {[
                { icon: Shield, label: "ACID Escrow" },
                { icon: Zap, label: "30-min Window" },
                { icon: TrendingUp, label: "0% Maker Fee" },
                { icon: Shield, label: "NBE Compliant" },
              ].map(({ icon: Icon, label }) => (
                <div key={label} className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Icon className="w-4 h-4 text-primary" />
                  {label}
                </div>
              ))}
            </div>
          </motion.div>

          {/* Right — live ticker card */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative"
          >
            <LiveTickerCard />
          </motion.div>
        </div>

        {/* Stats bar */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mt-16 grid grid-cols-2 sm:grid-cols-4 gap-4"
        >
          {[
            { label: "Total Volume", value: PLATFORM_STATS.totalVolume },
            { label: "Active Traders", value: PLATFORM_STATS.totalUsers },
            { label: "Trades Settled", value: PLATFORM_STATS.totalTrades },
            { label: "Platform Uptime", value: PLATFORM_STATS.uptimePercent },
          ].map((stat) => (
            <div
              key={stat.label}
              className="glass rounded-xl p-4 text-center sm:text-left transition-transform hover:scale-105"
            >
              <div className="text-2xl font-bold text-gold-gradient">{stat.value}</div>
              <div className="text-xs text-muted-foreground mt-1">{stat.label}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

function LiveTickerCard() {
  return (
    <div className="gradient-border rounded-2xl p-6 shadow-2xl shadow-black/40">
      <div className="flex items-center justify-between mb-4">
        <div>
          <div className="text-xs text-muted-foreground">USD / ETB</div>
          <div className="text-3xl font-bold tabular-nums">
            128.<span className="text-primary">45</span>
          </div>
        </div>
        <div className="text-right">
          <div className="inline-flex items-center px-2 py-1 rounded-md bg-emerald-500/15 text-emerald-400 text-xs font-semibold">
            <TrendingUp className="w-3 h-3 mr-1" />
            +1.34%
          </div>
          <div className="text-[10px] text-muted-foreground mt-1">24h change</div>
        </div>
      </div>

      {/* Mini sparkline */}
      <div className="h-24 mb-4 relative">
        <svg viewBox="0 0 300 100" className="w-full h-full" preserveAspectRatio="none">
          <defs>
            <linearGradient id="sparkGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="rgb(245, 158, 11)" stopOpacity="0.4" />
              <stop offset="100%" stopColor="rgb(245, 158, 11)" stopOpacity="0" />
            </linearGradient>
          </defs>
          <path
            d="M0,60 L20,55 L40,62 L60,48 L80,52 L100,40 L120,45 L140,35 L160,38 L180,28 L200,32 L220,22 L240,25 L260,18 L280,22 L300,12"
            fill="none"
            stroke="rgb(245, 158, 11)"
            strokeWidth="2"
            vectorEffect="non-scaling-stroke"
          />
          <path
            d="M0,60 L20,55 L40,62 L60,48 L80,52 L100,40 L120,45 L140,35 L160,38 L180,28 L200,32 L220,22 L240,25 L260,18 L280,22 L300,12 L300,100 L0,100 Z"
            fill="url(#sparkGrad)"
          />
        </svg>
      </div>

      <div className="grid grid-cols-3 gap-3 text-xs">
        <div className="glass rounded-lg p-2">
          <div className="text-muted-foreground">24h High</div>
          <div className="font-semibold tabular-nums">129.20</div>
        </div>
        <div className="glass rounded-lg p-2">
          <div className="text-muted-foreground">24h Low</div>
          <div className="font-semibold tabular-nums">126.80</div>
        </div>
        <div className="glass rounded-lg p-2">
          <div className="text-muted-foreground">Volume</div>
          <div className="font-semibold tabular-nums">248K</div>
        </div>
      </div>

      <div className="mt-4 flex gap-2">
        <button className="flex-1 py-2 rounded-lg bg-emerald-500/15 text-emerald-400 text-sm font-semibold hover:bg-emerald-500/25 transition-colors">
          Buy USD
        </button>
        <button className="flex-1 py-2 rounded-lg bg-red-500/15 text-red-400 text-sm font-semibold hover:bg-red-500/25 transition-colors">
          Sell USD
        </button>
      </div>
    </div>
  );
}
