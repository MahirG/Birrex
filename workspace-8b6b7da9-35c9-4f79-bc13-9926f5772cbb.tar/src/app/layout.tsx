import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "BirrEX — Ethiopia's #1 P2P Crypto Exchange | USD ⇄ ETB",
  description:
    "Trade USD and USDT against Ethiopian Birr with instant Telebirr, M-PESA, and bank settlements. ACID-compliant escrow, 30-min payment windows, and NBE-compliant reporting.",
  keywords: [
    "Ethiopian crypto exchange",
    "ETB USD exchange",
    "Telebirr crypto",
    "P2P crypto Ethiopia",
    "BirrEX",
    "Addis Ababa Bitcoin",
  ],
  authors: [{ name: "BirrEX Team" }],
  openGraph: {
    title: "BirrEX — Ethiopia's #1 P2P Crypto Exchange",
    description:
      "Trade USD ⇄ ETB with instant Telebirr settlement. Bank-grade security, NBE-compliant.",
    siteName: "BirrEX",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "BirrEX — Ethiopia's #1 P2P Crypto Exchange",
    description: "Trade USD ⇄ ETB with instant Telebirr settlement.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground min-h-screen`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
