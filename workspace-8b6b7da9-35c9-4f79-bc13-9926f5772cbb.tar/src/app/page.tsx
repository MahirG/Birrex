import { SiteHeader } from "@/components/exchange/site-header";
import { TickerTape } from "@/components/exchange/ticker-tape";
import { HeroSection } from "@/components/exchange/hero-section";
import { StatsSection } from "@/components/exchange/stats-section";
import { OrderbookSection } from "@/components/exchange/orderbook-section";
import { P2PSection } from "@/components/exchange/p2p-section";
import { HowItWorksSection } from "@/components/exchange/how-it-works-section";
import { SecuritySection } from "@/components/exchange/security-section";
import { CtaSection } from "@/components/exchange/cta-section";
import { SiteFooter } from "@/components/exchange/site-footer";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <SiteHeader />
      <main className="flex-1">
        <HeroSection />
        <TickerTape />
        <StatsSection />
        <OrderbookSection />
        <P2PSection />
        <HowItWorksSection />
        <SecuritySection />
        <CtaSection />
      </main>
      <SiteFooter />
    </div>
  );
}
