/**
 * BirrEX — Exchange data layer.
 *
 * In production this would be replaced by WebSocket subscriptions to the
 * NestJS backend (Socket.io namespace /exchange). For this demo we ship
 * a realistic mock that simulates live price ticks + order book updates.
 */

export type TradingPair = "USD_ETB" | "USDT_ETB";

export interface Ticker {
  pair: TradingPair;
  lastPrice: number;
  change24h: number; // percentage
  high24h: number;
  low24h: number;
  volume24h: number; // in base currency
  volumeQuote24h: number; // in ETB
}

export interface OrderbookLevel {
  price: number;
  quantity: number;
  total: number; // cumulative
}

export interface OrderbookSnapshot {
  pair: TradingPair;
  bids: OrderbookLevel[]; // sorted desc by price
  asks: OrderbookLevel[]; // sorted asc by price
  spread: number;
  spreadPercent: number;
  timestamp: number;
}

export interface TradeTick {
  id: string;
  pair: TradingPair;
  price: number;
  quantity: number;
  side: "BUY" | "SELL";
  timestamp: number;
}

export interface P2PListing {
  id: string;
  advertiser: string;
  advertiserTrades: number;
  advertiserRating: number; // 0-100
  side: "BUY" | "SELL";
  asset: "USD" | "USDT";
  fiat: "ETB";
  price: number;
  available: number;
  limitMin: number;
  limitMax: number;
  paymentMethods: string[]; // Telebirr, M-PESA, CBE, Awash, Dashen
  completionRate: number; // 0-100
  online: boolean;
}

export interface Candle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

// ---------------------------------------------------------------------------
// Seed data
// ---------------------------------------------------------------------------

const PAYMENT_METHODS = ["Telebirr", "M-PESA", "CBE Bank", "Awash Bank", "Dashen Bank"] as const;
const ADVERTISER_NAMES = [
  "AddisTrader", "LionCapital", "HornOfAfricaFX", "ShebaExchange", "BlueNileCrypto",
  "LucyTrading", "AwashCrypto", "TanaDeFi", "RiftValleyFX", "SolomonicExchange",
  "QueenOfSheba", "EthioGold", "BoleCapital", "PioneerFX", "MercatoTrades",
];

function rand(min: number, max: number): number {
  return Math.random() * (max - min) + min;
}

function pick<T>(arr: readonly T[]): T {
  return arr[Math.floor(Math.random() * arr.length)]!;
}

// ---------------------------------------------------------------------------
// Initial ticker
// ---------------------------------------------------------------------------

export const INITIAL_TICKERS: Record<TradingPair, Ticker> = {
  USD_ETB: {
    pair: "USD_ETB",
    lastPrice: 128.45,
    change24h: 1.34,
    high24h: 129.20,
    low24h: 126.80,
    volume24h: 248_540,
    volumeQuote24h: 31_891_213,
  },
  USDT_ETB: {
    pair: "USDT_ETB",
    lastPrice: 128.12,
    change24h: 0.92,
    high24h: 128.90,
    low24h: 126.55,
    volume24h: 412_780,
    volumeQuote24h: 52_883_220,
  },
};

// ---------------------------------------------------------------------------
// Orderbook generator
// ---------------------------------------------------------------------------

export function generateOrderbook(pair: TradingPair): OrderbookSnapshot {
  const mid = INITIAL_TICKERS[pair].lastPrice;
  const bids: OrderbookLevel[] = [];
  const asks: OrderbookLevel[] = [];
  let bidTotal = 0;
  let askTotal = 0;
  const tick = mid * 0.0002; // 2 bps
  for (let i = 0; i < 14; i++) {
    const bidPrice = mid - tick * (i + 1);
    const bidQty = rand(50, 1500);
    bidTotal += bidQty;
    bids.push({ price: bidPrice, quantity: bidQty, total: bidTotal });

    const askPrice = mid + tick * (i + 1);
    const askQty = rand(50, 1500);
    askTotal += askQty;
    asks.push({ price: askPrice, quantity: askQty, total: askTotal });
  }
  const spread = asks[0]!.price - bids[0]!.price;
  return {
    pair,
    bids,
    asks,
    spread,
    spreadPercent: (spread / mid) * 100,
    timestamp: Date.now(),
  };
}

// ---------------------------------------------------------------------------
// P2P listings
// ---------------------------------------------------------------------------

export function generateP2PListings(count: number = 20): P2PListing[] {
  const listings: P2PListing[] = [];
  for (let i = 0; i < count; i++) {
    const side: "BUY" | "SELL" = Math.random() > 0.5 ? "BUY" : "SELL";
    const asset: "USD" | "USDT" = Math.random() > 0.5 ? "USD" : "USDT";
    const basePrice = asset === "USD" ? 128.45 : 128.12;
    const priceVariance = (Math.random() - 0.5) * 2.5;
    const price = basePrice + priceVariance;
    const available = Math.floor(rand(500, 8000));
    listings.push({
      id: `p2p-${i + 1}`,
      advertiser: pick(ADVERTISER_NAMES),
      advertiserTrades: Math.floor(rand(50, 5000)),
      advertiserRating: Math.floor(rand(88, 100)),
      side,
      asset,
      fiat: "ETB",
      price: Number(price.toFixed(2)),
      available,
      limitMin: Math.floor(rand(500, 5000)),
      limitMax: Math.floor(rand(50_000, 500_000)),
      paymentMethods: Array.from(new Set([
        pick(PAYMENT_METHODS),
        pick(PAYMENT_METHODS),
        pick(PAYMENT_METHODS),
      ])),
      completionRate: Math.floor(rand(92, 100)),
      online: Math.random() > 0.3,
    });
  }
  // SELL listings first, sorted by price ASC; then BUY, sorted by price DESC.
  return listings.sort((a, b) => {
    if (a.side !== b.side) return a.side === "SELL" ? -1 : 1;
    return a.side === "SELL" ? a.price - b.price : b.price - a.price;
  });
}

// ---------------------------------------------------------------------------
// Candle chart data — 90 candles, ~1% volatility per candle
// ---------------------------------------------------------------------------

export function generateCandles(pair: TradingPair, count: number = 90): Candle[] {
  const candles: Candle[] = [];
  let price = INITIAL_TICKERS[pair].lastPrice * 0.97;
  const now = Date.now();
  const interval = 60 * 60 * 1000; // 1h candles
  for (let i = count - 1; i >= 0; i--) {
    const open = price;
    const volatility = price * 0.012;
    const close = open + (Math.random() - 0.48) * volatility;
    const high = Math.max(open, close) + Math.random() * volatility * 0.6;
    const low = Math.min(open, close) - Math.random() * volatility * 0.6;
    candles.push({
      time: now - i * interval,
      open,
      high,
      low,
      close,
      volume: rand(1000, 5000),
    });
    price = close;
  }
  return candles;
}

// ---------------------------------------------------------------------------
// Live tick simulator — used by the page to drive the order book animations
// ---------------------------------------------------------------------------

export function nextTick(current: Ticker): Ticker {
  const drift = (Math.random() - 0.5) * 0.0015;
  const newPrice = current.lastPrice * (1 + drift);
  return {
    ...current,
    lastPrice: Number(newPrice.toFixed(2)),
    high24h: Math.max(current.high24h, newPrice),
    low24h: Math.min(current.low24h, newPrice),
    change24h: Number(((newPrice - current.lastPrice * (1 - current.change24h / 100)) / (current.lastPrice * (1 - current.change24h / 100))) * 100 + current.change24h).toFixed(2),
    volume24h: current.volume24h + rand(-50, 100),
    volumeQuote24h: current.volumeQuote24h + rand(-5000, 12000),
  };
}

// ---------------------------------------------------------------------------
// Trust / platform stats
// ---------------------------------------------------------------------------

export const PLATFORM_STATS = {
  totalUsers: "184,520",
  totalVolume: "ETB 8.4B+",
  totalTrades: "1.2M+",
  uptimePercent: "99.99%",
  countriesServed: "1",
  paymentMethods: 5,
  avgSettlementMinutes: 4,
  disputeResolutionHours: 12,
  reserveRatioPercent: "102%",
};

export const FEATURE_HIGHLIGHTS = [
  {
    title: "Instant Telebirr Settlement",
    description: "Send/receive ETB in under 30 minutes via Telebirr, M-PESA, CBE, Awash, or Dashen Bank.",
    icon: "zap",
    metric: "< 30 min",
    metricLabel: "avg settlement",
  },
  {
    title: "Bank-Grade Security",
    description: "RSA-256 encrypted PII, TOTP 2FA, anti-CSRF cookies, and ACID-compliant escrow on every trade.",
    icon: "shield",
    metric: "256-bit",
    metricLabel: "RSA encryption",
  },
  {
    title: "NBE-Compliant Reporting",
    description: "Automated daily reports submitted to the National Bank of Ethiopia at 22:00 Addis Ababa time.",
    icon: "file-check",
    metric: "100%",
    metricLabel: "NBE compliant",
  },
  {
    title: "Self-Match Prevention",
    description: "Price-time priority matching engine with per-pair distributed locks and double-spend defense.",
    icon: "lock",
    metric: "0",
    metricLabel: "double-spend incidents",
  },
];

export const STEPS = [
  {
    number: "01",
    title: "Place Your Order",
    description: "Choose to buy or sell USD/USDT. Set your price and quantity, or match instantly against the order book.",
    icon: "mouse-pointer-click",
  },
  {
    number: "02",
    title: "Escrow Locks Instantly",
    description: "The seller's crypto is atomically locked in our ACID-compliant escrow. A 30-minute payment window starts immediately.",
    icon: "lock",
  },
  {
    number: "03",
    title: "Settle via Telebirr",
    description: "The buyer sends ETB via Telebirr, M-PESA, or bank. Once the seller confirms receipt, crypto is released. Done!",
    icon: "check-circle",
  },
];

export const PAYMENT_PROVIDERS = [
  { name: "Telebirr", color: "#EE2B3A", description: "Ethio Telecom", coverage: "98% of mobile money" },
  { name: "M-PESA", color: "#4CB050", description: "Safaricom Ethiopia", coverage: "Cross-border ready" },
  { name: "CBE", color: "#1B4F8C", description: "Commercial Bank of Ethiopia", coverage: "Largest bank network" },
  { name: "Awash Bank", color: "#F37021", description: "Private bank", coverage: "400+ branches" },
  { name: "Dashen Bank", color: "#0E8E9E", description: "Private bank", coverage: "Premium service" },
];

export const TRUST_BADGES = [
  { label: "ISO 27001 Ready", icon: "shield-check" },
  { label: "NBE Registered", icon: "landmark" },
  { label: "ACID Compliant", icon: "database" },
  { label: "SOC 2 Type II", icon: "lock" },
  { label: "GDPR Aligned", icon: "globe" },
];
