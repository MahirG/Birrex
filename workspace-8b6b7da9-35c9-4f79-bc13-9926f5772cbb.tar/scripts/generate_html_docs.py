#!/usr/bin/env python3
"""
Generates a single self-contained HTML documentation file for the
ETB/USD P2P Exchange project. The output is saved to
/home/z/my-project/download/etb-p2p-exchange-docs.html

The HTML contains:
  1. Project overview + tech stack
  2. Architecture diagram (Mermaid.js via CDN)
  3. Trade state machine diagram
  4. Module-by-module breakdown with key code snippets
  5. Full source tree browser (collapsible tree)
  6. API endpoint reference
  7. Test suite summary

The HTML is fully offline-browseable once loaded (Mermaid is the only CDN
dependency — the code blocks are static HTML).
"""
import os
import re
import html
import json
from pathlib import Path
from datetime import datetime

PROJECT_ROOT = Path('/home/z/my-project')
OUTPUT_FILE = PROJECT_ROOT / 'download' / 'etb-p2p-exchange-docs.html'

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def escape_html(s: str) -> str:
    return html.escape(s, quote=True)

def slugify(s: str) -> str:
    return re.sub(r'[^a-z0-9-]+', '-', s.lower()).strip('-')

# ---------------------------------------------------------------------------
# Walk the project tree
# ---------------------------------------------------------------------------

# Files we want to include in the source browser (relative paths).
INCLUDE_EXTENSIONS = {'.ts', '.sql', '.json', '.yml', '.yaml', '.md', '.sh'}
EXCLUDE_DIRS = {'node_modules', 'dist', 'coverage', '.git', 'upload', 'skills'}
EXCLUDE_FILES = {'.env', '.env.example'}  # env files might have secrets

def walk_tree(root: Path):
    """Returns a nested dict: { name, path, type ('dir'|'file'), children? }"""
    tree = {'name': root.name, 'path': str(root.relative_to(PROJECT_ROOT)), 'type': 'dir', 'children': []}
    for entry in sorted(root.iterdir(), key=lambda p: (not p.is_dir(), p.name)):
        if entry.name in EXCLUDE_DIRS:
            continue
        if entry.is_dir():
            child = walk_tree(entry)
            # Skip empty directories
            if child['children']:
                tree['children'].append(child)
        elif entry.is_file():
            if entry.name in EXCLUDE_FILES:
                continue
            if entry.suffix.lower() in INCLUDE_EXTENSIONS:
                tree['children'].append({
                    'name': entry.name,
                    'path': str(entry.relative_to(PROJECT_ROOT)),
                    'type': 'file',
                    'size': entry.stat().st_size,
                })
    return tree

def count_lines(path: Path) -> int:
    try:
        with open(path, 'r', encoding='utf-8', errors='replace') as f:
            return sum(1 for _ in f)
    except Exception:
        return 0

# ---------------------------------------------------------------------------
# Read key source files for embedding
# ---------------------------------------------------------------------------

def read_file(rel_path: str) -> str:
    p = PROJECT_ROOT / rel_path
    if not p.exists():
        return f'// FILE NOT FOUND: {rel_path}'
    try:
        return p.read_text(encoding='utf-8', errors='replace')
    except Exception as e:
        return f'// ERROR: {e}'

# ---------------------------------------------------------------------------
# Module manifest — defines what each module does + key code snippets
# ---------------------------------------------------------------------------

MODULES = [
    {
        'name': 'Matching Engine',
        'icon': 'matching',
        'color': '#3b82f6',
        'phase': 'Phase 1',
        'summary': 'Price-time priority matching with per-pair distributed Redis lock, self-match prevention, atomic escrow, and full state machine from ESCROW_PENDING → RELEASED.',
        'files': [
            'src/modules/matching-engine/matching-engine.service.ts',
            'src/modules/matching-engine/matching-engine.controller.ts',
            'src/modules/matching-engine/dto/place-order.dto.ts',
        ],
        'highlights': [
            {
                'title': 'Core matching loop',
                'file': 'src/modules/matching-engine/matching-engine.service.ts',
                'lines': (396, 545),
            },
        ],
    },
    {
        'name': 'Orderbook',
        'icon': 'orderbook',
        'color': '#8b5cf6',
        'phase': 'Phase 1',
        'summary': 'Redis sorted sets scored by (price × 1e8 + createdAt). Atomic Lua scripts for peek/add/remove/updateQty. Cold-start rebuild from Postgres.',
        'files': [
            'src/modules/orderbook/orderbook.service.ts',
        ],
        'highlights': [
            {
                'title': 'Atomic Lua: peek matchable makers',
                'file': 'src/modules/orderbook/orderbook.service.ts',
                'lines': (24, 71),
            },
        ],
    },
    {
        'name': 'Escrow',
        'icon': 'escrow',
        'color': '#10b981',
        'phase': 'Phase 1',
        'summary': 'SERIALIZABLE Postgres transactions with SELECT FOR UPDATE on wallets + orders. Every balance mutation writes an immutable WalletTransaction ledger row.',
        'files': [
            'src/modules/escrow/escrow.service.ts',
        ],
        'highlights': [
            {
                'title': 'Atomic escrow lock',
                'file': 'src/modules/escrow/escrow.service.ts',
                'lines': (60, 180),
            },
        ],
    },
    {
        'name': 'WebSocket Gateway',
        'icon': 'websocket',
        'color': '#f59e0b',
        'phase': 'Phase 1',
        'summary': 'Socket.io server with @socket.io/redis-adapter for multi-instance room replication. RealtimeBroadcaster publishes to Redis pub/sub so events emit from any instance reach all subscribers.',
        'files': [
            'src/modules/websocket/websocket.gateway.ts',
            'src/modules/websocket/realtime.broadcaster.ts',
        ],
        'highlights': [],
    },
    {
        'name': 'Auth',
        'icon': 'auth',
        'color': '#ef4444',
        'phase': 'Phase 2',
        'summary': 'JWT access + refresh tokens (HttpOnly cookie). TOTP 2FA with otplib. Anti-CSRF via double-submit cookie (SameSite=Strict + Origin check). Account lockout after 5 failed logins.',
        'files': [
            'src/modules/auth/auth.service.ts',
            'src/modules/auth/auth.controller.ts',
            'src/modules/auth/guards/csrf.guard.ts',
            'src/modules/auth/strategies/jwt.strategy.ts',
        ],
        'highlights': [
            {
                'title': 'Login with 2FA verification',
                'file': 'src/modules/auth/auth.service.ts',
                'lines': (130, 220),
            },
            {
                'title': 'CSRF double-submit cookie guard',
                'file': 'src/modules/auth/guards/csrf.guard.ts',
                'lines': (1, 100),
            },
        ],
    },
    {
        'name': 'Wallets',
        'icon': 'wallets',
        'color': '#06b6d4',
        'phase': 'Phase 2',
        'summary': 'Double-entry ledger with signed amounts (negative=debit, positive=credit). Admin deposit + user withdrawal + APPROVE/REJECT workflow. Every balance change has before/after snapshots.',
        'files': [
            'src/modules/wallets/wallet.service.ts',
            'src/modules/wallets/wallet.controller.ts',
            'src/modules/wallets/dto/wallet.dto.ts',
        ],
        'highlights': [
            {
                'title': 'Admin deposit with atomic ledger write',
                'file': 'src/modules/wallets/wallet.service.ts',
                'lines': (122, 175),
            },
        ],
    },
    {
        'name': 'KYC',
        'icon': 'kyc',
        'color': '#a855f7',
        'phase': 'Phase 2',
        'summary': 'End-to-end submission → moderator review → user verification. Tamper detection via SHA-256. Document numbers encrypted at column level. Idempotent approve/reject. Resubmission after rejection with full audit trail.',
        'files': [
            'src/modules/kyc/kyc.service.ts',
            'src/modules/kyc/kyc.controller.ts',
            'src/modules/kyc/dto/kyc.dto.ts',
            'src/database/entities/kyc.entity.ts',
        ],
        'highlights': [
            {
                'title': 'Submit KYC with tamper detection',
                'file': 'src/modules/kyc/kyc.service.ts',
                'lines': (74, 145),
            },
        ],
    },
    {
        'name': 'Disputes',
        'icon': 'disputes',
        'color': '#dc2626',
        'phase': 'Phase 3',
        'summary': 'Ticketing + moderator queue + screenshot uploads. Open → Under Review → Resolved (Maker/Taker/Refund/Escalated). RESOLVED_MAKER triggers escrow.refundEscrow(). Hash verification on every evidence upload.',
        'files': [
            'src/modules/disputes/dispute.service.ts',
            'src/modules/disputes/dispute.controller.ts',
            'src/modules/disputes/dto/dispute.dto.ts',
        ],
        'highlights': [
            {
                'title': 'Open dispute with evidence upload + tamper detection',
                'file': 'src/modules/disputes/dispute.service.ts',
                'lines': (60, 165),
            },
            {
                'title': 'Resolve dispute triggers escrow action',
                'file': 'src/modules/disputes/dispute.service.ts',
                'lines': (245, 320),
            },
        ],
    },
    {
        'name': 'Payments',
        'icon': 'payments',
        'color': '#0ea5e9',
        'phase': 'Phase 3',
        'summary': '5 Ethiopian payment provider adapters: Telebirr (HMAC-SHA256), M-PESA (Daraja), CBE, Awash, Dashen. PaymentProviderRegistry routes by enum. Account numbers RSA-256 encrypted + masked on read.',
        'files': [
            'src/modules/payments/payment.service.ts',
            'src/modules/payments/payment.controller.ts',
            'src/modules/payments/providers/payment-providers.ts',
            'src/modules/payments/dto/payment.dto.ts',
        ],
        'highlights': [
            {
                'title': 'Telebirr adapter with HMAC-SHA256 webhook verification',
                'file': 'src/modules/payments/providers/payment-providers.ts',
                'lines': (42, 130),
            },
        ],
    },
    {
        'name': 'NBE Compliance',
        'icon': 'nbe',
        'color': '#16a34a',
        'phase': 'Phase 3',
        'summary': 'Daily NBE report at 22:00 Addis_Ababa via cron. Suspicious transaction flags: large cash (≥200k ETB), frequent trader (≥10/day), high dispute ratio (≥30%), rapid-fire ordering (≥50/hr).',
        'files': [
            'src/modules/nbe-compliance/nbe-report.service.ts',
            'src/modules/nbe-compliance/nbe-report.controller.ts',
            'src/modules/nbe-compliance/dto/nbe-report.dto.ts',
        ],
        'highlights': [
            {
                'title': 'Suspicious transaction detection rules',
                'file': 'src/modules/nbe-compliance/nbe-report.service.ts',
                'lines': (240, 315),
            },
        ],
    },
]

# ---------------------------------------------------------------------------
# API endpoints reference
# ---------------------------------------------------------------------------

API_ENDPOINTS = [
    # Auth
    {'method': 'POST', 'path': '/api/v1/auth/register', 'auth': 'None', 'csrf': 'No', 'desc': 'Register new account'},
    {'method': 'POST', 'path': '/api/v1/auth/login', 'auth': 'None', 'csrf': 'No', 'desc': 'Login (+ 2FA if enabled)'},
    {'method': 'POST', 'path': '/api/v1/auth/refresh', 'auth': 'Refresh Cookie', 'csrf': 'No', 'desc': 'Rotate access + refresh tokens'},
    {'method': 'POST', 'path': '/api/v1/auth/logout', 'auth': 'JWT', 'csrf': 'Yes', 'desc': 'Clear refresh + CSRF cookies'},
    {'method': 'GET', 'path': '/api/v1/auth/me', 'auth': 'JWT', 'csrf': 'No', 'desc': 'Current user profile'},
    {'method': 'GET', 'path': '/api/v1/auth/csrf-token', 'auth': 'None', 'csrf': 'No', 'desc': 'Issue fresh CSRF cookie'},
    {'method': 'POST', 'path': '/api/v1/auth/2fa/setup', 'auth': 'JWT', 'csrf': 'Yes', 'desc': 'Generate TOTP secret + QR code'},
    {'method': 'POST', 'path': '/api/v1/auth/2fa/verify', 'auth': 'JWT', 'csrf': 'Yes', 'desc': 'Verify first TOTP code → enable 2FA'},
    {'method': 'POST', 'path': '/api/v1/auth/2fa/disable', 'auth': 'JWT', 'csrf': 'Yes', 'desc': 'Disable 2FA (requires password + TOTP)'},

    # Wallets
    {'method': 'GET', 'path': '/api/v1/wallets', 'auth': 'JWT', 'csrf': 'No', 'desc': 'List all wallet balances'},
    {'method': 'GET', 'path': '/api/v1/wallets/:currency', 'auth': 'JWT', 'csrf': 'No', 'desc': 'Get balance for one currency'},
    {'method': 'GET', 'path': '/api/v1/wallets/transactions/list', 'auth': 'JWT', 'csrf': 'No', 'desc': 'Paginated ledger query'},
    {'method': 'POST', 'path': '/api/v1/wallets/withdrawals', 'auth': 'JWT', 'csrf': 'Yes', 'desc': 'Request withdrawal (available → locked)'},
    {'method': 'POST', 'path': '/api/v1/admin/wallets/deposits', 'auth': 'JWT+Admin', 'csrf': 'Yes', 'desc': 'Admin credits user deposit'},
    {'method': 'POST', 'path': '/api/v1/admin/wallets/withdrawals/:id/process', 'auth': 'JWT+Admin', 'csrf': 'Yes', 'desc': 'Approve/reject withdrawal'},

    # KYC
    {'method': 'POST', 'path': '/api/v1/kyc/submit', 'auth': 'JWT', 'csrf': 'Yes', 'desc': 'Submit KYC application with documents'},
    {'method': 'GET', 'path': '/api/v1/kyc/status', 'auth': 'JWT', 'csrf': 'No', 'desc': 'Get current KYC status + latest submission'},
    {'method': 'GET', 'path': '/api/v1/admin/kyc/pending', 'auth': 'JWT+Mod', 'csrf': 'No', 'desc': 'Moderator queue of PENDING submissions'},
    {'method': 'POST', 'path': '/api/v1/admin/kyc/:id/approve', 'auth': 'JWT+Admin', 'csrf': 'Yes', 'desc': 'Approve KYC → user verified'},
    {'method': 'POST', 'path': '/api/v1/admin/kyc/:id/reject', 'auth': 'JWT+Admin', 'csrf': 'Yes', 'desc': 'Reject KYC with reason'},

    # Orders / Matching
    {'method': 'POST', 'path': '/api/v1/orders', 'auth': 'JWT+KYC', 'csrf': 'Yes', 'desc': 'Place LIMIT/MARKET order'},
    {'method': 'DELETE', 'path': '/api/v1/orders/:id', 'auth': 'JWT+KYC', 'csrf': 'Yes', 'desc': 'Cancel OPEN/PARTIALLY_FILLED order'},
    {'method': 'GET', 'path': '/api/v1/orders/orderbook/:pair', 'auth': 'JWT', 'csrf': 'No', 'desc': 'L2 orderbook snapshot (50 levels)'},
    {'method': 'GET', 'path': '/api/v1/orders/top-of-book/:pair', 'auth': 'JWT', 'csrf': 'No', 'desc': 'Best bid/ask + spread'},

    # Disputes
    {'method': 'POST', 'path': '/api/v1/disputes', 'auth': 'JWT', 'csrf': 'Yes', 'desc': 'Open dispute against a trade'},
    {'method': 'POST', 'path': '/api/v1/disputes/:id/evidence', 'auth': 'JWT', 'csrf': 'Yes', 'desc': 'Add evidence to a dispute'},
    {'method': 'GET', 'path': '/api/v1/disputes', 'auth': 'JWT', 'csrf': 'No', 'desc': 'List my disputes (as participant)'},
    {'method': 'GET', 'path': '/api/v1/admin/disputes', 'auth': 'JWT+Mod', 'csrf': 'No', 'desc': 'Moderator queue (filterable)'},
    {'method': 'POST', 'path': '/api/v1/admin/disputes/:id/assign', 'auth': 'JWT+Mod', 'csrf': 'Yes', 'desc': 'Self-assign OPEN dispute'},
    {'method': 'POST', 'path': '/api/v1/admin/disputes/:id/resolve', 'auth': 'JWT+Admin', 'csrf': 'Yes', 'desc': 'Resolve dispute (triggers escrow)'},

    # Payments
    {'method': 'POST', 'path': '/api/v1/payments/methods', 'auth': 'JWT', 'csrf': 'Yes', 'desc': 'Register payment method (encrypted)'},
    {'method': 'GET', 'path': '/api/v1/payments/methods', 'auth': 'JWT', 'csrf': 'No', 'desc': 'List user payment methods (masked)'},
    {'method': 'POST', 'path': '/api/v1/payments/initiate', 'auth': 'JWT', 'csrf': 'Yes', 'desc': 'Initiate outbound payment via provider'},
    {'method': 'POST', 'path': '/api/v1/payments/webhook', 'auth': 'Signature', 'csrf': 'No', 'desc': 'Provider webhook (signature-verified)'},
    {'method': 'POST', 'path': '/api/v1/admin/payments/methods/:id/verify', 'auth': 'JWT+Admin', 'csrf': 'Yes', 'desc': 'Verify user payment method'},

    # NBE Compliance
    {'method': 'GET', 'path': '/api/v1/admin/nbe/report', 'auth': 'JWT+Admin', 'csrf': 'No', 'desc': 'Generate NBE report for date range'},
    {'method': 'POST', 'path': '/api/v1/admin/nbe/submit', 'auth': 'JWT+Admin', 'csrf': 'Yes', 'desc': 'Manually submit daily report to NBE'},
    {'method': 'GET', 'path': '/api/v1/admin/nbe/suspicious', 'auth': 'JWT+Admin', 'csrf': 'No', 'desc': 'List recent suspicious transactions'},
]

# ---------------------------------------------------------------------------
# Build the HTML
# ---------------------------------------------------------------------------

def render_code_block(code: str, lang: str = 'typescript') -> str:
    """Renders a syntax-highlighted code block."""
    escaped = escape_html(code)
    return f'<pre class="code-block" data-lang="{lang}"><code>{escaped}</code></pre>'

def render_code_excerpt(rel_path: str, line_range: tuple[int, int] | None = None) -> str:
    """Renders a code excerpt from a file, optionally limited to a line range."""
    content = read_file(rel_path)
    if line_range:
        start, end = line_range
        lines = content.split('\n')
        # Adjust for 1-indexed lines.
        excerpt = '\n'.join(lines[start - 1:end])
        # Prepend line numbers
        numbered = '\n'.join(
            f'{i + start:4d} | {line}'
            for i, line in enumerate(lines[start - 1:end])
        )
        lang = 'typescript' if rel_path.endswith('.ts') else 'sql' if rel_path.endswith('.sql') else 'text'
        return f'<pre class="code-block" data-lang="{lang}"><code>{escape_html(numbered)}</code></pre>'
    else:
        lang = 'typescript' if rel_path.endswith('.ts') else 'sql' if rel_path.endswith('.sql') else 'text'
        return render_code_block(content, lang)

def render_tree_node(node: dict, level: int = 0) -> str:
    """Renders a single tree node as HTML."""
    indent = '  ' * level
    if node['type'] == 'dir':
        children_html = ''.join(render_tree_node(c, level + 1) for c in node.get('children', []))
        return f'''
        <li class="tree-dir" data-path="{escape_html(node['path'])}">
          <span class="tree-icon">📁</span>
          <span class="tree-name">{escape_html(node['name'])}/</span>
          <ul class="tree-children">{children_html}</ul>
        </li>'''
    else:
        size_kb = node.get('size', 0) / 1024
        size_str = f'{size_kb:.1f}KB' if size_kb < 1024 else f'{size_kb / 1024:.1f}MB'
        return f'''
        <li class="tree-file" data-path="{escape_html(node['path'])}">
          <span class="tree-icon">📄</span>
          <span class="tree-name">{escape_html(node['name'])}</span>
          <span class="tree-size">{size_str}</span>
        </li>'''

def render_module(mod: dict) -> str:
    """Renders a single module section."""
    files_html = ''
    for f in mod['files']:
        content = read_file(f)
        line_count = content.count('\n') + 1
        files_html += f'''
        <div class="file-section">
          <h4 class="file-title">
            <span class="file-path">{escape_html(f)}</span>
            <span class="file-lines">{line_count} lines</span>
          </h4>
          {render_code_excerpt(f)}
        </div>'''

    highlights_html = ''
    for h in mod.get('highlights', []):
        highlights_html += f'''
        <div class="highlight-section">
          <h4 class="highlight-title">{escape_html(h['title'])}</h4>
          <p class="highlight-path">{escape_html(h['file'])} : lines {h['lines'][0]}-{h['lines'][1]}</p>
          {render_code_excerpt(h['file'], h['lines'])}
        </div>'''

    return f'''
    <section class="module" id="module-{slugify(mod['name'])}" style="--module-color: {mod['color']};">
      <header class="module-header">
        <div class="module-badge" style="background: {mod['color']};">{escape_html(mod['phase'])}</div>
        <h2 class="module-title">{escape_html(mod['name'])}</h2>
      </header>
      <p class="module-summary">{escape_html(mod['summary'])}</p>
      {highlights_html}
      <h3 class="files-heading">Full source</h3>
      {files_html}
    </section>'''

def render_api_table() -> str:
    """Renders the API endpoints reference table."""
    rows = []
    for ep in API_ENDPOINTS:
        method_class = ep['method'].lower()
        rows.append(f'''
        <tr>
          <td><span class="method method-{method_class}">{ep['method']}</span></td>
          <td><code>{escape_html(ep['path'])}</code></td>
          <td>{escape_html(ep['auth'])}</td>
          <td>{escape_html(ep['csrf'])}</td>
          <td>{escape_html(ep['desc'])}</td>
        </tr>''')
    return f'<table class="api-table"><thead><tr><th>Method</th><th>Path</th><th>Auth</th><th>CSRF</th><th>Description</th></tr></thead><tbody>{"".join(rows)}</tbody></table>'

# ---------------------------------------------------------------------------
# Count project stats
# ---------------------------------------------------------------------------

def count_stats():
    ts_files = list((PROJECT_ROOT / 'src').rglob('*.ts'))
    sql_files = list((PROJECT_ROOT / 'src' / 'database' / 'migrations').glob('*.sql'))
    test_files = [f for f in ts_files if '.spec.ts' in f.name]
    src_files = [f for f in ts_files if '.spec.ts' not in f.name]

    src_loc = sum(count_lines(f) for f in src_files)
    test_loc = sum(count_lines(f) for f in test_files)
    sql_loc = sum(count_lines(f) for f in sql_files)

    return {
        'src_files': len(src_files),
        'test_files': len(test_files),
        'sql_files': len(sql_files),
        'src_loc': src_loc,
        'test_loc': test_loc,
        'sql_loc': sql_loc,
        'total_loc': src_loc + test_loc + sql_loc,
        'modules': len(MODULES),
        'endpoints': len(API_ENDPOINTS),
    }

stats = count_stats()
tree = walk_tree(PROJECT_ROOT)

# ---------------------------------------------------------------------------
# Build full HTML
# ---------------------------------------------------------------------------

generated_at = datetime.now().strftime('%Y-%m-%d %H:%M:%S UTC+3')

html_content = f'''<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ETB/USD P2P Crypto Exchange — Project Documentation</title>
  <script src="https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.min.js"></script>
  <style>
    /* ----------------------------------------------------------------- */
    /* DESIGN SYSTEM                                                      */
    /* ----------------------------------------------------------------- */
    :root {{
      --bg: #0f172a;
      --bg-elevated: #1e293b;
      --bg-card: #1e293b;
      --bg-code: #0b1120;
      --border: #334155;
      --text: #f1f5f9;
      --text-muted: #94a3b8;
      --text-dim: #64748b;
      --accent: #3b82f6;
      --accent-hover: #60a5fa;
      --success: #10b981;
      --warning: #f59e0b;
      --danger: #ef4444;
      --font-sans: -apple-system, BlinkMacSystemFont, "Segoe UI", "Helvetica Neue", Arial, sans-serif;
      --font-mono: "JetBrains Mono", "SF Mono", "Fira Code", Consolas, "Courier New", monospace;
    }}

    * {{ box-sizing: border-box; margin: 0; padding: 0; }}
    html {{ scroll-behavior: smooth; }}
    body {{
      background: var(--bg);
      color: var(--text);
      font-family: var(--font-sans);
      font-size: 15px;
      line-height: 1.6;
      -webkit-font-smoothing: antialiased;
    }}

    /* ----------------------------------------------------------------- */
    /* LAYOUT                                                             */
    /* ----------------------------------------------------------------- */
    .container {{ max-width: 1400px; margin: 0 auto; padding: 0 2rem; }}
    .sidebar {{
      position: fixed; top: 0; left: 0; bottom: 0; width: 280px;
      background: var(--bg-elevated); border-right: 1px solid var(--border);
      overflow-y: auto; padding: 2rem 1.5rem; z-index: 100;
    }}
    .main {{ margin-left: 280px; padding: 2rem 3rem; }}

    @media (max-width: 1024px) {{
      .sidebar {{ display: none; }}
      .main {{ margin-left: 0; padding: 1.5rem; }}
    }}

    /* ----------------------------------------------------------------- */
    /* SIDEBAR NAV                                                        */
    /* ----------------------------------------------------------------- */
    .sidebar h1 {{
      font-size: 1.15rem; font-weight: 700; margin-bottom: 0.25rem;
      background: linear-gradient(135deg, var(--accent) 0%, #8b5cf6 100%);
      -webkit-background-clip: text; -webkit-text-fill-color: transparent;
      background-clip: text;
    }}
    .sidebar .subtitle {{ color: var(--text-muted); font-size: 0.8rem; margin-bottom: 2rem; }}
    .sidebar nav h3 {{
      color: var(--text-dim); font-size: 0.7rem; text-transform: uppercase;
      letter-spacing: 0.1em; margin: 1.5rem 0 0.5rem;
    }}
    .sidebar nav a {{
      display: block; color: var(--text-muted); text-decoration: none;
      padding: 0.4rem 0.5rem; border-radius: 6px; font-size: 0.875rem;
      transition: all 0.15s;
    }}
    .sidebar nav a:hover {{ background: var(--bg-card); color: var(--text); }}
    .sidebar nav a.module-link::before {{
      content: ''; display: inline-block; width: 8px; height: 8px;
      border-radius: 50%; margin-right: 0.5rem; vertical-align: middle;
      background: var(--module-color, var(--accent));
    }}

    /* ----------------------------------------------------------------- */
    /* HERO                                                               */
    /* ----------------------------------------------------------------- */
    .hero {{
      padding: 3rem 0 2rem; border-bottom: 1px solid var(--border); margin-bottom: 2rem;
    }}
    .hero h2 {{
      font-size: 2.5rem; font-weight: 800; line-height: 1.1; margin-bottom: 1rem;
      background: linear-gradient(135deg, #f1f5f9 0%, #94a3b8 100%);
      -webkit-background-clip: text; -webkit-text-fill-color: transparent;
      background-clip: text;
    }}
    .hero .lead {{ font-size: 1.1rem; color: var(--text-muted); max-width: 60ch; }}
    .hero .meta {{
      display: flex; gap: 1.5rem; margin-top: 1.5rem; flex-wrap: wrap;
      color: var(--text-dim); font-size: 0.85rem;
    }}
    .hero .meta strong {{ color: var(--text); font-weight: 600; }}

    /* ----------------------------------------------------------------- */
    /* STATS GRID                                                         */
    /* ----------------------------------------------------------------- */
    .stats-grid {{
      display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 1rem; margin: 2rem 0;
    }}
    .stat-card {{
      background: var(--bg-card); border: 1px solid var(--border);
      border-radius: 10px; padding: 1.25rem;
    }}
    .stat-card .label {{ color: var(--text-dim); font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.05em; }}
    .stat-card .value {{ font-size: 1.75rem; font-weight: 700; margin-top: 0.25rem; }}
    .stat-card .value.mono {{ font-family: var(--font-mono); color: var(--accent); }}

    /* ----------------------------------------------------------------- */
    /* SECTIONS                                                           */
    /* ----------------------------------------------------------------- */
    section.block {{ margin: 3rem 0; }}
    section.block > h3 {{
      font-size: 1.5rem; font-weight: 700; margin-bottom: 1rem;
      padding-bottom: 0.5rem; border-bottom: 2px solid var(--border);
    }}

    /* ----------------------------------------------------------------- */
    /* MODULE CARDS                                                       */
    /* ----------------------------------------------------------------- */
    .module {{
      background: var(--bg-card); border: 1px solid var(--border);
      border-left: 4px solid var(--module-color, var(--accent));
      border-radius: 10px; padding: 2rem; margin: 2rem 0;
    }}
    .module-header {{ display: flex; align-items: center; gap: 1rem; margin-bottom: 0.75rem; }}
    .module-badge {{
      font-size: 0.7rem; font-weight: 700; padding: 0.25rem 0.6rem;
      border-radius: 999px; color: white; text-transform: uppercase;
      letter-spacing: 0.05em;
    }}
    .module-title {{ font-size: 1.5rem; font-weight: 700; }}
    .module-summary {{ color: var(--text-muted); margin-bottom: 1.5rem; font-size: 0.95rem; }}
    .files-heading, .highlight-title {{
      font-size: 1rem; font-weight: 600; margin: 1.5rem 0 0.75rem;
      color: var(--accent-hover);
    }}
    .file-section {{ margin: 1rem 0; }}
    .file-title {{
      display: flex; justify-content: space-between; align-items: center;
      font-family: var(--font-mono); font-size: 0.8rem; color: var(--text-muted);
      background: var(--bg-elevated); padding: 0.5rem 0.75rem;
      border-radius: 6px 6px 0 0; border: 1px solid var(--border); border-bottom: none;
    }}
    .file-path {{ color: var(--accent-hover); }}
    .file-lines {{ color: var(--text-dim); }}
    .highlight-section {{ margin: 1.5rem 0; }}
    .highlight-path {{
      font-family: var(--font-mono); font-size: 0.75rem; color: var(--text-dim);
      margin-bottom: 0.5rem;
    }}

    /* ----------------------------------------------------------------- */
    /* CODE BLOCKS                                                        */
    /* ----------------------------------------------------------------- */
    .code-block {{
      background: var(--bg-code); border: 1px solid var(--border);
      border-radius: 0 0 6px 6px; padding: 1rem 1.25rem;
      font-family: var(--font-mono); font-size: 0.8rem; line-height: 1.55;
      overflow-x: auto; max-height: 600px; overflow-y: auto;
      color: #cbd5e1;
    }}
    .file-section .code-block {{ border-radius: 0 0 6px 6px; }}
    .code-block::-webkit-scrollbar {{ height: 8px; width: 8px; }}
    .code-block::-webkit-scrollbar-track {{ background: var(--bg-code); }}
    .code-block::-webkit-scrollbar-thumb {{ background: var(--border); border-radius: 4px; }}

    /* ----------------------------------------------------------------- */
    /* TABLES                                                             */
    /* ----------------------------------------------------------------- */
    .api-table {{
      width: 100%; border-collapse: collapse; margin: 1rem 0;
      font-size: 0.85rem;
    }}
    .api-table th {{
      text-align: left; padding: 0.75rem 1rem; background: var(--bg-elevated);
      color: var(--text-muted); font-weight: 600; font-size: 0.75rem;
      text-transform: uppercase; letter-spacing: 0.05em;
      border-bottom: 1px solid var(--border);
    }}
    .api-table td {{
      padding: 0.6rem 1rem; border-bottom: 1px solid var(--border);
      vertical-align: top;
    }}
    .api-table tr:hover td {{ background: var(--bg-elevated); }}
    .api-table code {{ font-family: var(--font-mono); font-size: 0.8rem; color: var(--accent-hover); }}
    .method {{
      display: inline-block; padding: 0.15rem 0.5rem; border-radius: 4px;
      font-size: 0.7rem; font-weight: 700; font-family: var(--font-mono);
      color: white; min-width: 50px; text-align: center;
    }}
    .method-get {{ background: #10b981; }}
    .method-post {{ background: #3b82f6; }}
    .method-delete {{ background: #ef4444; }}
    .method-patch {{ background: #f59e0b; }}

    /* ----------------------------------------------------------------- */
    /* MERMAID                                                            */
    /* ----------------------------------------------------------------- */
    .mermaid {{
      background: white; padding: 1.5rem; border-radius: 8px;
      margin: 1rem 0; text-align: center;
    }}

    /* ----------------------------------------------------------------- */
    /* TREE VIEWER                                                        */
    /* ----------------------------------------------------------------- */
    .tree-viewer {{
      background: var(--bg-card); border: 1px solid var(--border);
      border-radius: 8px; padding: 1rem; margin: 1rem 0;
      font-family: var(--font-mono); font-size: 0.8rem;
      max-height: 600px; overflow-y: auto;
    }}
    .tree-viewer ul {{ list-style: none; padding-left: 1.25rem; }}
    .tree-viewer > ul {{ padding-left: 0; }}
    .tree-viewer li {{ padding: 0.15rem 0; color: var(--text-muted); }}
    .tree-viewer .tree-dir {{ cursor: pointer; }}
    .tree-viewer .tree-dir > .tree-name {{ color: var(--accent-hover); font-weight: 600; }}
    .tree-viewer .tree-file .tree-name {{ color: var(--text); }}
    .tree-viewer .tree-size {{ color: var(--text-dim); margin-left: 0.5rem; font-size: 0.75rem; }}
    .tree-viewer .tree-icon {{ margin-right: 0.4rem; }}

    /* Collapsed state */
    .tree-viewer .tree-dir.collapsed > .tree-children {{ display: none; }}

    /* ----------------------------------------------------------------- */
    /* FOOTER                                                             */
    /* ----------------------------------------------------------------- */
    footer {{
      margin-top: 4rem; padding-top: 2rem; border-top: 1px solid var(--border);
      color: var(--text-dim); font-size: 0.85rem; text-align: center;
    }}

    /* ----------------------------------------------------------------- */
    /* UTILITIES                                                          */
    /* ----------------------------------------------------------------- */
    .badge {{
      display: inline-block; padding: 0.15rem 0.5rem; border-radius: 4px;
      font-size: 0.7rem; font-weight: 600; background: var(--bg-elevated);
      color: var(--text-muted); border: 1px solid var(--border);
    }}
    .badge-success {{ background: rgba(16, 185, 129, 0.15); color: #34d399; border-color: rgba(16, 185, 129, 0.3); }}
    .badge-warning {{ background: rgba(245, 158, 11, 0.15); color: #fbbf24; border-color: rgba(245, 158, 11, 0.3); }}
    .badge-info {{ background: rgba(59, 130, 246, 0.15); color: #60a5fa; border-color: rgba(59, 130, 246, 0.3); }}
  </style>
</head>
<body>

<!-- ================================================================= -->
<!-- SIDEBAR                                                            -->
<!-- ================================================================= -->
<aside class="sidebar">
  <h1>ETB/USD P2P Exchange</h1>
  <p class="subtitle">Backend Documentation</p>

  <nav>
    <h3>Overview</h3>
    <a href="#top">Project Overview</a>
    <a href="#architecture">Architecture</a>
    <a href="#state-machine">Trade State Machine</a>
    <a href="#stats">Project Stats</a>

    <h3>Modules</h3>
    {''.join(f'<a href="#module-{slugify(m["name"])}" class="module-link" style="--module-color: {m["color"]}">{m["name"]}</a>' for m in MODULES)}

    <h3>Reference</h3>
    <a href="#api">API Endpoints</a>
    <a href="#tests">Test Suite</a>
    <a href="#tree">Source Tree</a>
    <a href="#sql">Database Schema</a>
  </nav>
</aside>

<!-- ================================================================= -->
<!-- MAIN CONTENT                                                       -->
<!-- ================================================================= -->
<main class="main" id="top">

  <!-- HERO -->
  <div class="hero">
    <h2>ETB/USD P2P Crypto Exchange</h2>
    <p class="lead">
      A production-grade P2P crypto/fiat exchange purpose-built for the Ethiopian Birr (ETB)
      and US Dollar (USD) market. NestJS + TypeORM + PostgreSQL + Redis + Socket.io, with
      full Amharic localization and Telebirr/M-PESA/CBE/Awash/Dashen payment integrations.
    </p>
    <div class="meta">
      <span><strong>Generated:</strong> {generated_at}</span>
      <span><strong>Version:</strong> Phase 3 Complete</span>
      <span><strong>License:</strong> UNLICENSED (Proprietary)</span>
    </div>
  </div>

  <!-- STATS -->
  <section class="block" id="stats">
    <h3>Project Statistics</h3>
    <div class="stats-grid">
      <div class="stat-card">
        <div class="label">Source Files</div>
        <div class="value mono">{stats['src_files']}</div>
      </div>
      <div class="stat-card">
        <div class="label">Test Files</div>
        <div class="value mono">{stats['test_files']}</div>
      </div>
      <div class="stat-card">
        <div class="label">Source LOC</div>
        <div class="value mono">{stats['src_loc']:,}</div>
      </div>
      <div class="stat-card">
        <div class="label">Test LOC</div>
        <div class="value mono">{stats['test_loc']:,}</div>
      </div>
      <div class="stat-card">
        <div class="label">SQL Schema LOC</div>
        <div class="value mono">{stats['sql_loc']:,}</div>
      </div>
      <div class="stat-card">
        <div class="label">Modules</div>
        <div class="value mono">{stats['modules']}</div>
      </div>
      <div class="stat-card">
        <div class="label">API Endpoints</div>
        <div class="value mono">{stats['endpoints']}</div>
      </div>
      <div class="stat-card">
        <div class="label">Total LOC</div>
        <div class="value mono">{stats['total_loc']:,}</div>
      </div>
    </div>
  </section>

  <!-- ARCHITECTURE -->
  <section class="block" id="architecture">
    <h3>System Architecture</h3>
    <p style="color: var(--text-muted); margin-bottom: 1rem;">
      Stateless NestJS instances scale horizontally behind a load balancer. All shared state
      lives in Redis (orderbook, sessions, pub/sub) and PostgreSQL (ACID store for trades,
      wallets, KYC, disputes). Socket.io Redis adapter replicates WebSocket room membership
      across instances so events emitted from any node reach all subscribers.
    </p>
    <div class="mermaid">
{read_file('docs/ARCHITECTURE.md').split('```mermaid')[1].split('```')[0]}
    </div>
  </section>

  <!-- STATE MACHINE -->
  <section class="block" id="state-machine">
    <h3>Trade State Machine</h3>
    <p style="color: var(--text-muted); margin-bottom: 1rem;">
      Every trade moves through this state machine. The SERIALIZABLE transaction in the
      EscrowService defends against double-spend at every transition.
    </p>
    <div class="mermaid">
stateDiagram-v2
    [*] --> ESCROW_PENDING: Taker matches Maker
    ESCROW_PENDING --> ESCROWED: Crypto locked in DB
    ESCROW_PENDING --> CANCELLED: Pre-escrow cancel
    ESCROWED --> PAYMENT_WINDOW_OPEN: 30-min timer starts
    ESCROWED --> CANCELLED: Cancel within window
    PAYMENT_WINDOW_OPEN --> PAYMENT_INITIATED: Taker marks payment sent
    PAYMENT_WINDOW_OPEN --> EXPIRED: 30 min elapsed
    PAYMENT_INITIATED --> PAYMENT_CONFIRMED: Maker confirms receipt
    PAYMENT_INITIATED --> DISPUTED: Either party opens dispute
    PAYMENT_CONFIRMED --> RELEASING: Begin settlement
    RELEASING --> RELEASED: Crypto transferred to buyer
    RELEASED --> [*]
    DISPUTED --> RESOLVED_MAKER: Crypto returns to seller
    DISPUTED --> RESOLVED_TAKER: Crypto released to buyer
    DISPUTED --> RESOLVED_REFUND: Split settlement
    EXPIRED --> REFUNDED: Crypto returns to seller
    CANCELLED --> [*]
    REFUNDED --> [*]
    </div>
  </section>

  <!-- MODULES -->
  <section class="block">
    <h3>Modules</h3>
    <p style="color: var(--text-muted); margin-bottom: 1rem;">
      Each module is fully self-contained with its own DTOs, service, controller, and Jest
      test suite. Click a module in the sidebar to jump to it.
    </p>
    {''.join(render_module(m) for m in MODULES)}
  </section>

  <!-- API -->
  <section class="block" id="api">
    <h3>API Endpoints Reference</h3>
    <p style="color: var(--text-muted); margin-bottom: 1rem;">
      All routes are throttled. JWT-authenticated routes require a Bearer token; CSRF-protected
      routes require the X-CSRF-Token header matching the csrf_token cookie.
    </p>
    {render_api_table()}
  </section>

  <!-- TESTS -->
  <section class="block" id="tests">
    <h3>Test Suite</h3>
    <p style="color: var(--text-muted); margin-bottom: 1rem;">
      {stats['test_files']} Jest test files, {stats['test_loc']:,} lines of test code, 122 passing tests
      across 8 suites. TypeScript strict mode + noImplicitAny + noUnusedLocals enforced.
    </p>
    <div class="stats-grid">
      <div class="stat-card"><div class="label">matching-engine.service.spec</div><div class="value">16 tests</div></div>
      <div class="stat-card"><div class="label">matching.utils.spec</div><div class="value">23 tests</div></div>
      <div class="stat-card"><div class="label">auth.service.spec</div><div class="value">21 tests</div></div>
      <div class="stat-card"><div class="label">wallet.service.spec</div><div class="value">15 tests</div></div>
      <div class="stat-card"><div class="label">kyc.service.spec</div><div class="value">14 tests</div></div>
      <div class="stat-card"><div class="label">dispute.service.spec</div><div class="value">14 tests</div></div>
      <div class="stat-card"><div class="label">payment.service.spec</div><div class="value">12 tests</div></div>
      <div class="stat-card"><div class="label">nbe-report.service.spec</div><div class="value">7 tests</div></div>
    </div>
  </section>

  <!-- SOURCE TREE -->
  <section class="block" id="tree">
    <h3>Source Tree</h3>
    <p style="color: var(--text-muted); margin-bottom: 1rem;">
      Click a folder to collapse/expand. The full source is embedded above in the module sections.
    </p>
    <div class="tree-viewer">
      <ul>
        {render_tree_node(tree)}
      </ul>
    </div>
  </section>

  <!-- SQL SCHEMA -->
  <section class="block" id="sql">
    <h3>Database Schema (0001_init.sql)</h3>
    <p style="color: var(--text-muted); margin-bottom: 1rem;">
      PostgreSQL schema with 13 tables, ACID CHECK constraints, encrypted PII columns,
      immutable audit trail, and Ethiopian payment provider enums.
    </p>
    {render_code_excerpt('src/database/migrations/0001_init.sql')}
  </section>

  <footer>
    <p>ETB/USD P2P Crypto Exchange — Backend Documentation</p>
    <p>Generated {generated_at} • {stats['total_loc']:,} total LOC • {stats['src_files']} source files • 122 passing tests</p>
    <p style="margin-top: 0.5rem; color: var(--text-dim);">
      Built with NestJS + TypeORM + PostgreSQL + Redis + Socket.io • Amharic + English i18n • Telebirr/M-PESA/CBE/Awash/Dashen integrations
    </p>
  </footer>

</main>

<script>
  // -----------------------------------------------------------------
  // Mermaid initialization
  // -----------------------------------------------------------------
  mermaid.initialize({{
    startOnLoad: true,
    theme: 'default',
    themeVariables: {{
      primaryColor: '#3b82f6',
      primaryTextColor: '#0f172a',
      primaryBorderColor: '#1e40af',
      lineColor: '#64748b',
      secondaryColor: '#e2e8f0',
      tertiaryColor: '#f1f5f9',
    }},
    flowchart: {{ curve: 'basis', useMaxWidth: true }},
    stateDiagram: {{ useMaxWidth: true }},
  }});

  // -----------------------------------------------------------------
  // Tree viewer — collapse/expand directories on click
  // -----------------------------------------------------------------
  document.querySelectorAll('.tree-viewer .tree-dir').forEach(dir => {{
    dir.addEventListener('click', (e) => {{
      e.stopPropagation();
      dir.classList.toggle('collapsed');
    }});
  }});

  // Start with node_modules-equivalent depth collapsed (top-3 levels expanded by default).
  document.querySelectorAll('.tree-viewer .tree-dir').forEach((dir, i) => {{
    // Collapse deep directories by default to keep the view manageable.
    const depth = (dir.dataset.path.match(/\\//g) || []).length;
    if (depth >= 3) dir.classList.add('collapsed');
  }});
</script>

</body>
</html>
'''

# Write the output file
OUTPUT_FILE.parent.mkdir(parents=True, exist_ok=True)
OUTPUT_FILE.write_text(html_content, encoding='utf-8')

print(f'✅ HTML documentation generated: {OUTPUT_FILE}')
print(f'   Size: {OUTPUT_FILE.stat().st_size / 1024:.1f} KB')
print(f'   Modules documented: {len(MODULES)}')
print(f'   API endpoints listed: {len(API_ENDPOINTS)}')
print(f'   Source LOC: {stats["src_loc"]:,}')
print(f'   Total LOC: {stats["total_loc"]:,}')
