#!/usr/bin/env python3
"""
Captures the rendered BirrEX website from the running Next.js dev server
and saves it as a single standalone HTML file with all CSS inlined.

Output: /home/z/my-project/download/birrex-website.html
"""
import re
import urllib.request
import os
from pathlib import Path

BASE = "http://localhost:3000"
OUTPUT = Path("/home/z/my-project/download/birrex-website.html")

# 1. Fetch the rendered HTML
print("Fetching rendered HTML from", BASE)
with urllib.request.urlopen(BASE) as r:
    html = r.read().decode("utf-8")
print(f"  Got {len(html):,} bytes of HTML")

# 2. Find all <link rel="stylesheet" href="..."> tags and inline their CSS
css_pattern = re.compile(r'<link rel="stylesheet" href="(/_next/[^"]+)"[^>]*/?>')
inlined_css_blocks = []

def fetch_css(match):
    href = match.group(1)
    url = BASE + href
    try:
        with urllib.request.urlopen(url) as r:
            css = r.read().decode("utf-8")
        print(f"  Inlined CSS: {href} ({len(css):,} bytes)")
        inlined_css_blocks.append(css)
        return ""  # remove the <link> tag
    except Exception as e:
        print(f"  WARNING: Could not fetch CSS {href}: {e}")
        return ""

html = css_pattern.sub(fetch_css, html)

# 3. Inject the inlined CSS into the <head>
all_css = "\n".join(inlined_css_blocks)
style_tag = f'<style id="inlined-css">\n{all_css}\n</style>'
html = html.replace("</head>", f"{style_tag}\n</head>", 1)

# 4. Remove all <script> tags — the SSR-rendered HTML has all the content;
#    scripts would only try to hydrate and fail in a standalone context.
script_pattern = re.compile(r'<script[^>]*>.*?</script>', re.DOTALL)
script_count = len(script_pattern.findall(html))
html = script_pattern.sub("", html)
print(f"  Removed {script_count} <script> tags")

# 5. Remove the Next.js dev overlay + error boundary cruft if present.
html = re.sub(r'<nextjs-portal[^>]*>.*?</nextjs-portal>', '', html, flags=re.DOTALL)
html = re.sub(r'<script[^>]*>', '', html)  # any leftover opening script tags
html = re.sub(r'</script>', '', html)      # any leftover closing script tags

# 6. Remove the "data-precedence" attribute and other React SSR hints that
#    would confuse a static browser render.
html = re.sub(r'\sdata-precedence="[^"]*"', '', html)

# 7. Add a small inline <script> at the end to re-enable the interactive
#    features we can simulate client-side (pair tab switching, buy/sell toggle,
#    mobile menu, ticker animation is pure CSS so it keeps working).
interactivity_script = """
<script>
// Minimal interactivity for the standalone HTML export.
document.addEventListener('DOMContentLoaded', function() {
  // Mobile menu toggle
  var menuBtn = document.querySelector('button[aria-label="Toggle menu"]');
  if (menuBtn) {
    menuBtn.addEventListener('click', function() {
      var nav = document.querySelector('.glass-strong.border-t');
      if (nav) nav.style.display = nav.style.display === 'none' || !nav.style.display ? 'block' : 'none';
    });
  }

  // Pair tabs (USD/ETB vs USDT/ETB) — visual toggle only
  document.querySelectorAll('[role="tab"]').forEach(function(tab) {
    tab.addEventListener('click', function() {
      var siblings = tab.parentNode.querySelectorAll('[role="tab"]');
      siblings.forEach(function(s) {
        s.removeAttribute('data-state');
        s.style.background = '';
        s.style.color = '';
      });
      tab.setAttribute('data-state', 'active');
      tab.style.background = 'var(--primary)';
      tab.style.color = 'var(--primary-foreground)';
    });
  });

  // Buy/Sell toggle on P2P + hero card — visual only
  document.querySelectorAll('button').forEach(function(btn) {
    var txt = (btn.textContent || '').trim();
    if (txt === 'Buy' || txt === 'Sell' || txt === 'BUY' || txt === 'SELL'
        || txt === 'Buy USD' || txt === 'Sell USD') {
      btn.addEventListener('click', function(e) {
        // Just visual feedback — a quick opacity flash
        e.preventDefault();
        btn.style.opacity = '0.7';
        setTimeout(function() { btn.style.opacity = '1'; }, 150);
      });
    }
  });

  // Smooth scroll for anchor links
  document.querySelectorAll('a[href^="#"]').forEach(function(a) {
    a.addEventListener('click', function(e) {
      var href = a.getAttribute('href');
      if (href.length > 1) {
        var target = document.querySelector(href);
        if (target) {
          e.preventDefault();
          target.scrollIntoView({ behavior: 'smooth' });
        }
      }
    });
  });

  console.log('%c BirrEX standalone HTML loaded ', 'background: #F0B90B; color: #0f172a; font-weight: bold; padding: 4px 8px; border-radius: 4px;');
});
</script>
"""
html = html.replace("</body>", f"{interactivity_script}\n</body>", 1)

# 8. Update the <title> to make it clear this is the standalone export
html = html.replace(
    "<title>BirrEX",
    '<meta name="generator" content="BirrEX Standalone HTML Export">\\n<title>BirrEX',
    1,
)

# 9. Write the final standalone HTML
OUTPUT.parent.mkdir(parents=True, exist_ok=True)
OUTPUT.write_text(html, encoding="utf-8")

size_kb = OUTPUT.stat().st_size / 1024
print(f"\\n✅ Standalone HTML saved: {OUTPUT}")
print(f"   Size: {size_kb:.1f} KB")
print(f"   CSS inlined: {len(inlined_css_blocks)} stylesheet(s)")
print(f"   Open in any browser — no server required.")
