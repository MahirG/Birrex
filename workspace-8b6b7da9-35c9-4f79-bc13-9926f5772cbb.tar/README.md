# ETB/USD P2P Crypto Exchange — Backend

A production-grade P2P crypto/fiat exchange for the Ethiopian Birr (ETB) and
US Dollar (USD) market. Built with NestJS + TypeORM + PostgreSQL + Redis.

> **Status**: Phase 1 — Matching Engine & Orderbook (delivered).
> Phases 2+ (Auth, KYC, Disputes, Payments, NBE Compliance) are scaffolded
> in the schema and module map but not yet implemented.

## What's in Phase 1

- **Database schema** (`src/database/migrations/0001_init.sql`)
  - `users`, `wallets`, `wallet_transactions`, `payment_methods`,
    `orders`, `trades`, `disputes`, `dispute_evidence`, `trade_messages`,
    `notifications`, `audit_logs`
  - ACID CHECK constraints, immutable ledger, encrypted PII columns,
    Ethiopian payment provider enums.
- **TypeORM entities** with strict TypeScript (zero `any`)
  - `src/database/entities/*.entity.ts`
- **Orderbook Service** — Redis sorted sets + atomic Lua scripts
  - `src/modules/orderbook/orderbook.service.ts`
  - Two books per pair (sell ASC by price, buy DESC by price), FIFO tiebreak.
- **Escrow Service** — atomic wallet state machine
  - `src/modules/escrow/escrow.service.ts`
  - SERIALIZABLE Postgres transactions with `SELECT FOR UPDATE` on wallets.
  - Defends against double-spend via DB CHECK constraints.
- **Matching Engine** — price-time priority, race-condition safe
  - `src/modules/matching-engine/matching-engine.service.ts`
  - Per-pair distributed lock via Redis SET NX.
  - Self-match prevention, partial fills, MARKET order support.
- **WebSocket Gateway** — Socket.io + Redis adapter
  - `src/modules/websocket/websocket.gateway.ts`
  - `src/modules/websocket/realtime.broadcaster.ts`
  - Pub/sub fan-out so any instance can emit events to any user.
- **i18n** — full Amharic (Ge'ez script) + English translations
  - `src/modules/i18n/i18n.service.ts`
- **Jest unit tests** — 16 matching-engine specs + 6 utility specs
  - `src/modules/matching-engine/__tests__/matching-engine.service.spec.ts`
  - `src/modules/matching-engine/__tests__/matching.utils.spec.ts`

## Quickstart

```bash
# 1. Spin up Postgres + Redis + MinIO
docker-compose up -d

# 2. Configure env
cp .env.example .env
# Edit .env — at minimum set POSTGRES_PASSWORD, JWT_ACCESS_SECRET, JWT_REFRESH_SECRET

# 3. Install + migrate
npm install
npm run migration:run

# 4. Run
npm run start:dev   # API on http://localhost:3000

# 5. Test
npm test            # Jest unit tests
npm run typecheck   # tsc --noEmit
```

## API Surface (Phase 1)

| Method | Path                                 | Auth | Description                                |
| ------ | ------------------------------------ | ---- | ------------------------------------------ |
| POST   | `/api/v1/orders`                     | JWT  | Place a new order (LIMIT or MARKET)        |
| DELETE | `/api/v1/orders/:orderId`            | JWT  | Cancel an OPEN / PARTIALLY_FILLED order    |
| GET    | `/api/v1/orders/orderbook/:pair`     | JWT  | Get L2 orderbook snapshot (50 levels/side) |
| GET    | `/api/v1/orders/top-of-book/:pair`   | JWT  | Get best bid + best ask + spread           |

WebSocket namespace: `/exchange`
- Subscribe to `subscribe:pair` with `{pair: 'USD_ETB'}` for orderbook updates.
- User-private events auto-delivered to room `user:<id>` after JWT handshake.

## Financial Invariants (Defended)

1. **No double-spend** — `wallets.available_balance + locked_balance >= 0` enforced by DB CHECK.
2. **Atomic escrow** — `lockEscrow()` runs in SERIALIZABLE isolation with row locks on both the order and the wallet.
3. **No self-match** — matching engine skips makers belonging to the same user.
4. **No partial fill on cancel** — cancel acquires a pessimistic_write lock on the order row.
5. **Atomic book updates** — Redis Lua scripts update sorted set + metadata hash in one shot.
6. **Idempotent recovery** — Redis peek is non-destructive; if the engine crashes between peek and DB commit, the maker stays on the book.

## Decimal Arithmetic

All financial math uses **BigInt-backed decimal strings** to avoid float64 drift.
See `src/utils/matching.utils.ts` for `addDecimal`, `subtractDecimal`,
`multiplyDecimal`, `lessThan` — all preserve up to 8 fractional digits and
correctly handle the full NUMERIC(20,8) range.

## What's NOT in Phase 1 (intentionally)

- Authentication endpoints (login, register, refresh, 2FA setup) — Phase 2
- KYC submission/review workflow — Phase 2
- Dispute ticketing + moderator queue — Phase 2
- Telebirr/M-PESA/CBE/Awash/Dashen API integrations — Phase 2
- NBE compliance reporting — Phase 2
- Next.js frontend — Phase 3

## License

UNLICENSED — Proprietary. All rights reserved.
