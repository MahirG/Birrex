# P2P ETB/USD Exchange — Architecture

```mermaid
graph TB
    subgraph "Client Layer"
        WEB[Next.js Web App<br/>React + Tailwind + Zustand]
        MOB[Mobile App<br/>Future]
    end

    subgraph "Edge"
        LB[Nginx / Load Balancer<br/>Sticky WS sessions]
    end

    subgraph "Application Layer — NestJS Stateless Instances"
        API1[API Instance 1]
        API2[API Instance 2]
        APIN[API Instance N]
    end

    subgraph "Core Domain Services"
        AUTH[Auth Service<br/>JWT + 2FA TOTP]
        MATCH[MatchingEngineService<br/>Price-Time Priority]
        ORDERBOOK[OrderbookService<br/>Redis Sorted Sets + Lua]
        ESCROW[EscrowService<br/>SERIALIZABLE Tx + Wallet Lock]
        WS[ExchangeGateway<br/>Socket.io + Redis Adapter]
        BROADCAST[RealtimeBroadcaster<br/>Redis Pub/Sub]
        DISPUTE[Dispute Module<br/>Phase 2 — Moderation Queue]
        KYC[KYC Module<br/>Phase 2 — Ethiopian ID/Passport]
        NBE[NBE Compliance<br/>Phase 2 — Daily Reporting]
    end

    subgraph "Payment Integrations (Phase 2)"
        TELEBIRR[Telebirr API]
        MPESA[M-PESA API]
        CBE[CBE Bank API]
        AWASH[Awash Bank API]
        DASHEN[Dashen Bank API]
    end

    subgraph "Data Layer"
        PG[(PostgreSQL 16<br/>ACID — Users/Orders/Trades/Wallets/Ledger)]
        REDIS[(Redis 7<br/>Orderbook + Sessions + RateLimit + PubSub)]
        S3[(S3 / MinIO<br/>KYC + Dispute Screenshots)]
    end

    WEB --> LB
    MOB --> LB
    LB --> API1
    LB --> API2
    LB --> APIN

    API1 --> AUTH
    API1 --> MATCH
    API1 --> ESCROW
    API1 --> DISPUTE
    API1 --> KYC
    API1 --> NBE

    MATCH --> ORDERBOOK
    MATCH --> ESCROW
    MATCH --> BROADCAST
    ESCROW --> BROADCAST
    BROADCAST --> WS

    API1 --> PG
    API1 --> REDIS
    MATCH --> REDIS
    ORDERBOOK --> REDIS
    WS --> REDIS
    BROADCAST --> REDIS

    ESCROW --> TELEBIRR
    ESCROW --> MPESA
    ESCROW --> CBE
    ESCROW --> AWASH
    ESCROW --> DASHEN

    KYC --> S3
    DISPUTE --> S3
```

## Request Flow — Order Placement

```mermaid
sequenceDiagram
    participant U as User (REST)
    participant C as MatchingEngineController
    participant M as MatchingEngineService
    participant O as OrderbookService (Redis)
    participant E as EscrowService (Postgres)
    participant B as RealtimeBroadcaster
    participant W as WebSocketGateway

    U->>C: POST /api/v1/orders<br/>{pair, side, price, qty}
    C->>M: placeOrder(params)
    M->>M: validateUserForTrading()
    M->>M: validateOrderBusinessRules()
    M->>M: INSERT order (OPEN)
    M->>O: SET lock:pair-match:USD_ETB NX
    M->>O: peekMatchableMakers(pair, side, price)
    O-->>M: [maker1, maker2, ...]

    loop For each matchable maker
        M->>E: lockEscrow() [SERIALIZABLE tx]
        E->>E: SELECT maker_order FOR UPDATE
        E->>E: SELECT seller_wallet FOR UPDATE
        E->>E: MOVE available → locked
        E->>E: INSERT trade (ESCROWED)
        E->>E: INSERT wallet_transaction (ledger)
        E->>E: UPDATE maker_order.filled_quantity
        E-->>M: { trade, walletTx }
        M->>O: updateRemainingQuantity() OR removeMakerOrder()
        M->>B: emitTradeCreated(maker, taker, payload)
        B->>B: PUBLISH etb:realtime
        B->>W: (cross-instance adapter) deliver locally
        W-->>U: socket emit 'trade:created'
    end

    alt Remaining qty > 0 AND LIMIT order
        M->>O: addMakerOrder(remaining)
        M->>B: emitOrderbookUpdate()
    end

    M->>B: emitOrderPlaced(taker, payload)
    M->>O: DEL lock:pair-match:USD_ETB
    M-->>C: PlaceOrderResult
    C-->>U: 201 Created
```

## Trade State Machine

```mermaid
stateDiagram-v2
    [*] --> ESCROW_PENDING: Taker matches Maker
    ESCROW_PENDING --> ESCROWED: Crypto locked in DB
    ESCROW_PENDING --> CANCELLED: Pre-escrow cancel
    ESCROWED --> PAYMENT_WINDOW_OPEN: 30-min timer starts
    ESCROWED --> CANCELLED: Cancel within window
    PAYMENT_WINDOW_OPEN --> PAYMENT_INITIATED: Taker marks payment sent
    PAYMENT_WINDOW_OPEN --> EXPIRED: 30 min elapsed
    PAYMENT_INITIATED --> PAYMENT_CONFIRMED: Maker confirms receipt
    PAYMENT_INITIATED --> DISPUTED: Either party opens dispute
    PAYMENT_CONFIRMED --> RELEASING: Begin settlement
    RELEASING --> RELEASED: Crypto transferred to buyer
    RELEASED --> [*]
    DISPUTED --> RESOLVED_MAKER: Crypto returns to seller
    DISPUTED --> RESOLVED_TAKER: Crypto released to buyer
    DISPUTED --> RESOLVED_REFUND: Split settlement
    EXPIRED --> REFUNDED: Crypto returns to seller
    CANCELLED --> [*]
    REFUNDED --> [*]
```

## Module Map

| Module                  | Purpose                                                    | Status   |
| ----------------------- | ---------------------------------------------------------- | -------- |
| `I18nModule`            | Amharic + English translations                            | ✅ Phase 1 |
| `OrderbookModule`       | Redis sorted-set book + atomic Lua scripts                | ✅ Phase 1 |
| `EscrowModule`          | SERIALIZABLE wallet state machine                         | ✅ Phase 1 |
| `WebSocketModule`       | Socket.io gateway + Redis pub/sub broadcaster             | ✅ Phase 1 |
| `MatchingEngineModule`  | Price-time priority matching + race-condition safety      | ✅ Phase 1 |
| `AuthModule`            | JWT, refresh tokens, 2FA TOTP, anti-CSRF                  | 🔜 Phase 2 |
| `UsersModule`           | Registration, profile, password reset                     | 🔜 Phase 2 |
| `WalletsModule`         | Deposits/withdrawals, ledger queries                       | 🔜 Phase 2 |
| `PaymentsModule`        | Telebirr/M-PESA/CBE/Awash/Dashen integrations              | 🔜 Phase 2 |
| `DisputesModule`        | Ticketing + moderator queue + screenshot uploads           | 🔜 Phase 2 |
| `KycModule`             | Ethiopian ID/Passport submission + reviewer queue          | 🔜 Phase 2 |
| `NbeComplianceModule`   | Daily NBE reporting + suspicious-transaction flags          | 🔜 Phase 2 |
| `NotificationsModule`   | In-app + email + Telegram push                             | 🔜 Phase 2 |
| `AdminModule`           | Admin/Moderator dashboard APIs                             | 🔜 Phase 2 |

## Horizontal Scaling Notes

- **Stateless API instances**: No in-memory state. Multiple NestJS instances can run concurrently.
- **Redis as the shared book**: All orderbook state lives in Redis, not in process memory.
- **Socket.io Redis adapter**: Cross-instance room membership replication so events emit from any instance reach all subscribers.
- **Redis pub/sub channel** (`etb:realtime`): Application-level event bus on top of Socket.io for clean traceId propagation.
- **Per-pair distributed lock**: Serializes matching passes per pair (not globally) so USD_ETB and USDT_ETB can match concurrently.
- **PostgreSQL SERIALIZABLE**: The last line of defense against double-spend. Even if every other guard fails, the DB transaction will reject concurrent escrow locks on the same wallet.

## Running Locally

```bash
# 1. Start Postgres + Redis + MinIO
docker-compose up -d

# 2. Copy env and edit secrets
cp .env.example .env
# Generate RSA keys:
openssl genpkey -algorithm RSA -out rsa_private.pem -pkeyopt rsa_keygen_bits:2048
openssl rsa -in rsa_private.pem -pubout -out rsa_public.pem
# Reference their paths in .env

# 3. Install deps and run migrations
npm install
npm run migration:run

# 4. Start the API in dev mode
npm run start:dev

# 5. Run unit tests
npm test
```
