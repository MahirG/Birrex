import { Injectable, Logger } from '@nestjs/common';
import { DataSource, EntityManager } from 'typeorm';
import { v4 as uuid } from 'uuid';
import {
  Wallet,
  WalletTransaction,
  Trade,
  TradeStatus,
  Order,
  OrderStatus,
  OrderSide,
  WalletCurrency,
  TransactionType,
  TransactionStatus,
} from '../../database/entities';
import { BusinessException, ErrorCode } from '../../common/exceptions/business.exception';
import {
  subtractDecimal,
  addDecimal,
  multiplyDecimal,
  formatTradeNumber,
} from '../../utils/matching.utils';
import type { MatchedTrade } from '../../types/orderbook.types';
import { getEnv } from '../../config';

/**
 * Converts a decimal string to a BigInt at the given scale.
 * Used internally by compare() / lt() / eq() — same semantics as the
 * toScaledBigInt helper in matching.utils, kept private to avoid coupling
 * the escrow module's internal numeric comparisons to the public utils API.
 */
function toScaledBigIntSafe(s: string, scale: number): bigint {
  const negative = s.startsWith('-');
  const abs = negative ? s.slice(1) : s;
  const dotIdx = abs.indexOf('.');
  const intPart = dotIdx === -1 ? abs : abs.slice(0, dotIdx);
  const fracPart = dotIdx === -1 ? '' : abs.slice(dotIdx + 1);
  const paddedFrac = fracPart.padEnd(scale, '0').slice(0, scale);
  const combined = (intPart || '0') + paddedFrac;
  const big = BigInt(combined || '0');
  return negative ? -big : big;
}

/**
 * EscrowService — the atomic state machine for trade settlement.
 *
 * Every method here runs inside a single Postgres SERIALIZABLE transaction.
 * Why SERIALIZABLE?
 *   - READ COMMITTED allows phantoms → double-spend possible if two trades
 *     settle the same wallet concurrently.
 *   - REPEATABLE READ allows write skew → could oversell locked balance.
 *   - SERIALIZABLE is the only level that gives us true ACID guarantees for
 *     the (available, locked) wallet state machine.
 *
 * Trade-off: SERIALIZABLE may abort-and-retry on contention. For our scale
 * (one user has at most a few concurrent trades), this is the right call.
 * If contention ever becomes a problem we can:
 *   (a) use SELECT ... FOR UPDATE on the wallet row instead, or
 *   (b) shard wallets by user_id (already the case) to reduce contention.
 *
 * Every method that mutates the wallet also writes a row to
 * wallet_transactions with before/after snapshots. This is the immutable
 * audit trail that NBE compliance reports are built from.
 */
@Injectable()
export class EscrowService {
  private readonly logger = new Logger(EscrowService.name);

  constructor(private readonly dataSource: DataSource) {}

  // ===========================================================================
  // ESCROW LOCK — called by the matching engine immediately after a match.
  // ===========================================================================

  /**
   * Atomically:
   *   1. Validates the maker's wallet has enough crypto to cover the trade.
   *   2. Moves crypto from maker.available → maker.locked (escrow).
   *   3. Inserts the Trade row in ESCROWED state.
   *   4. Inserts a WalletTransaction row (TRADE_LOCK) for the audit trail.
   *   5. Updates the maker order's filled_quantity.
   *
   * Returns the freshly-created Trade. If anything fails, the entire
   * transaction rolls back and the maker order is left untouched.
   *
   * Financial invariant defended here:
   *   - The DB-level CHECK constraint (available + locked >= 0) makes
   *     double-spend impossible EVEN IF the application has a bug.
   */
  async lockEscrow(params: {
    makerOrderId: string;
    takerOrderId: string;
    makerUserId: string;
    takerUserId: string;
    pair: string;
    takerSide: OrderSide;
    price: string;
    quantity: string;
    paymentMethodId?: string | null;
    paymentWindowMinutes: number;
    tradeNumberDailyCounter: number;
  }): Promise<{ trade: Trade; walletTx: WalletTransaction }> {
    return this.dataSource.transaction(
      'SERIALIZABLE',
      async (manager: EntityManager) => {
        const env = getEnv();

        // ---- 1. Load maker order (FOR UPDATE to prevent concurrent fills) ----
        const makerOrder = await manager.findOne(Order, {
          where: { id: params.makerOrderId },
          lock: { mode: 'pessimistic_write' },
        });
        if (!makerOrder) {
          throw new BusinessException(
            ErrorCode.ORDER_NOT_FOUND,
            `Maker order ${params.makerOrderId} not found`,
          );
        }
        if (makerOrder.status === OrderStatus.FILLED || makerOrder.status === OrderStatus.CANCELLED) {
          throw new BusinessException(
            ErrorCode.ORDER_NOT_CANCELLABLE,
            `Maker order ${makerOrder.id} is ${makerOrder.status} and cannot accept more matches`,
          );
        }

        // ---- 2. Determine the SELL side's wallet + currency ----
        // The SELLER is the one whose crypto gets locked.
        //   - If takerSide == BUY  → taker buys, maker sells. Maker is seller.
        //   - If takerSide == SELL → taker sells, maker buys. Taker is seller.
        const sellerUserId = params.takerSide === OrderSide.BUY ? params.makerUserId : params.takerUserId;
        const baseCurrency = this.baseCurrencyOfPair(params.pair);

        // ---- 3. Load the seller's wallet with a row lock ----
        const sellerWallet = await manager
          .createQueryBuilder(Wallet, 'w')
          .setLock('pessimistic_write')
          .where('w.user_id = :uid', { uid: sellerUserId })
          .andWhere('w.currency = :cur', { cur: baseCurrency })
          .getOne();

        if (!sellerWallet) {
          throw new BusinessException(
            ErrorCode.WALLET_NOT_FOUND,
            `Seller ${sellerUserId} has no ${baseCurrency} wallet`,
          );
        }

        // ---- 4. Compute amounts (crypto quantity + fee) ----
        const feeBps = params.takerSide === OrderSide.BUY ? env.MAKER_FEE_BPS : env.TAKER_FEE_BPS;
        const feeAmount = this.computeFee(params.quantity, feeBps);
        const cryptoToLock = addDecimal(params.quantity, feeAmount);

        if (this.lt(sellerWallet.availableBalance, cryptoToLock)) {
          throw new BusinessException(
            ErrorCode.INSUFFICIENT_BALANCE,
            `Seller wallet ${sellerWallet.id} has ${sellerWallet.availableBalance} ${baseCurrency} but trade requires ${cryptoToLock} (qty + ${feeBps}bps fee)`,
            { available: sellerWallet.availableBalance, required: cryptoToLock },
          );
        }

        // ---- 5. Move crypto from available → locked ----
        const newAvailable = subtractDecimal(sellerWallet.availableBalance, cryptoToLock);
        const newLocked = addDecimal(sellerWallet.lockedBalance, cryptoToLock);

        sellerWallet.availableBalance = newAvailable;
        sellerWallet.lockedBalance = newLocked;
        await manager.save(sellerWallet);

        // ---- 6. Insert Trade row in ESCROWED state ----
        const now = new Date();
        const tradeNumber = formatTradeNumber(now, params.tradeNumberDailyCounter);
        const expiresAt = new Date(now.getTime() + params.paymentWindowMinutes * 60_000);

        const trade = manager.create(Trade, {
          tradeNumber,
          makerOrderId: params.makerOrderId,
          takerOrderId: params.takerOrderId,
          makerUserId: params.makerUserId,
          takerUserId: params.takerUserId,
          pair: params.pair,
          side: params.takerSide,
          price: params.price,
          quantity: params.quantity,
          escrowWalletId: sellerWallet.id,
          cryptoLockedAmount: cryptoToLock,
          paymentMethodId: params.paymentMethodId ?? null,
          paymentWindowMinutes: params.paymentWindowMinutes,
          paymentWindowExpiresAt: expiresAt,
          status: TradeStatus.ESCROWED,
          makerFee: params.takerSide === OrderSide.BUY ? feeAmount : '0',
          takerFee: params.takerSide === OrderSide.SELL ? feeAmount : '0',
        });
        const savedTrade = await manager.save(trade);

        // ---- 7. Insert WalletTransaction ledger entry ----
        const walletTx = manager.create(WalletTransaction, {
          walletId: sellerWallet.id,
          relatedTradeId: savedTrade.id,
          type: TransactionType.TRADE_LOCK,
          status: TransactionStatus.COMPLETED,
          amount: '-' + cryptoToLock,                       // debit (signed)
          balanceBefore: sellerWallet.availableBalance,    // post-update snapshot is wrong here; corrected below
          balanceAfter: newAvailable,
          reference: this.generateTxnReference(),
          description: `Escrow lock for trade ${tradeNumber}`,
          completedAt: now,
        });
        // Re-capture the actual BEFORE snapshot:
        walletTx.balanceBefore = subtractDecimal(newAvailable, '-' + cryptoToLock) ===
          sellerWallet.availableBalance
          ? subtractDecimal(newAvailable, cryptoToLock)
          : sellerWallet.availableBalance;
        // Simpler and unambiguous: balanceBefore is what it WAS before this delta:
        walletTx.balanceBefore = addDecimal(newAvailable, cryptoToLock);
        await manager.save(walletTx);

        // ---- 8. Update maker order's filled_quantity ----
        const newFilledQty = addDecimal(makerOrder.filledQuantity, params.quantity);
        makerOrder.filledQuantity = newFilledQty;
        if (this.lte(newFilledQty, makerOrder.quantity)) {
          makerOrder.status = this.eq(newFilledQty, makerOrder.quantity)
            ? OrderStatus.FILLED
            : OrderStatus.PARTIALLY_FILLED;
          if (makerOrder.status === OrderStatus.FILLED) {
            makerOrder.filledAt = now;
          }
        }
        await manager.save(makerOrder);

        this.logger.log(
          `Escrow locked: trade ${tradeNumber} | ${params.quantity} ${baseCurrency} ` +
            `from user ${sellerUserId} | wallet ${sellerWallet.id} ` +
            `(available ${newAvailable}, locked ${newLocked})`,
        );

        return { trade: savedTrade, walletTx };
      },
    );
  }

  // ===========================================================================
  // ESCROW RELEASE — called by the trade controller after the maker confirms
  // receipt of fiat payment.
  // ===========================================================================

  /**
   * Atomically:
   *   1. Validates the trade is in PAYMENT_CONFIRMED state.
   *   2. Loads the escrowed wallet (seller's wallet) with a row lock.
   *   3. Moves crypto from seller.locked → buyer.available.
   *   4. Marks the trade as RELEASED.
   *   5. Writes two WalletTransaction rows (TRADE_RELEASE on both sides).
   *
   * This is the terminal success state — once released, the trade is final.
   */
  async releaseEscrow(tradeId: string): Promise<Trade> {
    return this.dataSource.transaction(
      'SERIALIZABLE',
      async (manager: EntityManager) => {
        const trade = await manager.findOne(Trade, {
          where: { id: tradeId },
          lock: { mode: 'pessimistic_write' },
        });
        if (!trade) {
          throw new BusinessException(ErrorCode.TRADE_NOT_FOUND, `Trade ${tradeId} not found`);
        }
        if (trade.status !== TradeStatus.PAYMENT_CONFIRMED) {
          throw new BusinessException(
            ErrorCode.INVALID_TRADE_STATE_TRANSITION,
            `Trade ${trade.tradeNumber} is ${trade.status}; can only release from PAYMENT_CONFIRMED`,
            { current: trade.status, expected: TradeStatus.PAYMENT_CONFIRMED },
          );
        }

        const baseCurrency = this.baseCurrencyOfPair(trade.pair);
        const sellerUserId = trade.side === OrderSide.BUY ? trade.makerUserId : trade.takerUserId;
        const buyerUserId = trade.side === OrderSide.BUY ? trade.takerUserId : trade.makerUserId;

        // ---- Lock seller wallet (escrow source) ----
        const sellerWallet = await manager
          .createQueryBuilder(Wallet, 'w')
          .setLock('pessimistic_write')
          .where('w.user_id = :uid', { uid: sellerUserId })
          .andWhere('w.currency = :cur', { cur: baseCurrency })
          .getOne();
        if (!sellerWallet) {
          throw new BusinessException(
            ErrorCode.WALLET_NOT_FOUND,
            `Seller wallet ${sellerUserId}/${baseCurrency} vanished mid-release`,
          );
        }

        // ---- Lock buyer wallet (settlement target) ----
        let buyerWallet = await manager
          .createQueryBuilder(Wallet, 'w')
          .setLock('pessimistic_write')
          .where('w.user_id = :uid', { uid: buyerUserId })
          .andWhere('w.currency = :cur', { cur: baseCurrency })
          .getOne();
        if (!buyerWallet) {
          // Auto-create buyer wallet (idempotent)
          buyerWallet = manager.create(Wallet, {
            userId: buyerUserId,
            currency: baseCurrency,
            availableBalance: '0',
            lockedBalance: '0',
            pendingBalance: '0',
          });
          buyerWallet = await manager.save(buyerWallet);
        }

        // ---- Validate locked balance covers the trade ----
        if (this.lt(sellerWallet.lockedBalance, trade.cryptoLockedAmount)) {
          throw new BusinessException(
            ErrorCode.ESCROW_RELEASE_FAILED,
            `Seller wallet ${sellerWallet.id} locked ${sellerWallet.lockedBalance} < trade amount ${trade.cryptoLockedAmount}`,
          );
        }

        // ---- Compute net amounts ----
        // Buyer receives the trade quantity (NOT including the fee — the fee
        // was charged on top of the quantity at lock time and is now revenue).
        const buyerCredit = trade.quantity;
        // Seller's locked balance decreases by the FULL locked amount (qty + fee).
        const sellerDebit = trade.cryptoLockedAmount;

        // ---- Move the money ----
        const newSellerLocked = subtractDecimal(sellerWallet.lockedBalance, sellerDebit);
        const newBuyerAvailable = addDecimal(buyerWallet.availableBalance, buyerCredit);

        sellerWallet.lockedBalance = newSellerLocked;
        buyerWallet.availableBalance = newBuyerAvailable;
        await manager.save([sellerWallet, buyerWallet]);

        // ---- Write ledger entries (one debit, one credit) ----
        const sellerTxn = manager.create(WalletTransaction, {
          walletId: sellerWallet.id,
          relatedTradeId: trade.id,
          type: TransactionType.TRADE_RELEASE,
          status: TransactionStatus.COMPLETED,
          amount: '-' + sellerDebit,
          balanceBefore: addDecimal(newSellerLocked, sellerDebit),
          balanceAfter: newSellerLocked,
          reference: this.generateTxnReference(),
          description: `Escrow release (debit) for trade ${trade.tradeNumber}`,
          completedAt: new Date(),
        });
        const buyerTxn = manager.create(WalletTransaction, {
          walletId: buyerWallet.id,
          relatedTradeId: trade.id,
          type: TransactionType.TRADE_RELEASE,
          status: TransactionStatus.COMPLETED,
          amount: buyerCredit,
          balanceBefore: subtractDecimal(newBuyerAvailable, buyerCredit),
          balanceAfter: newBuyerAvailable,
          reference: this.generateTxnReference(),
          description: `Escrow release (credit) for trade ${trade.tradeNumber}`,
          completedAt: new Date(),
        });
        await manager.save([sellerTxn, buyerTxn]);

        // ---- Mark trade as RELEASED ----
        trade.status = TradeStatus.RELEASING;
        await manager.save(trade);
        trade.status = TradeStatus.RELEASED;
        trade.completedAt = new Date();
        const finalTrade = await manager.save(trade);

        this.logger.log(
          `Escrow released: trade ${trade.tradeNumber} | ${buyerCredit} ${baseCurrency} ` +
            `from user ${sellerUserId} → user ${buyerUserId}`,
        );
        return finalTrade;
      },
    );
  }

  // ===========================================================================
  // ESCROW REFUND — called when a trade is cancelled pre-escrow, OR when a
  // dispute resolves in favor of the seller (crypto returns to seller).
  // ===========================================================================

  /**
   * Returns the full escrowed amount to the seller. Used when:
   *   - Payment window expired with no payment (taker defaulted).
   *   - Dispute resolved in seller's favor.
   *   - Admin force-cancels an active trade.
   *
   * The trade MUST already be in ESCROWED, PAYMENT_WINDOW_OPEN,
   * PAYMENT_INITIATED, DISPUTED, or EXPIRED state.
   */
  async refundEscrow(tradeId: string, reason: string): Promise<Trade> {
    return this.dataSource.transaction(
      'SERIALIZABLE',
      async (manager: EntityManager) => {
        const trade = await manager.findOne(Trade, {
          where: { id: tradeId },
          lock: { mode: 'pessimistic_write' },
        });
        if (!trade) {
          throw new BusinessException(ErrorCode.TRADE_NOT_FOUND, `Trade ${tradeId} not found`);
        }

        const allowedStates: TradeStatus[] = [
          TradeStatus.ESCROWED,
          TradeStatus.PAYMENT_WINDOW_OPEN,
          TradeStatus.PAYMENT_INITIATED,
          TradeStatus.DISPUTED,
          TradeStatus.EXPIRED,
        ];
        if (!allowedStates.includes(trade.status)) {
          throw new BusinessException(
            ErrorCode.INVALID_TRADE_STATE_TRANSITION,
            `Trade ${trade.tradeNumber} is ${trade.status}; cannot refund`,
            { current: trade.status, allowed: allowedStates },
          );
        }

        const baseCurrency = this.baseCurrencyOfPair(trade.pair);
        const sellerUserId = trade.side === OrderSide.BUY ? trade.makerUserId : trade.takerUserId;

        const sellerWallet = await manager
          .createQueryBuilder(Wallet, 'w')
          .setLock('pessimistic_write')
          .where('w.user_id = :uid', { uid: sellerUserId })
          .andWhere('w.currency = :cur', { cur: baseCurrency })
          .getOne();
        if (!sellerWallet) {
          throw new BusinessException(
            ErrorCode.WALLET_NOT_FOUND,
            `Seller wallet vanished during refund`,
          );
        }

        if (this.lt(sellerWallet.lockedBalance, trade.cryptoLockedAmount)) {
          throw new BusinessException(
            ErrorCode.ESCROW_RELEASE_FAILED,
            `Locked balance insufficient for refund`,
          );
        }

        const newLocked = subtractDecimal(sellerWallet.lockedBalance, trade.cryptoLockedAmount);
        const newAvailable = addDecimal(sellerWallet.availableBalance, trade.cryptoLockedAmount);

        sellerWallet.lockedBalance = newLocked;
        sellerWallet.availableBalance = newAvailable;
        await manager.save(sellerWallet);

        const txn = manager.create(WalletTransaction, {
          walletId: sellerWallet.id,
          relatedTradeId: trade.id,
          type: TransactionType.TRADE_REFUND,
          status: TransactionStatus.COMPLETED,
          amount: trade.cryptoLockedAmount,                // credit
          balanceBefore: subtractDecimal(newAvailable, trade.cryptoLockedAmount),
          balanceAfter: newAvailable,
          reference: this.generateTxnReference(),
          description: `Escrow refund for trade ${trade.tradeNumber}: ${reason}`,
          completedAt: new Date(),
        });
        await manager.save(txn);

        trade.status = TradeStatus.REFUNDED;
        trade.completedAt = new Date();
        trade.cancelReason = reason;
        const finalTrade = await manager.save(trade);

        this.logger.log(
          `Escrow refunded: trade ${trade.tradeNumber} | ${trade.cryptoLockedAmount} ${baseCurrency} ` +
            `returned to user ${sellerUserId} | reason: ${reason}`,
        );
        return finalTrade;
      },
    );
  }

  // ===========================================================================
  // HELPERS
  // ===========================================================================

  private baseCurrencyOfPair(pair: string): WalletCurrency {
    switch (pair) {
      case 'USD_ETB':  return WalletCurrency.USD;
      case 'USDT_ETB': return WalletCurrency.USDT;
      default:
        throw new BusinessException(
          ErrorCode.INVALID_PAIR,
          `Unknown pair ${pair}`,
        );
    }
  }

  private computeFee(quantity: string, feeBps: number): string {
    if (feeBps === 0) return '0';
    // fee = quantity * feeBps / 10000
    const numerator = multiplyDecimal(quantity, String(feeBps));
    return this.divideBy10000(numerator);
  }

  private divideBy10000(decimal: string): string {
    const parts = decimal.split('.');
    const intPart = parts[0] ?? '0';
    const fracPart = parts[1] ?? '';
    const combined = intPart + fracPart;
    // We need to divide by 10000 → shift decimal point left by 4.
    // Pad with zeros if combined length < 4.
    const padded = combined.padStart(4, '0');
    const newInt = padded.slice(0, -4) || '0';
    const newFrac = padded.slice(-4) + '';
    // Trim trailing zeros in fractional part
    const trimmedFrac = newFrac.replace(/0+$/, '');
    return trimmedFrac.length === 0 ? newInt : `${newInt}.${trimmedFrac}`;
  }

  private lt(a: string, b: string): boolean {
    return this.compare(a, b) < 0;
  }
  private lte(a: string, b: string): boolean {
    return this.compare(a, b) <= 0;
  }
  private eq(a: string, b: string): boolean {
    return this.compare(a, b) === 0;
  }

  private compare(a: string, b: string): number {
    const aScale = (a.split('.')[1] ?? '').length;
    const bScale = (b.split('.')[1] ?? '').length;
    const scale = Math.max(aScale, bScale);
    const aBig = toScaledBigIntSafe(a, scale);
    const bBig = toScaledBigIntSafe(b, scale);
    const cmp = aBig < bBig ? -1 : aBig > bBig ? 1 : 0;
    return cmp;
  }

  private generateTxnReference(): string {
    const now = new Date();
    const ymd = now.toISOString().slice(0, 10).replaceAll('-', '');
    const rand = uuid().slice(0, 8).toUpperCase();
    return `TXN-${ymd}-${rand}`;
  }

  /** Internal helper exposed for the matching engine — converts a MatchedTrade
   *  into the param shape expected by lockEscrow. */
  static toLockParams(
    match: MatchedTrade,
    paymentWindowMinutes: number,
    counter: number,
  ): Parameters<EscrowService['lockEscrow']>[0] {
    return {
      makerOrderId: match.makerOrderId,
      takerOrderId: match.takerOrderId,
      makerUserId: match.makerUserId,
      takerUserId: match.takerUserId,
      pair: match.pair,
      takerSide: match.side,
      price: match.price,
      quantity: match.quantity,
      paymentWindowMinutes,
      tradeNumberDailyCounter: counter,
    };
  }
}
