import { Injectable, Logger } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, EntityManager, LessThan, Repository } from 'typeorm';
import { v4 as uuid } from 'uuid';

import {
  Wallet,
  WalletCurrency,
  WalletTransaction,
  TransactionType,
  TransactionStatus,
} from '../../database/entities';
import { BusinessException, ErrorCode } from '../../common/exceptions/business.exception';
import {
  addDecimal,
  subtractDecimal,
  lessThan,
  multiplyDecimal,
} from '../../utils/matching.utils';
import type {
  WalletBalanceResponse,
  WalletTransactionResponse,
  PaginatedLedgerResponse,
} from './dto/wallet.dto';

/**
 * WalletService — the canonical source of truth for every balance change.
 *
 * Design invariants (enforced here, NOT just by the DB):
 *
 *   1. Double-entry discipline:
 *      Every credit has a matching debit conceptually. We don't model
 *      "accounts" formally (the Wallet entity IS the account), but every
 *      balance mutation writes a WalletTransaction with before/after
 *      snapshots — so the ledger can be replayed from scratch.
 *
 *   2. Atomic ledger writes:
 *      Every balance change happens inside a SERIALIZABLE transaction with
 *      SELECT FOR UPDATE on the wallet row. The wallet row is the lock.
 *      No two concurrent operations can mutate the same wallet.
 *
 *   3. Reference numbers are unique:
 *      `reference` is UNIQUE in the DB. We generate it as
 *      `TXN-YYYYMMDD-<8-char-uuid>` so it's globally sortable + greppable.
 *
 *   4. Signed amounts:
 *      `amount` is negative for debits, positive for credits. This lets
 *      consumers sum a wallet's transactions to derive its balance.
 *
 *   5. No partial writes:
 *      If the wallet update succeeds but the ledger insert fails, the
 *      entire transaction rolls back. The wallet never has a balance
 *      without a corresponding ledger entry.
 */
@Injectable()
export class WalletService {
  private readonly logger = new Logger(WalletService.name);

  constructor(@InjectDataSource() private readonly dataSource: DataSource) {}

  // ===========================================================================
  // READ: balance + ledger
  // ===========================================================================

  /**
   * Returns the user's wallet for a specific currency. Auto-creates the
   * wallet with zero balance if it doesn't exist (idempotent).
   */
  async getOrCreateWallet(userId: string, currency: WalletCurrency): Promise<Wallet> {
    return this.dataSource.transaction(async (manager) => {
      let wallet = await this.findWallet(manager, userId, currency);
      if (!wallet) {
        wallet = manager.create(Wallet, {
          userId,
          currency,
          availableBalance: '0',
          lockedBalance: '0',
          pendingBalance: '0',
        });
        wallet = await manager.save(wallet);
      }
      return wallet;
    });
  }

  async getBalances(userId: string): Promise<WalletBalanceResponse[]> {
    const repo: Repository<Wallet> = this.dataSource.getRepository(Wallet);
    const wallets = await repo.find({ where: { userId } });
    return wallets.map((w) => this.toBalanceResponse(w));
  }

  async getBalance(userId: string, currency: WalletCurrency): Promise<WalletBalanceResponse> {
    const wallet = await this.getOrCreateWallet(userId, currency);
    return this.toBalanceResponse(wallet);
  }

  /**
   * Returns a paginated slice of the user's ledger, newest first.
   * Optional filters: currency, transaction type, related trade ID.
   */
  async getLedger(
    userId: string,
    filters: {
      currency?: WalletCurrency;
      type?: string;
      relatedTradeId?: string;
      page: number;
      limit: number;
    },
  ): Promise<PaginatedLedgerResponse> {
    const page = Math.max(1, filters.page);
    const limit = Math.min(100, Math.max(1, filters.limit));

    // First: find the user's wallet IDs for the requested currency (or all).
    const walletRepo = this.dataSource.getRepository(Wallet);
    const wallets = await walletRepo.find({
      where: filters.currency ? { userId, currency: filters.currency } : { userId },
      select: ['id'],
    });
    if (wallets.length === 0) {
      return { items: [], total: 0, page, limit, hasMore: false };
    }
    const walletIds = wallets.map((w) => w.id);

    // Then: query the transactions for those wallet IDs.
    const txnRepo = this.dataSource.getRepository(WalletTransaction);
    const qb = txnRepo
      .createQueryBuilder('tx')
      .where('tx.wallet_id IN (:...walletIds)', { walletIds })
      .orderBy('tx.created_at', 'DESC')
      .skip((page - 1) * limit)
      .take(limit + 1); // +1 to detect hasMore

    if (filters.type) {
      qb.andWhere('tx.type = :type', { type: filters.type });
    }
    if (filters.relatedTradeId) {
      qb.andWhere('tx.related_trade_id = :tid', { tid: filters.relatedTradeId });
    }

    const rows = await qb.getMany();
    const hasMore = rows.length > limit;
    const items = rows.slice(0, limit).map((t) => this.toTxnResponse(t));

    return { items, total: items.length, page, limit, hasMore };
  }

  // ===========================================================================
  // WRITE: deposit (admin), withdraw (user), process withdrawal (admin)
  // ===========================================================================

  /**
   * Credits the user's wallet with a fiat/crypto deposit. Admin-only —
   * invoked after the admin confirms the funds have settled at the
   * payment provider (Telebirr / CBE / etc.).
   *
   * Financial effect:
   *   wallet.available += amount
   *   ledger: DEPOSIT credit, status COMPLETED
   *
   * Idempotency:
   *   We do NOT enforce unique providerReference at the DB level (the same
   *   reference might legitimately appear in different wallets). The admin
   *   UI is responsible for not double-crediting; we log loudly.
   */
  async adminDeposit(params: {
    userId: string;
    currency: WalletCurrency;
    amount: string;
    providerReference: string;
    description?: string;
    adminId: string;
  }): Promise<{ wallet: Wallet; transaction: WalletTransaction }> {
    if (lessThan(params.amount, '0.00000001')) {
      throw new BusinessException(
        ErrorCode.BAD_REQUEST,
        'Deposit amount must be positive',
      );
    }

    return this.dataSource.transaction('SERIALIZABLE', async (manager) => {
      const wallet = await this.getOrCreateWalletInTx(manager, params.userId, params.currency);

      const balanceBefore = wallet.availableBalance;
      const balanceAfter = addDecimal(wallet.availableBalance, params.amount);
      wallet.availableBalance = balanceAfter;
      await manager.save(wallet);

      const txn = manager.create(WalletTransaction, {
        walletId: wallet.id,
        type: TransactionType.DEPOSIT,
        status: TransactionStatus.COMPLETED,
        amount: params.amount,
        balanceBefore,
        balanceAfter,
        reference: this.generateTxnReference(),
        description: params.description
          ? `${params.description} [ref:${params.providerReference}]`
          : `Deposit via provider ref ${params.providerReference}`,
        completedAt: new Date(),
      });
      const saved = await manager.save(txn);

      this.logger.log(
        `Admin deposit: user=${params.userId} wallet=${wallet.id} ` +
          `+${params.amount} ${params.currency} (ref ${params.providerReference}) ` +
          `by admin=${params.adminId}`,
      );
      return { wallet, transaction: saved };
    });
  }

  /**
   * User-initiated withdrawal request. Moves funds from `available` to
   * `locked` and creates a WalletTransaction in PENDING status. The
   * withdrawal is NOT complete until an admin approves it.
   *
   * Financial effect:
   *   wallet.available -= amount
   *   wallet.locked     += amount
   *   ledger: WITHDRAWAL debit, status PENDING
   *
   * On admin REJECT, the funds move back from locked → available and the
   * txn flips to REVERSED. On APPROVE, the funds leave locked entirely
   * and the txn flips to COMPLETED.
   */
  async requestWithdrawal(params: {
    userId: string;
    currency: WalletCurrency;
    amount: string;
    destination: string;
    description?: string;
  }): Promise<{ wallet: Wallet; transaction: WalletTransaction }> {
    if (lessThan(params.amount, '0.00000001')) {
      throw new BusinessException(
        ErrorCode.BAD_REQUEST,
        'Withdrawal amount must be positive',
      );
    }

    return this.dataSource.transaction('SERIALIZABLE', async (manager) => {
      const wallet = await this.getOrCreateWalletInTx(manager, params.userId, params.currency);

      if (lessThan(wallet.availableBalance, params.amount)) {
        throw new BusinessException(
          ErrorCode.INSUFFICIENT_BALANCE,
          `Insufficient ${params.currency} balance. Required: ${params.amount}, available: ${wallet.availableBalance}`,
          { required: params.amount, available: wallet.availableBalance, currency: params.currency },
        );
      }

      const balanceBefore = wallet.availableBalance;
      const balanceAfter = subtractDecimal(wallet.availableBalance, params.amount);
      wallet.availableBalance = balanceAfter;
      wallet.lockedBalance = addDecimal(wallet.lockedBalance, params.amount);
      await manager.save(wallet);

      const txn = manager.create(WalletTransaction, {
        walletId: wallet.id,
        type: TransactionType.WITHDRAWAL,
        status: TransactionStatus.PENDING,
        amount: '-' + params.amount, // debit (signed)
        balanceBefore,
        balanceAfter,
        reference: this.generateTxnReference(),
        description: `Withdrawal to ${params.destination}${params.description ? ': ' + params.description : ''}`,
      });
      const saved = await manager.save(txn);

      this.logger.log(
        `Withdrawal requested: user=${params.userId} wallet=${wallet.id} ` +
          `-${params.amount} ${params.currency} → ${params.destination} (txn ${saved.reference})`,
      );
      return { wallet, transaction: saved };
    });
  }

  /**
   * Admin approves or rejects a pending withdrawal. The walletTxnId is the
   * ID of the original WITHDRAWAL transaction created by requestWithdrawal().
   *
   * APPROVE:
   *   wallet.locked -= amount
   *   txn.status = COMPLETED
   *   (No new ledger row — the original WITHDRAWAL row is updated in place.)
   *
   * REJECT:
   *   wallet.locked     -= amount
   *   wallet.available  += amount
   *   txn.status = REVERSED
   *   new ledger row: type=ADJUSTMENT, amount=+amount, "Withdrawal reversal"
   */
  async processWithdrawal(params: {
    walletTxnId: string;
    action: 'APPROVE' | 'REJECT';
    reason?: string;
    providerReference?: string;
    adminId: string;
  }): Promise<{ wallet: Wallet; transaction: WalletTransaction }> {
    return this.dataSource.transaction('SERIALIZABLE', async (manager) => {
      // Lock the txn row + its wallet row.
      const txn = await manager.findOne(WalletTransaction, {
        where: { id: params.walletTxnId },
        lock: { mode: 'pessimistic_write' },
      });
      if (!txn) {
        throw new BusinessException(ErrorCode.NOT_FOUND, `Transaction ${params.walletTxnId} not found`);
      }
      if (txn.status !== TransactionStatus.PENDING) {
        throw new BusinessException(
          ErrorCode.CONFLICT,
          `Transaction is ${txn.status}; can only process PENDING withdrawals`,
        );
      }
      if (txn.type !== TransactionType.WITHDRAWAL) {
        throw new BusinessException(
          ErrorCode.BAD_REQUEST,
          `Transaction ${params.walletTxnId} is not a withdrawal`,
        );
      }

      const wallet = await manager.findOne(Wallet, {
        where: { id: txn.walletId },
        lock: { mode: 'pessimistic_write' },
      });
      if (!wallet) {
        throw new BusinessException(ErrorCode.WALLET_NOT_FOUND, 'Wallet vanished mid-process');
      }

      // The original amount was stored as a NEGATIVE signed value.
      const amount = txn.amount.startsWith('-') ? txn.amount.slice(1) : txn.amount;

      if (params.action === 'APPROVE') {
        if (lessThan(wallet.lockedBalance, amount)) {
          throw new BusinessException(
            ErrorCode.INSUFFICIENT_LOCKED_BALANCE,
            `Locked balance ${wallet.lockedBalance} < withdrawal amount ${amount}`,
          );
        }
        wallet.lockedBalance = subtractDecimal(wallet.lockedBalance, amount);
        await manager.save(wallet);

        txn.status = TransactionStatus.COMPLETED;
        txn.completedAt = new Date();
        txn.description = `${txn.description ?? ''} [approved by ${params.adminId} ref:${params.providerReference ?? 'n/a'}]`.trim();
        const saved = await manager.save(txn);

        this.logger.log(
          `Withdrawal APPROVED: txn=${txn.reference} user=${wallet.userId} ` +
            `-${amount} ${wallet.currency} by admin=${params.adminId}`,
        );
        return { wallet, transaction: saved };
      }

      // REJECT — refund the locked amount back to available.
      wallet.lockedBalance = subtractDecimal(wallet.lockedBalance, amount);
      wallet.availableBalance = addDecimal(wallet.availableBalance, amount);
      await manager.save(wallet);

      txn.status = TransactionStatus.REVERSED;
      txn.description = `${txn.description ?? ''} [REJECTED by ${params.adminId}: ${params.reason ?? 'no reason'}]`.trim();
      const updatedTxn = await manager.save(txn);

      // Write a separate reversal ledger entry — this keeps the original
      // withdrawal row immutable (auditors can trace: PENDING → REVERSED
      // + new ADJUSTMENT credit).
      const reversal = manager.create(WalletTransaction, {
        walletId: wallet.id,
        type: TransactionType.ADJUSTMENT,
        status: TransactionStatus.COMPLETED,
        amount: amount, // credit
        balanceBefore: subtractDecimal(wallet.availableBalance, amount),
        balanceAfter: wallet.availableBalance,
        reference: this.generateTxnReference(),
        description: `Withdrawal reversal for ${txn.reference}: ${params.reason ?? 'rejected'}`,
        completedAt: new Date(),
      });
      await manager.save(reversal);

      this.logger.log(
        `Withdrawal REJECTED: txn=${txn.reference} user=${wallet.userId} ` +
          `+${amount} ${wallet.currency} returned to available by admin=${params.adminId}`,
      );
      return { wallet, transaction: updatedTxn };
    });
  }

  // ===========================================================================
  // HELPERS — exposed for the escrow service to call inside its own tx.
  // ===========================================================================

  /**
   * Finds a wallet by (userId, currency) using the same query builder the
   * EscrowService uses — so callers can pass either a manager or the
   * DataSource directly.
   *
   * This is the canonical "find wallet" path. The escrow service uses
   * createQueryBuilder directly inside its own transaction because it
   * needs setLock('pessimistic_write') — but we expose this helper for
   * the rest of the system.
   */
  static async findWalletInTx(
    manager: EntityManager,
    userId: string,
    currency: WalletCurrency,
  ): Promise<Wallet | null> {
    return manager
      .createQueryBuilder(Wallet, 'w')
      .setLock('pessimistic_write')
      .where('w.user_id = :uid', { uid: userId })
      .andWhere('w.currency = :cur', { cur: currency })
      .getOne();
  }

  // ===========================================================================
  // PRIVATE
  // ===========================================================================

  private async findWallet(
    manager: EntityManager,
    userId: string,
    currency: WalletCurrency,
  ): Promise<Wallet | null> {
    return manager
      .createQueryBuilder(Wallet, 'w')
      .where('w.user_id = :uid', { uid: userId })
      .andWhere('w.currency = :cur', { cur: currency })
      .getOne();
  }

  private async getOrCreateWalletInTx(
    manager: EntityManager,
    userId: string,
    currency: WalletCurrency,
  ): Promise<Wallet> {
    const existing = await this.findWallet(manager, userId, currency);
    if (existing) return existing;
    const created = manager.create(Wallet, {
      userId,
      currency,
      availableBalance: '0',
      lockedBalance: '0',
      pendingBalance: '0',
    });
    return manager.save(created);
  }

  private generateTxnReference(): string {
    const now = new Date();
    const ymd = now.toISOString().slice(0, 10).replaceAll('-', '');
    const rand = uuid().slice(0, 8).toUpperCase();
    return `TXN-${ymd}-${rand}`;
  }

  private toBalanceResponse(w: Wallet): WalletBalanceResponse {
    return {
      currency: w.currency,
      available: w.availableBalance,
      locked: w.lockedBalance,
      pending: w.pendingBalance,
      address: w.address,
    };
  }

  private toTxnResponse(t: WalletTransaction): WalletTransactionResponse {
    return {
      id: t.id,
      type: t.type,
      status: t.status,
      amount: t.amount,
      balanceBefore: t.balanceBefore,
      balanceAfter: t.balanceAfter,
      reference: t.reference,
      description: t.description,
      relatedTradeId: t.relatedTradeId,
      createdAt: t.createdAt.toISOString(),
      completedAt: t.completedAt ? t.completedAt.toISOString() : null,
    };
  }
}

// Suppress unused-import warnings for helpers referenced via JSDoc only.
void multiplyDecimal;
void LessThan;
