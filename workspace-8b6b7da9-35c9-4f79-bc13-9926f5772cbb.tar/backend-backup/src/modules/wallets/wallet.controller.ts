import {
  Body,
  Controller,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  Post,
  Query,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { ThrottlerGuard } from '@nestjs/throttler';

import { WalletService } from './wallet.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CsrfGuard } from '../auth/guards/csrf.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { CurrentUser, type AuthUser } from '../../common/decorators/current-user.decorator';
import { LoggingInterceptor } from '../../common/interceptors/logging.interceptor';
import {
  AdminDepositDto,
  WithdrawalRequestDto,
  ProcessWithdrawalDto,
  LedgerQueryDto,
  type WalletBalanceResponse,
  type PaginatedLedgerResponse,
} from './dto/wallet.dto';
import { WalletCurrency, UserRole } from '../../database/entities';
import { BusinessException, ErrorCode } from '../../common/exceptions/business.exception';

/**
 * WalletController — user-facing wallet endpoints.
 *
 * All routes require JWT auth. State-changing routes (POST /withdrawals)
 * also require the CSRF token.
 *
 * Read-only routes (GET /wallets, GET /wallets/:currency, GET /wallets/transactions)
 * are CSRF-exempt by default (CsrfGuard skips GET).
 */
@Controller('v1/wallets')
@UseGuards(JwtAuthGuard, ThrottlerGuard)
@UseInterceptors(LoggingInterceptor)
export class WalletController {
  constructor(private readonly walletService: WalletService) {}

  @Get()
  @HttpCode(HttpStatus.OK)
  async listBalances(@CurrentUser() user: AuthUser): Promise<WalletBalanceResponse[]> {
    return this.walletService.getBalances(user.id);
  }

  @Get(':currency')
  @HttpCode(HttpStatus.OK)
  async getBalance(
    @CurrentUser() user: AuthUser,
    @Param('currency') currency: string,
  ): Promise<WalletBalanceResponse> {
    const cur = this.parseCurrency(currency);
    return this.walletService.getBalance(user.id, cur);
  }

  @Get('transactions/list')
  @HttpCode(HttpStatus.OK)
  async getLedger(
    @CurrentUser() user: AuthUser,
    @Query() query: LedgerQueryDto,
  ): Promise<PaginatedLedgerResponse> {
    return this.walletService.getLedger(user.id, {
      currency: query.currency,
      type: query.type,
      relatedTradeId: query.relatedTradeId,
      page: query.page ?? 1,
      limit: query.limit ?? 50,
    });
  }

  @Post('withdrawals')
  @HttpCode(HttpStatus.CREATED)
  @UseGuards(CsrfGuard)
  async requestWithdrawal(
    @CurrentUser() user: AuthUser,
    @Body() dto: WithdrawalRequestDto,
  ) {
    const result = await this.walletService.requestWithdrawal({
      userId: user.id,
      currency: dto.currency,
      amount: dto.amount,
      destination: dto.destination,
      description: dto.description,
    });
    return {
      transactionId: result.transaction.id,
      reference: result.transaction.reference,
      status: result.transaction.status,
      amount: result.transaction.amount,
      balance: {
        available: result.wallet.availableBalance,
        locked: result.wallet.lockedBalance,
      },
    };
  }

  private parseCurrency(currency: string): WalletCurrency {
    const valid: WalletCurrency[] = [
      WalletCurrency.USD,
      WalletCurrency.ETB,
      WalletCurrency.USDT,
      WalletCurrency.BTC,
      WalletCurrency.ETH,
    ];
    const found = valid.find((c) => c === currency);
    if (!found) {
      throw new BusinessException(
        ErrorCode.INVALID_CURRENCY,
        `Currency ${currency} not supported`,
      );
    }
    return found;
  }
}

/**
 * AdminWalletController — admin-only routes for crediting deposits and
 * processing withdrawals. All routes require ADMIN or SUPER_ADMIN role
 * (enforced by @Roles + RolesGuard).
 *
 * CSRF is required on all admin POST routes because they mutate state on
 * behalf of users (deposits) or on behalf of the platform (withdrawal
 * approvals).
 */
@Controller('v1/admin/wallets')
@UseGuards(JwtAuthGuard, RolesGuard, CsrfGuard, ThrottlerGuard)
@UseInterceptors(LoggingInterceptor)
export class AdminWalletController {
  constructor(private readonly walletService: WalletService) {}

  @Post('deposits')
  @HttpCode(HttpStatus.CREATED)
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN)
  async adminDeposit(@CurrentUser() user: AuthUser, @Body() dto: AdminDepositDto) {
    const result = await this.walletService.adminDeposit({
      userId: dto.userId,
      currency: dto.currency,
      amount: dto.amount,
      providerReference: dto.providerReference,
      description: dto.description,
      adminId: user.id,
    });
    return {
      transactionId: result.transaction.id,
      reference: result.transaction.reference,
      status: result.transaction.status,
      balance: {
        available: result.wallet.availableBalance,
        locked: result.wallet.lockedBalance,
      },
    };
  }

  @Post('withdrawals/:walletTxnId/process')
  @HttpCode(HttpStatus.OK)
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN)
  async processWithdrawal(
    @CurrentUser() user: AuthUser,
    @Param('walletTxnId') walletTxnId: string,
    @Body() dto: ProcessWithdrawalDto,
  ) {
    const result = await this.walletService.processWithdrawal({
      walletTxnId,
      action: dto.action,
      reason: dto.reason,
      providerReference: dto.providerReference,
      adminId: user.id,
    });
    return {
      transactionId: result.transaction.id,
      reference: result.transaction.reference,
      status: result.transaction.status,
      balance: {
        available: result.wallet.availableBalance,
        locked: result.wallet.lockedBalance,
      },
    };
  }
}
