import { Test, type TestingModule } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { DataSource, EntityManager, Repository } from 'typeorm';
import { v4 as uuid } from 'uuid';

import { WalletService } from '../wallet.service';
import {
  Wallet,
  WalletCurrency,
  WalletTransaction,
  TransactionType,
  TransactionStatus,
} from '../../../database/entities';
import {
  ErrorCode,
} from '../../../common/exceptions/business.exception';

/**
 * Wallet tests use a richer in-memory mock than the auth tests because
 * we need to assert:
 *   - SERIALIZABLE transaction isolation behavior (mocked as a single-phase
 *     wrapper that delegates to a real EntityManager-like object)
 *   - createQueryBuilder patterns for wallet lookup
 *   - Ledger row creation with correct before/after snapshots
 *
 * The mock walks the same in-memory state maps the WalletService would
 * touch in production, just without Postgres underneath.
 */
class MockState {
  wallets = new Map<string, Wallet>();
  transactions = new Map<string, WalletTransaction>();
  // Per-user wallet lookup (userId+currency → walletId)
  walletIndex = new Map<string, string>();
}

class MockEntityManager {
  constructor(private readonly state: MockState) {}

  create<E extends object>(entity: new (...args: unknown[]) => E, data: Partial<E>): E {
    return Object.assign(new entity(), data) as E;
  }

  async save<E>(entity: E | E[]): Promise<E | E[]> {
    if (Array.isArray(entity)) {
      return Promise.all(entity.map((e) => this.save(e))) as unknown as Promise<E[]>;
    }
    const obj = entity as unknown as { id?: string };
    if (obj instanceof Wallet) {
      if (!obj.id) obj.id = uuid();
      if (!obj.createdAt) obj.createdAt = new Date();
      obj.updatedAt = new Date();
      this.state.wallets.set(obj.id, obj);
      this.state.walletIndex.set(`${obj.userId}|${obj.currency}`, obj.id);
    } else if (obj instanceof WalletTransaction) {
      if (!obj.id) obj.id = uuid();
      if (!obj.createdAt) obj.createdAt = new Date();
      this.state.transactions.set(obj.id, obj);
    }
    return entity;
  }

  async findOne(
    entity: new (...args: unknown[]) => unknown,
    options: { where: Record<string, unknown>; lock?: unknown },
  ): Promise<unknown | null> {
    if (entity === WalletTransaction) {
      const id = options.where.id as string;
      return this.state.transactions.get(id) ?? null;
    }
    if (entity === Wallet) {
      const id = options.where.id as string;
      return this.state.wallets.get(id) ?? null;
    }
    return null;
  }

  /**
   * Mocks `manager.createQueryBuilder(Wallet, 'w').where(...).andWhere(...).getOne()`.
   * The real query is `w.user_id = :uid AND w.currency = :cur`.
   */
  createQueryBuilder() {
    const self = this;
    const params: Record<string, unknown> = {};
    return {
      setLock: function () { return this; },
      where: function (_clause: string, p: Record<string, unknown>) {
        Object.assign(params, p);
        return this;
      },
      andWhere: function (_clause: string, p: Record<string, unknown>) {
        Object.assign(params, p);
        return this;
      },
      getOne: async function (): Promise<Wallet | null> {
        // Match by user_id (params.uid) and currency (params.cur).
        for (const w of self.state.wallets.values()) {
          if (params.uid && w.userId !== params.uid) continue;
          if (params.cur && w.currency !== params.cur) continue;
          return w;
        }
        return null;
      },
    };
  }

  async update(): Promise<{ affected: number }> {
    return { affected: 1 };
  }
}

class MockDataSource {
  state = new MockState();

  async transaction<T>(
    isolationOrFn: string | ((manager: EntityManager) => Promise<T>),
    maybeFn?: (manager: EntityManager) => Promise<T>,
  ): Promise<T> {
    const fn = typeof isolationOrFn === 'function' ? isolationOrFn : maybeFn!;
    const manager = new MockEntityManager(this.state) as unknown as EntityManager;
    return fn(manager);
  }

  getRepository<T extends object>(entity: new (...args: unknown[]) => T): Repository<T> {
    return new MockRepository(this.state, entity) as unknown as Repository<T>;
  }
}

class MockRepository<T extends object> {
  constructor(
    private readonly state: MockState,
    private readonly entity: new (...args: unknown[]) => T,
  ) {}

  async find(options?: { where?: Record<string, unknown>; select?: string[] }): Promise<T[]> {
    if (this.entity === Wallet) {
      let arr = [...this.state.wallets.values()];
      if (options?.where) {
        arr = arr.filter((w) => {
          for (const [k, v] of Object.entries(options.where!)) {
            if ((w as unknown as Record<string, unknown>)[k] !== v) return false;
          }
          return true;
        });
      }
      return arr as unknown as T[];
    }
    if (this.entity === WalletTransaction) {
      return [...this.state.transactions.values()]
        .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
        .slice(0, 100) as unknown as T[];
    }
    return [];
  }

  /**
   * Mocks the QueryBuilder chain used by WalletService.getLedger():
   *   repo.createQueryBuilder('tx')
   *     .where('tx.wallet_id IN (:...walletIds)', { walletIds })
   *     .orderBy('tx.created_at', 'DESC')
   *     .skip(N).take(M+1)
   *     [optional .andWhere(...)]
   *     .getMany()
   */
  createQueryBuilder(_alias: string) {
    const self = this;
    const state = this.state;
    const filters: { walletIds?: string[]; type?: string; relatedTradeId?: string } = {};
    let skip = 0;
    let take = Infinity;

    const builder = {
      where(_clause: string, params: { walletIds?: string[] }) {
        if (params.walletIds) filters.walletIds = params.walletIds;
        return builder;
      },
      andWhere(clause: string, params: { type?: string; tid?: string }) {
        if (params.type) filters.type = params.type;
        if (params.tid) filters.relatedTradeId = params.tid;
        if (clause.includes('type')) filters.type = params.type;
        return builder;
      },
      orderBy() { return builder; },
      skip(n: number) { skip = n; return builder; },
      take(n: number) { take = n; return builder; },
      async getMany(): Promise<T[]> {
        if (self.entity !== WalletTransaction) return [];
        let arr = [...state.transactions.values()];
        if (filters.walletIds) {
          arr = arr.filter((t) => filters.walletIds!.includes(t.walletId));
        }
        if (filters.type) {
          arr = arr.filter((t) => t.type === filters.type);
        }
        if (filters.relatedTradeId) {
          arr = arr.filter((t) => t.relatedTradeId === filters.relatedTradeId);
        }
        arr.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
        return arr.slice(skip, skip + take) as unknown as T[];
      },
    };
    return builder;
  }
}

describe('WalletService', () => {
  let service: WalletService;
  let ds: MockDataSource;
  let userId: string;

  beforeEach(async () => {
    ds = new MockDataSource();
    userId = uuid();

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        WalletService,
        { provide: DataSource, useValue: ds },
        { provide: getRepositoryToken(Wallet), useValue: ds.getRepository(Wallet) },
        { provide: getRepositoryToken(WalletTransaction), useValue: ds.getRepository(WalletTransaction) },
      ],
    }).compile();

    service = module.get(WalletService);
  });

  // Helper: seed a wallet directly into the mock state
  function seedWallet(
    userId: string,
    currency: WalletCurrency,
    available: string,
    locked: string = '0',
  ): Wallet {
    const w: Wallet = {
      id: uuid(),
      userId,
      currency,
      availableBalance: available,
      lockedBalance: locked,
      pendingBalance: '0',
      address: null,
      createdAt: new Date(),
      updatedAt: new Date(),
      transactions: [] as unknown as Wallet['transactions'],
    } as unknown as Wallet;
    ds.state.wallets.set(w.id, w);
    ds.state.walletIndex.set(`${userId}|${currency}`, w.id);
    return w;
  }

  // ===========================================================================
  // READ: balances + ledger
  // ===========================================================================
  describe('getBalance / getBalances', () => {
    it('returns a zero-balance wallet if none exists (auto-creates)', async () => {
      const balance = await service.getBalance(userId, WalletCurrency.USD);
      expect(balance.currency).toBe(WalletCurrency.USD);
      expect(balance.available).toBe('0');
      expect(balance.locked).toBe('0');
    });

    it('returns the existing wallet when one exists', async () => {
      seedWallet(userId, WalletCurrency.USD, '500.00', '50.00');
      const balance = await service.getBalance(userId, WalletCurrency.USD);
      expect(balance.available).toBe('500.00');
      expect(balance.locked).toBe('50.00');
    });

    it('returns all wallets for a user via getBalances', async () => {
      seedWallet(userId, WalletCurrency.USD, '500');
      seedWallet(userId, WalletCurrency.ETB, '12000');
      const balances = await service.getBalances(userId);
      expect(balances).toHaveLength(2);
      const usd = balances.find((b) => b.currency === WalletCurrency.USD);
      expect(usd?.available).toBe('500');
    });
  });

  describe('getLedger', () => {
    it('returns empty list when the user has no transactions', async () => {
      seedWallet(userId, WalletCurrency.USD, '500');
      const result = await service.getLedger(userId, { page: 1, limit: 50 });
      expect(result.items).toEqual([]);
      expect(result.hasMore).toBe(false);
    });
  });

  // ===========================================================================
  // WRITE: adminDeposit
  // ===========================================================================
  describe('adminDeposit', () => {
    it('credits the available balance + writes a COMPLETED DEPOSIT ledger row', async () => {
      const { wallet, transaction } = await service.adminDeposit({
        userId,
        currency: WalletCurrency.USD,
        amount: '100.50',
        providerReference: 'TELEBIRR-TX-12345',
        adminId: 'admin-1',
      });

      expect(wallet.availableBalance).toBe('100.5');
      expect(transaction.type).toBe(TransactionType.DEPOSIT);
      expect(transaction.status).toBe(TransactionStatus.COMPLETED);
      expect(transaction.amount).toBe('100.50');
      expect(transaction.balanceBefore).toBe('0');
      expect(transaction.balanceAfter).toBe('100.5');
      expect(transaction.reference).toMatch(/^TXN-\d{8}-[A-F0-9]{8}$/);
      expect(transaction.description).toContain('TELEBIRR-TX-12345');
    });

    it('adds to an existing balance without losing the prior amount', async () => {
      seedWallet(userId, WalletCurrency.USD, '250.00');
      const { wallet, transaction } = await service.adminDeposit({
        userId,
        currency: WalletCurrency.USD,
        amount: '100.00',
        providerReference: 'TELEBIRR-TX-67890',
        adminId: 'admin-1',
      });
      expect(wallet.availableBalance).toBe('350');
      expect(transaction.balanceBefore).toBe('250.00');
      expect(transaction.balanceAfter).toBe('350');
    });

    it('rejects a non-positive deposit amount', async () => {
      await expect(
        service.adminDeposit({
          userId,
          currency: WalletCurrency.USD,
          amount: '0',
          providerReference: 'TELEBIRR-TX-X',
          adminId: 'admin-1',
        }),
      ).rejects.toMatchObject({ errorCode: ErrorCode.BAD_REQUEST });
    });
  });

  // ===========================================================================
  // WRITE: requestWithdrawal
  // ===========================================================================
  describe('requestWithdrawal', () => {
    it('moves funds from available → locked + writes a PENDING WITHDRAWAL ledger row', async () => {
      seedWallet(userId, WalletCurrency.ETB, '10000.00');

      const { wallet, transaction } = await service.requestWithdrawal({
        userId,
        currency: WalletCurrency.ETB,
        amount: '3000.00',
        destination: '+251911234567',
      });

      expect(wallet.availableBalance).toBe('7000');
      expect(wallet.lockedBalance).toBe('3000');
      expect(transaction.type).toBe(TransactionType.WITHDRAWAL);
      expect(transaction.status).toBe(TransactionStatus.PENDING);
      expect(transaction.amount).toBe('-3000.00'); // signed debit
      expect(transaction.balanceBefore).toBe('10000.00');
      expect(transaction.balanceAfter).toBe('7000');
      expect(transaction.reference).toMatch(/^TXN-\d{8}-[A-F0-9]{8}$/);
      expect(transaction.description).toContain('+251911234567');
    });

    it('rejects a withdrawal that exceeds the available balance', async () => {
      seedWallet(userId, WalletCurrency.ETB, '5000.00');

      await expect(
        service.requestWithdrawal({
          userId,
          currency: WalletCurrency.ETB,
          amount: '6000.00',
          destination: '+251911234567',
        }),
      ).rejects.toMatchObject({ errorCode: ErrorCode.INSUFFICIENT_BALANCE });
    });

    it('preserves the (available + locked) invariant across withdrawal requests', async () => {
      seedWallet(userId, WalletCurrency.USD, '1000.00');
      const initialNet = '1000';

      // Request three withdrawals of 200 each.
      for (let i = 0; i < 3; i++) {
        await service.requestWithdrawal({
          userId,
          currency: WalletCurrency.USD,
          amount: '200.00',
          destination: `addr-${i}`,
        });
      }

      const wallet = ds.state.wallets.values().next().value as Wallet;
      const available = BigInt(wallet.availableBalance);
      const locked = BigInt(wallet.lockedBalance);
      expect(available + locked).toBe(BigInt(initialNet));
    });
  });

  // ===========================================================================
  // WRITE: processWithdrawal (APPROVE / REJECT)
  // ===========================================================================
  describe('processWithdrawal', () => {
    it('APPROVE removes funds from locked + marks the txn COMPLETED', async () => {
      seedWallet(userId, WalletCurrency.USD, '1000.00');

      const reqResult = await service.requestWithdrawal({
        userId,
        currency: WalletCurrency.USD,
        amount: '300.00',
        destination: '0xABCDEF',
      });
      expect(reqResult.wallet.lockedBalance).toBe('300');

      const result = await service.processWithdrawal({
        walletTxnId: reqResult.transaction.id,
        action: 'APPROVE',
        providerReference: 'BTC-TX-12345',
        adminId: 'admin-1',
      });

      expect(result.wallet.availableBalance).toBe('700');
      expect(result.wallet.lockedBalance).toBe('0');
      expect(result.transaction.status).toBe(TransactionStatus.COMPLETED);
      expect(result.transaction.completedAt).not.toBeNull();
    });

    it('REJECT returns funds to available + marks the txn REVERSED + writes a reversal ledger row', async () => {
      seedWallet(userId, WalletCurrency.USD, '1000.00');

      const reqResult = await service.requestWithdrawal({
        userId,
        currency: WalletCurrency.USD,
        amount: '300.00',
        destination: '0xABCDEF',
      });
      expect(reqResult.wallet.lockedBalance).toBe('300');

      const beforeReject = ds.state.transactions.size;
      const result = await service.processWithdrawal({
        walletTxnId: reqResult.transaction.id,
        action: 'REJECT',
        reason: 'Address flagged for fraud',
        adminId: 'admin-1',
      });

      expect(result.wallet.availableBalance).toBe('1000');
      expect(result.wallet.lockedBalance).toBe('0');
      expect(result.transaction.status).toBe(TransactionStatus.REVERSED);

      // A reversal ledger row should have been written.
      expect(ds.state.transactions.size).toBe(beforeReject + 1);
      const reversal = [...ds.state.transactions.values()]
        .filter((t) => t.type === TransactionType.ADJUSTMENT)
        .pop();
      expect(reversal).toBeDefined();
      expect(reversal!.amount).toBe('300.00'); // credit
      expect(reversal!.description).toContain('reversal');
    });

    it('rejects processing an already-completed withdrawal', async () => {
      seedWallet(userId, WalletCurrency.USD, '1000.00');
      const reqResult = await service.requestWithdrawal({
        userId,
        currency: WalletCurrency.USD,
        amount: '300.00',
        destination: '0xABCDEF',
      });

      await service.processWithdrawal({
        walletTxnId: reqResult.transaction.id,
        action: 'APPROVE',
        adminId: 'admin-1',
      });

      // Second attempt → must fail because it's COMPLETED, not PENDING.
      await expect(
        service.processWithdrawal({
          walletTxnId: reqResult.transaction.id,
          action: 'APPROVE',
          adminId: 'admin-1',
        }),
      ).rejects.toMatchObject({ errorCode: ErrorCode.CONFLICT });
    });

    it('rejects processing a non-withdrawal transaction', async () => {
      // Seed a PENDING DEPOSIT transaction directly. The service should
      // reject it because it's not a WITHDRAWAL (even though it's PENDING).
      const wallet = seedWallet(userId, WalletCurrency.USD, '100');
      const txn: WalletTransaction = {
        id: uuid(),
        walletId: wallet.id,
        relatedTradeId: null,
        type: TransactionType.DEPOSIT,
        status: TransactionStatus.PENDING,
        amount: '100',
        balanceBefore: '0',
        balanceAfter: '100',
        reference: 'TXN-TEST-1',
        description: 'fake pending deposit',
        createdAt: new Date(),
        completedAt: null,
      } as unknown as WalletTransaction;
      ds.state.transactions.set(txn.id, txn);

      await expect(
        service.processWithdrawal({
          walletTxnId: txn.id,
          action: 'APPROVE',
          adminId: 'admin-1',
        }),
      ).rejects.toMatchObject({ errorCode: ErrorCode.BAD_REQUEST });
    });
  });

  // ===========================================================================
  // INVARIANT: ledger snapshots are always consistent with wallet state
  // ===========================================================================
  describe('ledger consistency', () => {
    it('every balance change has matching balanceBefore → balanceAfter → wallet.available', async () => {
      seedWallet(userId, WalletCurrency.USD, '0');

      // 1. Deposit 100
      const d1 = await service.adminDeposit({
        userId,
        currency: WalletCurrency.USD,
        amount: '100',
        providerReference: 'ref1',
        adminId: 'admin',
      });
      expect(d1.transaction.balanceBefore).toBe('0');
      expect(d1.transaction.balanceAfter).toBe('100');

      // 2. Deposit 50 more
      const d2 = await service.adminDeposit({
        userId,
        currency: WalletCurrency.USD,
        amount: '50',
        providerReference: 'ref2',
        adminId: 'admin',
      });
      expect(d2.transaction.balanceBefore).toBe('100');
      expect(d2.transaction.balanceAfter).toBe('150');

      // 3. Withdraw 30
      const w1 = await service.requestWithdrawal({
        userId,
        currency: WalletCurrency.USD,
        amount: '30',
        destination: 'addr',
      });
      expect(w1.transaction.balanceBefore).toBe('150');
      expect(w1.transaction.balanceAfter).toBe('120');

      // 4. Approve withdrawal
      const p1 = await service.processWithdrawal({
        walletTxnId: w1.transaction.id,
        action: 'APPROVE',
        adminId: 'admin',
      });
      // No new txn row — the original WITHDRAWAL row is updated in place.
      // Balance unchanged (locked → out, available unchanged).
      expect(p1.wallet.availableBalance).toBe('120');
      expect(p1.wallet.lockedBalance).toBe('0');

      // 5. Ledger has 3 rows (2 deposits + 1 withdrawal).
      // Sorted newest first — but createdAt timestamps may collide at
      // millisecond resolution, so we look up by type instead of position.
      const ledger = await service.getLedger(userId, { page: 1, limit: 50 });
      expect(ledger.items.length).toBe(3);
      const withdrawal = ledger.items.find((i) => i.type === TransactionType.WITHDRAWAL);
      expect(withdrawal).toBeDefined();
      expect(withdrawal!.amount).toBe('-30');
      expect(withdrawal!.balanceAfter).toBe('120');

      const deposits = ledger.items.filter((i) => i.type === TransactionType.DEPOSIT);
      expect(deposits).toHaveLength(2);
      const depositAmounts = deposits.map((d) => d.amount).sort();
      expect(depositAmounts).toEqual(['100', '50']);
    });
  });
});
