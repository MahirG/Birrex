import { Type } from 'class-transformer';
import {
  IsEnum,
  IsOptional,
  IsString,
  IsUUID,
  Matches,
  Min,
  Max,
  IsInt,
} from 'class-validator';
import { WalletCurrency } from '../../../database/entities';

/**
 * DepositDto — admin-only. Records a fiat deposit received via Telebirr /
 * M-PESA / bank transfer. The admin supplies the payment provider's
 * transaction reference so we can reconcile against their statement.
 *
 * Important: deposits are NEVER credited to the user's available balance
 * until the admin (or an automated payment webhook in Phase 3) confirms
 * the funds have settled at the provider.
 */
export class AdminDepositDto {
  @IsUUID('4')
  userId: string;

  @IsEnum(WalletCurrency)
  currency: WalletCurrency;

  @IsString()
  @Matches(/^\d+(\.\d{1,8})?$/, { message: 'amount must be a positive decimal with up to 8 fractional digits' })
  amount: string;

  /**
   * Provider's transaction reference (e.g. Telebirr TX ID, CBE trace #).
   * Stored on the WalletTransaction for reconciliation + dispute defense.
   */
  @IsString()
  @Matches(/^[\w-]{4,64}$/, { message: 'providerReference must be 4-64 alphanumeric chars' })
  providerReference: string;

  @IsOptional()
  @IsString()
  description?: string;
}

/**
 * WithdrawalRequestDto — user-initiated. The user requests to withdraw
 * fiat/crypto to an external address. Funds move from `available` to
 * `locked` immediately; an admin must approve the withdrawal before
 * the funds actually leave the platform.
 */
export class WithdrawalRequestDto {
  @IsEnum(WalletCurrency)
  currency: WalletCurrency;

  @IsString()
  @Matches(/^\d+(\.\d{1,8})?$/)
  amount: string;

  /**
   * Destination: for crypto, an on-chain address; for fiat, a payment-method
   * ID (Telebirr phone number, bank account, etc.) previously saved by the
   * user via /v1/payment-methods.
   */
  @IsString()
  @Matches(/^[\w-]{5,255}$/, { message: 'destination must be 5-255 alphanumeric chars' })
  destination: string;

  @IsOptional()
  @IsString()
  description?: string;
}

/**
 * Admin processes a withdrawal: APPROVE (funds leave) or REJECT (funds
 * return to user's available balance).
 */
export class ProcessWithdrawalDto {
  @IsEnum(['APPROVE', 'REJECT'])
  action: 'APPROVE' | 'REJECT';

  @IsOptional()
  @IsString()
  reason?: string;

  /**
   * Required only for APPROVE — the provider's transaction reference for
   * the outbound transfer (e.g. Telebirr TX ID, BTC tx hash).
   */
  @IsOptional()
  @IsString()
  providerReference?: string;
}

/**
 * LedgerQueryDto — pagination + filters for GET /v1/wallets/transactions.
 */
export class LedgerQueryDto {
  @IsOptional()
  @IsEnum(WalletCurrency)
  currency?: WalletCurrency;

  @IsOptional()
  @IsString()
  type?: string; // TransactionType

  @Type(() => Number)
  @IsInt() @Min(1)
  @IsOptional()
  page?: number = 1;

  @Type(() => Number)
  @IsInt() @Min(1) @Max(100)
  @IsOptional()
  limit?: number = 50;

  @IsOptional()
  @IsUUID('4')
  relatedTradeId?: string;
}

export interface WalletBalanceResponse {
  currency: WalletCurrency;
  available: string;
  locked: string;
  pending: string;
  address: string | null;
}

export interface WalletTransactionResponse {
  id: string;
  type: string;
  status: string;
  amount: string;
  balanceBefore: string;
  balanceAfter: string;
  reference: string;
  description: string | null;
  relatedTradeId: string | null;
  createdAt: string;
  completedAt: string | null;
}

export interface PaginatedLedgerResponse {
  items: WalletTransactionResponse[];
  total: number;
  page: number;
  limit: number;
  hasMore: boolean;
}
