import { IsDateString, IsOptional } from 'class-validator';
import { Type } from 'class-transformer';
import { IsInt, Min, Max } from 'class-validator';

export class NbeReportQueryDto {
  /** ISO date string for the start of the reporting window (inclusive). */
  @IsDateString()
  dateFrom: string;

  /** ISO date string for the end of the reporting window (exclusive). */
  @IsDateString()
  dateTo: string;
}

export class SuspiciousTransactionQueryDto {
  @Type(() => Number)
  @IsInt() @Min(1) @Max(100)
  @IsOptional()
  limit?: number = 50;
}

/**
 * NbeDailyReport — the payload sent to NBE (National Bank of Ethiopia)
 * every evening at 22:00 Africa/Addis_Ababa via the cron job.
 *
 * The shape mirrors NBE's Forex Bureau Daily Reporting spec:
 *   - totalVolumeETB:   sum of all trade total_values in ETB
 *   - totalVolumeUSD:   sum of all trade quantities where pair=USD_ETB
 *   - tradeCount:       number of RELEASED trades
 *   - cancelledCount:   number of CANCELLED + EXPIRED trades
 *   - disputedCount:    number of DISPUTED + RESOLVED_* trades
 *   - uniqueParticipants: distinct users across maker + taker
 *   - suspiciousTransactions: trades flagged by the rules below
 *
 * Suspicious flags:
 *   - Large cash trade (single trade ≥ 200,000 ETB — NBE threshold)
 *   - Frequent trader (≥10 trades in a single day by one user)
 *   - Dispute ratio ≥ 30% (more than 3 of every 10 trades disputed)
 *   - Rapid-fire ordering (≥50 orders placed in 1 hour)
 */
export interface NbeDailyReport {
  reportDate: string;
  generatedAt: string;
  window: { from: string; to: string };
  totals: {
    totalVolumeETB: string;
    totalVolumeUSD: string;
    tradeCount: number;
    cancelledCount: number;
    disputedCount: number;
    uniqueParticipants: number;
  };
  perPairBreakdown: Array<{
    pair: string;
    tradeCount: number;
    volumeBase: string;
    volumeQuote: string;
  }>;
  suspiciousTransactions: SuspiciousTransaction[];
  topTraders: Array<{
    userId: string;
    email: string;
    tradeCount: number;
    volumeETB: string;
  }>;
}

export interface SuspiciousTransaction {
  tradeId: string;
  tradeNumber: string;
  userId: string;
  userEmail: string;
  pair: string;
  amountETB: string;
  flags: string[];
  tradeDate: string;
}
