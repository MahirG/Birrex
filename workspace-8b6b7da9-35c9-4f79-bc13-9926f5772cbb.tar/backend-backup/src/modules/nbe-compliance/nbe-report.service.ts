import { Injectable, Logger } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { Between, LessThan, MoreThan } from 'typeorm';
import { v4 as uuid } from 'uuid';

import {
  Trade,
  TradeStatus,
  Order,
  User,
} from '../../database/entities';
import {
  addDecimal,
  lessThan,
} from '../../utils/matching.utils';
import { getEnv } from '../../config';
import {
  type NbeDailyReport,
  type SuspiciousTransaction,
} from './dto/nbe-report.dto';

/**
 * NbeReportService — generates compliance reports for the National Bank of Ethiopia.
 *
 * Two responsibilities:
 *
 *   1. DAILY REPORT (cron at 22:00 Addis_Ababa):
 *      POST to NBE_REPORTING_API_BASE with the previous day's trade activity.
 *      If the NBE API is unreachable, the report is persisted locally + retried
 *      on the next run (Phase 4 — Phase 3 just logs the payload).
 *
 *   2. SUSPICIOUS TRANSACTION FLAGGING:
 *      Runs the same rule engine over the day's trades and surfaces any
 *      that match. Rules:
 *        a) Single trade ≥ 200,000 ETB (NBE large-cash threshold)
 *        b) User with ≥ 10 trades in one day (frequent trader)
 *        c) User with dispute ratio ≥ 30% (3+ of 10 trades disputed)
 *        d) User placing ≥ 50 orders in one hour (rapid-fire)
 *
 * All amounts are computed with our BigInt-backed decimal helpers so we
 * never lose precision on ETB sums.
 */
@Injectable()
export class NbeReportService {
  private readonly logger = new Logger(NbeReportService.name);

  // NBE large-cash threshold — single trade at or above this ETB value is flagged.
  static readonly LARGE_CASH_THRESHOLD_ETB = '200000';
  static readonly FREQUENT_TRADER_THRESHOLD = 10;
  static readonly DISPUTE_RATIO_THRESHOLD = 0.3;
  static readonly RAPID_FIRE_THRESHOLD_PER_HOUR = 50;

  constructor(@InjectDataSource() private readonly dataSource: DataSource) {}

  // ===========================================================================
  // DAILY REPORT
  // ===========================================================================

  /**
   * Generates the daily compliance report for the window [dateFrom, dateTo).
   *
   * Default window: the previous UTC day. The cron job calls this with
   * explicit dates so the report is deterministic regardless of when the
   * cron actually fires.
   */
  async generateDailyReport(params: {
    dateFrom: Date;
    dateTo: Date;
  }): Promise<NbeDailyReport> {
    const tradeRepo = this.dataSource.getRepository(Trade);

    // ---- Load all trades in the window ----
    const trades = await tradeRepo.find({
      where: { createdAt: Between(params.dateFrom, params.dateTo) },
      relations: ['makerUser', 'takerUser', 'makerOrder', 'takerOrder'],
      order: { createdAt: 'ASC' },
    });

    // ---- Compute totals ----
    let totalVolumeETB = '0';
    let totalVolumeUSD = '0';
    let tradeCount = 0;
    let cancelledCount = 0;
    let disputedCount = 0;
    const participants = new Set<string>();
    const perPair = new Map<string, { count: number; volumeBase: string; volumeQuote: string }>();

    for (const t of trades) {
      participants.add(t.makerUserId);
      participants.add(t.takerUserId);

      const pairStats = perPair.get(t.pair) ?? { count: 0, volumeBase: '0', volumeQuote: '0' };
      pairStats.count += 1;

      if (t.status === TradeStatus.RELEASED) {
        tradeCount++;
        totalVolumeETB = addDecimal(totalVolumeETB, t.totalValue);
        if (t.pair === 'USD_ETB') {
          totalVolumeUSD = addDecimal(totalVolumeUSD, t.quantity);
        }
        pairStats.volumeBase = addDecimal(pairStats.volumeBase, t.quantity);
        pairStats.volumeQuote = addDecimal(pairStats.volumeQuote, t.totalValue);
      } else if (t.status === TradeStatus.CANCELLED || t.status === TradeStatus.EXPIRED) {
        cancelledCount++;
      } else if (t.status === TradeStatus.DISPUTED || t.disputedAt !== null) {
        // Count disputes via the disputedAt timestamp so we catch trades that
        // were disputed AND subsequently resolved via the DisputeService.
        disputedCount++;
      }
      perPair.set(t.pair, pairStats);
    }

    // ---- Suspicious transaction detection ----
    const suspicious = await this.detectSuspiciousTransactions({
      dateFrom: params.dateFrom,
      dateTo: params.dateTo,
      trades,
    });

    // ---- Top traders (by trade count, descending) ----
    const traderStats = new Map<string, { userId: string; email: string; count: number; volumeETB: string }>();
    for (const t of trades) {
      if (t.status !== TradeStatus.RELEASED) continue;
      for (const user of [t.makerUser, t.takerUser] as User[]) {
        if (!user) continue;
        const stat = traderStats.get(user.id) ?? {
          userId: user.id,
          email: user.email,
          count: 0,
          volumeETB: '0',
        };
        stat.count += 1;
        stat.volumeETB = addDecimal(stat.volumeETB, t.totalValue);
        traderStats.set(user.id, stat);
      }
    }
    const topTraders = [...traderStats.values()]
      .sort((a, b) => b.count - a.count)
      .slice(0, 10)
      .map((s) => ({
        userId: s.userId,
        email: s.email,
        tradeCount: s.count,
        volumeETB: s.volumeETB,
      }));

    const report: NbeDailyReport = {
      reportDate: params.dateFrom.toISOString().slice(0, 10),
      generatedAt: new Date().toISOString(),
      window: { from: params.dateFrom.toISOString(), to: params.dateTo.toISOString() },
      totals: {
        totalVolumeETB,
        totalVolumeUSD,
        tradeCount,
        cancelledCount,
        disputedCount,
        uniqueParticipants: participants.size,
      },
      perPairBreakdown: [...perPair.entries()].map(([pair, s]) => ({
        pair,
        tradeCount: s.count,
        volumeBase: s.volumeBase,
        volumeQuote: s.volumeQuote,
      })),
      suspiciousTransactions: suspicious,
      topTraders,
    };

    this.logger.log(
      `NBE daily report generated: date=${report.reportDate} trades=${tradeCount} ` +
        `volumeETB=${totalVolumeETB} suspicious=${suspicious.length} participants=${participants.size}`,
    );

    return report;
  }

  // ===========================================================================
  // CRON — submit yesterday's report to NBE
  // ===========================================================================

  /**
   * Called by @Cron decorator in the controller. Generates yesterday's report
   * + submits it to NBE_REPORTING_API_BASE. Phase 3 stub just logs.
   */
  async submitDailyReportToNbe(): Promise<{ submitted: boolean; reportDate: string }> {
    const now = new Date();
    const yesterdayStart = new Date(now);
    yesterdayStart.setUTCDate(now.getUTCDate() - 1);
    yesterdayStart.setUTCHours(0, 0, 0, 0);
    const yesterdayEnd = new Date(yesterdayStart);
    yesterdayEnd.setUTCDate(yesterdayStart.getUTCDate() + 1);

    const report = await this.generateDailyReport({
      dateFrom: yesterdayStart,
      dateTo: yesterdayEnd,
    });

    const env = getEnv();
    if (!env.NBE_REPORTING_API_BASE) {
      this.logger.warn('NBE_REPORTING_API_BASE not configured — skipping submission');
      return { submitted: false, reportDate: report.reportDate };
    }

    // Phase 3 stub: log the payload that WOULD be POSTed.
    // Phase 4 will replace this with axios.post(env.NBE_REPORTING_API_BASE, report, { headers: { 'X-API-Key': env.NBE_REPORTING_API_KEY } }).
    this.logger.log(
      `[NBE-SUBMIT] reportDate=${report.reportDate} trades=${report.totals.tradeCount} ` +
        `volumeETB=${report.totals.totalVolumeETB} suspicious=${report.suspiciousTransactions.length}`,
    );

    return { submitted: true, reportDate: report.reportDate };
  }

  // ===========================================================================
  // SUSPICIOUS TRANSACTION DETECTION
  // ===========================================================================

  /**
   * Runs all four suspicious-transaction rules over the given trades.
   * Returns a de-duplicated list (one entry per trade, multiple flags merged).
   */
  async detectSuspiciousTransactions(params: {
    dateFrom: Date;
    dateTo: Date;
    trades?: Trade[];
  }): Promise<SuspiciousTransaction[]> {
    const trades = params.trades ?? await this.dataSource.getRepository(Trade).find({
      where: { createdAt: Between(params.dateFrom, params.dateTo) },
      relations: ['makerUser', 'takerUser'],
    });

    // Group trades by user for rules b + c.
    const tradesByUser = new Map<string, Trade[]>();
    for (const t of trades) {
      for (const uid of [t.makerUserId, t.takerUserId]) {
        const arr = tradesByUser.get(uid) ?? [];
        arr.push(t);
        tradesByUser.set(uid, arr);
      }
    }

    // Rule d: rapid-fire ordering — fetch orders placed in the window.
    const orderRepo = this.dataSource.getRepository(Order);
    const ordersInWindow = await orderRepo.find({
      where: { createdAt: Between(params.dateFrom, params.dateTo) },
      select: ['id', 'userId', 'createdAt'],
    });
    const ordersByUserHour = new Map<string, number>();
    for (const o of ordersInWindow) {
      const hourKey = `${o.userId}|${o.createdAt.toISOString().slice(0, 13)}`;
      ordersByUserHour.set(hourKey, (ordersByUserHour.get(hourKey) ?? 0) + 1);
    }
    const rapidFireUsers = new Set<string>();
    for (const [key, count] of ordersByUserHour) {
      if (count >= NbeReportService.RAPID_FIRE_THRESHOLD_PER_HOUR) {
        rapidFireUsers.add(key.split('|')[0]!);
      }
    }

    // Apply rules per trade.
    const suspiciousByTradeId = new Map<string, SuspiciousTransaction>();
    for (const t of trades) {
      const flags: string[] = [];

      // Rule a: single trade ≥ LARGE_CASH_THRESHOLD_ETB
      if (!lessThan(t.totalValue, NbeReportService.LARGE_CASH_THRESHOLD_ETB)) {
        flags.push('LARGE_CASH_TRADE');
      }

      // Rule b: frequent trader (either party)
      for (const uid of [t.makerUserId, t.takerUserId]) {
        const userTradeCount = tradesByUser.get(uid)?.length ?? 0;
        if (userTradeCount >= NbeReportService.FREQUENT_TRADER_THRESHOLD) {
          flags.push(`FREQUENT_TRADER_${uid === t.makerUserId ? 'MAKER' : 'TAKER'}`);
        }
      }

      // Rule c: dispute ratio ≥ 30% (per user)
      for (const uid of [t.makerUserId, t.takerUserId]) {
        const userTrades = tradesByUser.get(uid) ?? [];
        const disputed = userTrades.filter(
          (ut) => ut.disputedAt !== null ||
                  ut.status === TradeStatus.DISPUTED,
        ).length;
        const ratio = userTrades.length > 0 ? disputed / userTrades.length : 0;
        if (ratio >= NbeReportService.DISPUTE_RATIO_THRESHOLD) {
          flags.push(`HIGH_DISPUTE_RATIO_${uid === t.makerUserId ? 'MAKER' : 'TAKER'}`);
        }
      }

      // Rule d: rapid-fire ordering (either party)
      if (rapidFireUsers.has(t.makerUserId)) flags.push('RAPID_FIRE_MAKER');
      if (rapidFireUsers.has(t.takerUserId)) flags.push('RAPID_FIRE_TAKER');

      if (flags.length === 0) continue;

      const user = (t.makerUser ?? t.takerUser) as User | undefined;
      suspiciousByTradeId.set(t.id, {
        tradeId: t.id,
        tradeNumber: t.tradeNumber,
        userId: user?.id ?? t.makerUserId,
        userEmail: user?.email ?? 'unknown',
        pair: t.pair,
        amountETB: t.totalValue,
        flags,
        tradeDate: t.createdAt.toISOString(),
      });
    }

    return [...suspiciousByTradeId.values()];
  }

  /**
   * Returns the latest suspicious transactions across ALL time (not just one day).
   * Used by the admin dashboard for real-time monitoring.
   */
  async listRecentSuspiciousTransactions(limit: number = 50): Promise<SuspiciousTransaction[]> {
    // Look back 7 days for suspicious activity.
    const dateTo = new Date();
    const dateFrom = new Date(dateTo);
    dateFrom.setDate(dateTo.getDate() - 7);
    const all = await this.detectSuspiciousTransactions({ dateFrom, dateTo });
    return all.slice(0, limit);
  }
}

// Suppress unused-import warnings for things referenced via JSDoc only.
void uuid;
void LessThan;
void MoreThan;
