import { Module } from '@nestjs/common';
import { ScheduleModule } from '@nestjs/schedule';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Trade, Order, User } from '../../database/entities';
import { AuthModule } from '../auth/auth.module';
import { NbeReportService } from './nbe-report.service';
import { NbeReportController } from './nbe-report.controller';

@Module({
  imports: [
    TypeOrmModule.forFeature([Trade, Order, User]),
    AuthModule,
    ScheduleModule.forRoot(),
  ],
  controllers: [NbeReportController],
  providers: [NbeReportService],
  exports: [NbeReportService],
})
export class NbeComplianceModule {}
