import { Test, type TestingModule } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { DataSource, Repository } from 'typeorm';
import { v4 as uuid } from 'uuid';

import { NbeReportService } from '../nbe-report.service';
import {
  Trade,
  TradeStatus,
  OrderSide,
  OrderType,
  Order,
  OrderStatus,
  User,
  UserRole,
  UserStatus,
  KycStatus,
} from '../../../database/entities';

/**
 * NBE Report tests verify:
 *   1. Empty window → zero totals, empty suspicious list.
 *   2. Single RELEASED trade → tradeCount=1, volumeETB=total value, no flags.
 *   3. Large trade (≥ 200,000 ETB) → flagged LARGE_CASH_TRADE.
 *   4. Frequent trader (10+ trades by same user) → flagged FREQUENT_TRADER_*.
 *   5. High dispute ratio → flagged HIGH_DISPUTE_RATIO_*.
 *   6. Per-pair breakdown sums are correct.
 *   7. Top traders list is sorted by trade count desc.
 */

class MockTradeRepo {
  private trades: Trade[] = [];

  _setTrades(trades: Trade[]): void {
    this.trades = trades;
  }

  async find(options?: {
    where?: Record<string, unknown>;
    relations?: string[];
    order?: Record<string, string>;
    select?: string[];
  }): Promise<Trade[]> {
    let arr = [...this.trades];
    if (options?.where) {
      // The only filter we use is createdAt: Between(a, b) — TypeORM represents
      // Between as { createdAt: Between object } which has _type === 'between'.
      const createdAtFilter = options.where.createdAt as unknown as { _type?: string; from?: Date; to?: Date };
      if (createdAtFilter?._type === 'between' && createdAtFilter.from && createdAtFilter.to) {
        arr = arr.filter((t) =>
          t.createdAt >= createdAtFilter.from! && t.createdAt < createdAtFilter.to!,
        );
      }
    }
    if (options?.order?.createdAt === 'ASC') {
      arr.sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
    }
    return arr;
  }
}

class MockOrderRepo {
  private orders: Order[] = [];

  _setOrders(orders: Order[]): void {
    this.orders = orders;
  }

  async find(options?: {
    where?: Record<string, unknown>;
    select?: string[];
  }): Promise<Order[]> {
    let arr = [...this.orders];
    if (options?.where) {
      const createdAtFilter = options.where.createdAt as unknown as { _type?: string; from?: Date; to?: Date };
      if (createdAtFilter?._type === 'between' && createdAtFilter.from && createdAtFilter.to) {
        arr = arr.filter((o) =>
          o.createdAt >= createdAtFilter.from! && o.createdAt < createdAtFilter.to!,
        );
      }
    }
    return arr;
  }
}

class MockDataSource {
  constructor(
    private readonly tradeRepo: MockTradeRepo,
    private readonly orderRepo: MockOrderRepo,
  ) {}

  getRepository<T extends object>(entity: new (...args: unknown[]) => T): Repository<T> {
    if (entity === Trade) return this.tradeRepo as unknown as Repository<T>;
    if (entity === Order) return this.orderRepo as unknown as Repository<T>;
    return {} as Repository<T>;
  }
}

// TypeORM's Between() helper produces a FindOperator at runtime. Our mock's
// `find()` reads the operator's _type + from/to fields. To create a Between
// in tests we use this minimal stand-in.
function between(from: Date, to: Date): unknown {
  return { _type: 'between', from, to };
}

describe('NbeReportService', () => {
  let service: NbeReportService;
  let tradeRepo: MockTradeRepo;
  let orderRepo: MockOrderRepo;

  beforeEach(async () => {
    tradeRepo = new MockTradeRepo();
    orderRepo = new MockOrderRepo();
    const ds = new MockDataSource(tradeRepo, orderRepo);

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        NbeReportService,
        { provide: DataSource, useValue: ds },
        { provide: getRepositoryToken(Trade), useValue: tradeRepo },
        { provide: getRepositoryToken(Order), useValue: orderRepo },
      ],
    }).compile();

    service = module.get(NbeReportService);
  });

  // Helper: build a Trade with sensible defaults.
  function buildTrade(overrides: Partial<Trade> = {}): Trade {
    return {
      id: uuid(),
      tradeNumber: `TRD-20260625-${Math.floor(Math.random() * 99999)}`,
      makerOrderId: uuid(),
      takerOrderId: uuid(),
      makerUserId: overrides.makerUserId ?? uuid(),
      takerUserId: overrides.takerUserId ?? uuid(),
      pair: 'USD_ETB',
      side: OrderSide.BUY,
      price: '120',
      quantity: '100',
      totalValue: '12000',
      escrowWalletId: uuid(),
      cryptoLockedAmount: '100',
      paymentMethodId: null,
      paymentReference: null,
      paymentScreenshotUrl: null,
      paymentInitiatedAt: null,
      paymentConfirmedAt: null,
      paymentWindowMinutes: 30,
      paymentWindowExpiresAt: new Date(Date.now() + 30 * 60_000),
      status: TradeStatus.RELEASED,
      makerFee: '0',
      takerFee: '0.5',
      disputedAt: null,
      disputeReason: null,
      createdAt: new Date(),
      updatedAt: new Date(),
      completedAt: null,
      cancelledAt: null,
      cancelledBy: null,
      cancelReason: null,
      ...overrides,
    } as unknown as Trade;
  }

  function buildUser(id: string, email: string): User {
    return {
      id,
      email,
      phoneNumber: '+251911000000',
      passwordHash: 'x',
      fullName: email,
      role: UserRole.USER,
      status: UserStatus.ACTIVE,
      kycStatus: KycStatus.VERIFIED,
      is2faEnabled: false,
      totpSecretEncrypted: null,
      kycSubmittedAt: null,
      kycVerifiedAt: null,
      kycDocumentType: null,
      kycDocumentNumberEncrypted: null,
      preferredLanguage: 'en',
      timezone: 'Africa/Addis_Ababa',
      lastLoginAt: null,
      lastLoginIp: null,
      failedLoginAttempts: 0,
      lockedUntil: null,
      createdAt: new Date(),
      updatedAt: new Date(),
      wallets: [] as unknown as User['wallets'],
    } as unknown as User;
  }

  // ===========================================================================
  // EMPTY WINDOW
  // ===========================================================================
  describe('generateDailyReport — empty window', () => {
    it('returns zero totals + empty suspicious list when no trades exist', async () => {
      tradeRepo._setTrades([]);
      orderRepo._setOrders([]);

      const dateFrom = new Date('2026-06-25T00:00:00Z');
      const dateTo = new Date('2026-06-26T00:00:00Z');
      const report = await service.generateDailyReport({ dateFrom, dateTo });

      expect(report.totals.tradeCount).toBe(0);
      expect(report.totals.totalVolumeETB).toBe('0');
      expect(report.totals.totalVolumeUSD).toBe('0');
      expect(report.totals.uniqueParticipants).toBe(0);
      expect(report.suspiciousTransactions).toEqual([]);
      expect(report.topTraders).toEqual([]);
    });
  });

  // ===========================================================================
  // HAPPY PATH — single small trade
  // ===========================================================================
  describe('generateDailyReport — single small trade', () => {
    it('aggregates totals + per-pair breakdown correctly', async () => {
      const maker = buildUser(uuid(), 'maker@example.com');
      const taker = buildUser(uuid(), 'taker@example.com');
      const trade = buildTrade({
        makerUserId: maker.id,
        takerUserId: taker.id,
        pair: 'USD_ETB',
        price: '120',
        quantity: '100',
        totalValue: '12000',
        status: TradeStatus.RELEASED,
        createdAt: new Date('2026-06-25T10:00:00Z'),
      });
      (trade as unknown as { makerUser: User }).makerUser = maker;
      (trade as unknown as { takerUser: User }).takerUser = taker;
      tradeRepo._setTrades([trade]);
      orderRepo._setOrders([]);

      const report = await service.generateDailyReport({
        dateFrom: new Date('2026-06-25T00:00:00Z'),
        dateTo: new Date('2026-06-26T00:00:00Z'),
      });

      expect(report.totals.tradeCount).toBe(1);
      expect(report.totals.totalVolumeETB).toBe('12000');
      expect(report.totals.totalVolumeUSD).toBe('100');
      expect(report.totals.uniqueParticipants).toBe(2);
      expect(report.perPairBreakdown).toHaveLength(1);
      expect(report.perPairBreakdown[0]!.pair).toBe('USD_ETB');
      expect(report.perPairBreakdown[0]!.volumeBase).toBe('100');
      expect(report.perPairBreakdown[0]!.volumeQuote).toBe('12000');
      expect(report.topTraders).toHaveLength(2);
      // No suspicious activity on a single small trade.
      expect(report.suspiciousTransactions).toHaveLength(0);
    });
  });

  // ===========================================================================
  // SUSPICIOUS — LARGE_CASH_TRADE
  // ===========================================================================
  describe('suspicious — large cash trade', () => {
    it('flags a single trade ≥ 200,000 ETB as LARGE_CASH_TRADE', async () => {
      const maker = buildUser(uuid(), 'rich@example.com');
      const trade = buildTrade({
        makerUserId: maker.id,
        pair: 'USD_ETB',
        price: '2000',
        quantity: '200',
        totalValue: '400000', // ≥ 200,000 threshold
        status: TradeStatus.RELEASED,
      });
      (trade as unknown as { makerUser: User }).makerUser = maker;
      (trade as unknown as { takerUser: User }).takerUser = buildUser(uuid(), 'taker@example.com');
      tradeRepo._setTrades([trade]);
      orderRepo._setOrders([]);

      const report = await service.generateDailyReport({
        dateFrom: new Date('2026-06-25T00:00:00Z'),
        dateTo: new Date('2026-06-26T00:00:00Z'),
      });

      expect(report.suspiciousTransactions).toHaveLength(1);
      expect(report.suspiciousTransactions[0]!.flags).toContain('LARGE_CASH_TRADE');
      expect(report.suspiciousTransactions[0]!.amountETB).toBe('400000');
    });
  });

  // ===========================================================================
  // SUSPICIOUS — FREQUENT_TRADER
  // ===========================================================================
  describe('suspicious — frequent trader', () => {
    it('flags trades where either party has ≥ 10 trades in the window', async () => {
      const frequentMaker = buildUser(uuid(), 'frequent@example.com');
      const occasionalTaker = buildUser(uuid(), 'taker@example.com');
      (frequentMaker as unknown as { id: string }).id = frequentMaker.id;

      // Generate 10 trades by the frequent maker.
      const trades: Trade[] = [];
      for (let i = 0; i < 10; i++) {
        const t = buildTrade({
          makerUserId: frequentMaker.id,
          takerUserId: occasionalTaker.id,
          pair: 'USD_ETB',
          price: '120',
          quantity: '10',
          totalValue: '1200',
          status: TradeStatus.RELEASED,
          createdAt: new Date(`2026-06-25T${10 + i}:00:00Z`),
        });
        (t as unknown as { makerUser: User }).makerUser = frequentMaker;
        (t as unknown as { takerUser: User }).takerUser = occasionalTaker;
        trades.push(t);
      }
      tradeRepo._setTrades(trades);
      orderRepo._setOrders([]);

      const report = await service.generateDailyReport({
        dateFrom: new Date('2026-06-25T00:00:00Z'),
        dateTo: new Date('2026-06-26T00:00:00Z'),
      });

      // All 10 trades should be flagged (because both parties have ≥10).
      expect(report.suspiciousTransactions.length).toBe(10);
      // The first trade's flags should include FREQUENT_TRADER_MAKER.
      const firstFlags = report.suspiciousTransactions[0]!.flags;
      expect(firstFlags.some((f: string) => f.startsWith('FREQUENT_TRADER_'))).toBe(true);
    });
  });

  // ===========================================================================
  // SUSPICIOUS — HIGH_DISPUTE_RATIO
  // ===========================================================================
  describe('suspicious — high dispute ratio', () => {
    it('flags users whose dispute ratio is ≥ 30%', async () => {
      const maker = buildUser(uuid(), 'shady@example.com');
      // 10 trades; 4 disputed → 40% ratio → flagged.
      const trades: Trade[] = [];
      for (let i = 0; i < 10; i++) {
        const t = buildTrade({
          makerUserId: maker.id,
          pair: 'USD_ETB',
          price: '120',
          quantity: '10',
          totalValue: '1200',
          status: i < 4 ? TradeStatus.DISPUTED : TradeStatus.RELEASED,
          disputedAt: i < 4 ? new Date('2026-06-25T12:00:00Z') : null,
          createdAt: new Date(`2026-06-25T${10 + i}:00:00Z`),
        });
        (t as unknown as { makerUser: User }).makerUser = maker;
        (t as unknown as { takerUser: User }).takerUser = buildUser(uuid(), `t${i}@example.com`);
        trades.push(t);
      }
      tradeRepo._setTrades(trades);
      orderRepo._setOrders([]);

      const report = await service.generateDailyReport({
        dateFrom: new Date('2026-06-25T00:00:00Z'),
        dateTo: new Date('2026-06-26T00:00:00Z'),
      });

      // The 4 disputed trades will be flagged with HIGH_DISPUTE_RATIO_MAKER.
      const flaggedDisputed = report.suspiciousTransactions.filter((s) =>
        s.flags.some((f) => f.startsWith('HIGH_DISPUTE_RATIO_')),
      );
      expect(flaggedDisputed.length).toBeGreaterThan(0);
    });
  });

  // ===========================================================================
  // TOP TRADERS — sorted by trade count desc
  // ===========================================================================
  describe('top traders', () => {
    it('returns top 10 traders sorted by trade count descending', async () => {
      // 12 users, each with a different number of trades.
      const trades: Trade[] = [];
      const users: User[] = [];
      for (let u = 0; u < 12; u++) {
        const user = buildUser(uuid(), `user${u}@example.com`);
        users.push(user);
        for (let i = 0; i <= u; i++) {
          // user0 has 1 trade, user1 has 2, ..., user11 has 12 trades.
          const t = buildTrade({
            makerUserId: user.id,
            pair: 'USD_ETB',
            price: '120',
            quantity: '1',
            totalValue: '120',
            status: TradeStatus.RELEASED,
            createdAt: new Date(`2026-06-25T${10 + (u * 12 + i) % 12}:00:00Z`),
          });
          (t as unknown as { makerUser: User }).makerUser = user;
          (t as unknown as { takerUser: User }).takerUser = buildUser(uuid(), 'taker@example.com');
          trades.push(t);
        }
      }
      tradeRepo._setTrades(trades);
      orderRepo._setOrders([]);

      const report = await service.generateDailyReport({
        dateFrom: new Date('2026-06-25T00:00:00Z'),
        dateTo: new Date('2026-06-26T00:00:00Z'),
      });

      expect(report.topTraders).toHaveLength(10); // capped at 10
      // Sorted descending → first entry should be user11 with 12 trades.
      expect(report.topTraders[0]!.tradeCount).toBe(12);
      expect(report.topTraders[0]!.email).toBe('user11@example.com');
      // Second should be user10 with 11 trades.
      expect(report.topTraders[1]!.tradeCount).toBe(11);
    });
  });

  // ===========================================================================
  // CANCELLED + DISPUTED counting
  // ===========================================================================
  describe('counting by status', () => {
    it('counts CANCELLED/EXPIRED + DISPUTED trades in the right buckets', async () => {
      const trades: Trade[] = [
        buildTrade({ status: TradeStatus.RELEASED, totalValue: '1000' }),
        buildTrade({ status: TradeStatus.RELEASED, totalValue: '2000' }),
        buildTrade({ status: TradeStatus.CANCELLED, totalValue: '5000' }),
        buildTrade({ status: TradeStatus.EXPIRED, totalValue: '7000' }),
        buildTrade({ status: TradeStatus.DISPUTED, totalValue: '3000', disputedAt: new Date() }),
      ];
      for (const t of trades) {
        (t as unknown as { makerUser: User }).makerUser = buildUser(uuid(), 'm@example.com');
        (t as unknown as { takerUser: User }).takerUser = buildUser(uuid(), 't@example.com');
      }
      tradeRepo._setTrades(trades);
      orderRepo._setOrders([]);

      const report = await service.generateDailyReport({
        dateFrom: new Date('2026-06-25T00:00:00Z'),
        dateTo: new Date('2026-06-26T00:00:00Z'),
      });

      // 2 RELEASED, 2 CANCELLED/EXPIRED, 1 DISPUTED.
      expect(report.totals.tradeCount).toBe(2);
      expect(report.totals.cancelledCount).toBe(2);
      expect(report.totals.disputedCount).toBe(1);
      // Volume only counts RELEASED trades.
      expect(report.totals.totalVolumeETB).toBe('3000');
    });
  });
});

// Suppress unused-import warnings.
void between;
void OrderType;
void OrderStatus;
