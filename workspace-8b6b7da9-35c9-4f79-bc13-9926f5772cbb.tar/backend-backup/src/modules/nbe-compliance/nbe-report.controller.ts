import {
  Controller,
  Get,
  HttpCode,
  HttpStatus,
  Post,
  Query,
  UseGuards,
  UseInterceptors,
  Logger,
} from '@nestjs/common';
import { ThrottlerGuard } from '@nestjs/throttler';
import { Cron, CronExpression } from '@nestjs/schedule';

import { NbeReportService } from './nbe-report.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CsrfGuard } from '../auth/guards/csrf.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { LoggingInterceptor } from '../../common/interceptors/logging.interceptor';
import {
  NbeReportQueryDto,
  SuspiciousTransactionQueryDto,
  type NbeDailyReport,
  type SuspiciousTransaction,
} from './dto/nbe-report.dto';
import { UserRole } from '../../database/entities';
import { getEnv } from '../../config';

/**
 * NbeReportController — admin-only endpoints for NBE compliance reporting.
 *
 *   GET  /v1/admin/nbe/report                — generate report for [dateFrom, dateTo)
 *   POST /v1/admin/nbe/submit                — manually trigger NBE submission for yesterday
 *   GET  /v1/admin/nbe/suspicious            — list recent suspicious transactions (last 7 days)
 *
 * CRON: a @Cron decorator inside this controller fires the daily submission
 * automatically at 22:00 Africa/Addis_Ababa every evening.
 */
@Controller('v1/admin/nbe')
@UseGuards(JwtAuthGuard, RolesGuard, ThrottlerGuard)
@UseInterceptors(LoggingInterceptor)
export class NbeReportController {
  private readonly logger = new Logger(NbeReportController.name);

  constructor(private readonly nbeReportService: NbeReportService) {}

  /**
   * CRON — fires every evening at 22:00 Addis_Ababa time.
   * Africa/Addis_Ababa is UTC+3 (no DST), so 22:00 there = 19:00 UTC.
   * The cron expression uses UTC for portability.
   */
  @Cron('0 19 * * *', {
    name: 'nbe-daily-report',
    timeZone: 'UTC',
  })
  async handleDailyCron(): Promise<void> {
    this.logger.log('NBE daily cron fired — generating + submitting report');
    try {
      const result = await this.nbeReportService.submitDailyReportToNbe();
      this.logger.log(`NBE daily cron complete: submitted=${result.submitted} date=${result.reportDate}`);
    } catch (err) {
      this.logger.error(`NBE daily cron failed: ${(err as Error).message}`);
    }
  }

  @Get('report')
  @HttpCode(HttpStatus.OK)
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN)
  async getReport(@Query() query: NbeReportQueryDto): Promise<NbeDailyReport> {
    const dateFrom = new Date(query.dateFrom);
    const dateTo = new Date(query.dateTo);
    if (dateTo <= dateFrom) {
      throw new Error('dateTo must be after dateFrom');
    }
    return this.nbeReportService.generateDailyReport({ dateFrom, dateTo });
  }

  @Post('submit')
  @HttpCode(HttpStatus.OK)
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN)
  @UseGuards(CsrfGuard)
  async submitManually(): Promise<{ submitted: boolean; reportDate: string; nbeEndpoint: string | null }> {
    const result = await this.nbeReportService.submitDailyReportToNbe();
    return {
      ...result,
      nbeEndpoint: getEnv().NBE_REPORTING_API_BASE ?? null,
    };
  }

  @Get('suspicious')
  @HttpCode(HttpStatus.OK)
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN, UserRole.MODERATOR)
  async listSuspicious(@Query() query: SuspiciousTransactionQueryDto): Promise<SuspiciousTransaction[]> {
    return this.nbeReportService.listRecentSuspiciousTransactions(query.limit ?? 50);
  }
}

// Suppress unused-import warnings for things referenced via JSDoc only.
void CronExpression;
