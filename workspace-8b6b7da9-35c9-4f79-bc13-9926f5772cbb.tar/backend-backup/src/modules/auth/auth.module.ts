import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { PassportModule } from '@nestjs/passport';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from '../../database/entities';
import { CryptoService } from '../../common/crypto.service';
import { I18nModule } from '../i18n/i18n.module';
import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';
import { JwtStrategy } from './strategies/jwt.strategy';
import { JwtAuthGuard } from './guards/jwt-auth.guard';
import { CsrfGuard } from './guards/csrf.guard';

@Module({
  imports: [
    TypeOrmModule.forFeature([User]),
    PassportModule.register({ defaultStrategy: 'jwt' }),
    JwtModule.register({
      // The secret is read lazily inside AuthService via JwtService.signAsync,
      // so we don't need to set it globally here. Setting it here would
      // preclude using different secrets for access vs refresh tokens.
    }),
    I18nModule,
  ],
  controllers: [AuthController],
  providers: [AuthService, JwtStrategy, JwtAuthGuard, CsrfGuard, CryptoService],
  exports: [AuthService, JwtAuthGuard, CsrfGuard, JwtStrategy],
})
export class AuthModule {}
