import { Test, type TestingModule } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { JwtService } from '@nestjs/jwt';
import bcrypt from 'bcryptjs';
import { authenticator, totp } from 'otplib';
import { v4 as uuid } from 'uuid';

import { AuthService } from '../auth.service';
import { CryptoService } from '../../../common/crypto.service';
import { I18nService } from '../../i18n/i18n.service';
import {
  User,
  UserRole,
  UserStatus,
  KycStatus,
} from '../../../database/entities';
import {
  ErrorCode,
} from '../../../common/exceptions/business.exception';
import { _resetEnvCacheForTesting } from '../../../config';

/**
 * Auth tests focus on the service layer — controller-level concerns
 * (cookies, CSRF, throttling) are integration-tested in the e2e suite.
 *
 * We use an in-memory Map<User> backed by a tiny MockRepository. The
 * DataSource mock only needs to support transaction() for the
 * register / failed-login flows.
 */
class MockUserRepo {
  private users = new Map<string, User>();

  async findOne(options: { where: Record<string, unknown> | Array<Record<string, unknown>>; select?: string[] }): Promise<User | null> {
    const where = options.where;
    const conditions = Array.isArray(where) ? where : [where];
    let matched: User | undefined;
    for (const u of this.users.values()) {
      for (const cond of conditions) {
        let allMatch = true;
        for (const [k, v] of Object.entries(cond)) {
          if ((u as unknown as Record<string, unknown>)[k] !== v) {
            allMatch = false;
            break;
          }
        }
        if (allMatch) {
          matched = u;
          break;
        }
      }
      if (matched) break;
    }
    if (!matched) return null;
    if (options.select) {
      const picked: Partial<User> = { id: matched.id };
      for (const s of options.select) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (picked as any)[s] = (matched as any)[s];
      }
      return picked as User;
    }
    return matched;
  }

  async update(id: string, partial: Partial<User>): Promise<{ affected: number }> {
    const u = this.users.get(id);
    if (!u) return { affected: 0 };
    Object.assign(u, partial);
    return { affected: 1 };
  }

  // Helper for tests to seed users directly.
  _seed(user: User): void {
    this.users.set(user.id, user);
  }

  _get(id: string): User | undefined {
    return this.users.get(id);
  }

  _clear(): void {
    this.users.clear();
  }
}

class MockDataSource {
  constructor(private readonly userRepo: MockUserRepo) {}

  async transaction<T>(fn: (manager: unknown) => Promise<T>): Promise<T> {
    // Single-phase — we don't simulate rollbacks in unit tests.
    // The manager's create() returns the data; save() assigns IDs + persists.
    const userRepo = this.userRepo;
    const manager = {
      create: <E>(_entity: unknown, data: E): E => data,
      save: async <E>(entity: E): Promise<E> => {
        const obj = entity as unknown as { id?: string; email?: string };
        if (obj && !obj.id) obj.id = uuid();
        if (obj && obj.email) {
          // Persist to userRepo so subsequent findOne() can find the user.
          // We cast loosely because User has many fields the test doesn't set.
          userRepo._seed(obj as unknown as User);
        }
        return entity;
      },
      update: async () => ({ affected: 1 }),
      findOne: async () => null,
    };
    return fn(manager);
  }
}

describe('AuthService', () => {
  let service: AuthService;
  let userRepo: MockUserRepo;
  let jwtService: JwtService;
  let crypto: CryptoService;
  let i18n: I18nService;
  let dataSource: MockDataSource;

  beforeAll(() => {
    // Configure env for tests — JWT secrets must be set for signAsync.
    process.env.JWT_ACCESS_SECRET = 'test-access-secret-with-at-least-32-characters-length';
    process.env.JWT_REFRESH_SECRET = 'test-refresh-secret-with-at-least-32-characters-length';
    process.env.JWT_ACCESS_TTL = '15m';
    process.env.JWT_REFRESH_TTL = '7d';
    process.env.BCRYPT_ROUNDS = '4'; // fast tests
    process.env.RATE_LIMIT_LOGIN = '5';
    _resetEnvCacheForTesting();
  });

  afterAll(() => {
    _resetEnvCacheForTesting();
  });

  beforeEach(async () => {
    userRepo = new MockUserRepo();
    jwtService = new JwtService();
    i18n = new I18nService();
    dataSource = new MockDataSource(userRepo);

    // CryptoService needs RSA keys to encrypt/decrypt TOTP secrets.
    // For tests, we use a stub that does plain-text round-trips.
    crypto = {
      encrypt: (plaintext: string) => Buffer.from(plaintext, 'utf8'),
      decrypt: (blob: Buffer) => blob.toString('utf8'),
    } as unknown as CryptoService;

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AuthService,
        { provide: getRepositoryToken(User), useValue: userRepo },
        { provide: JwtService, useValue: jwtService },
        { provide: CryptoService, useValue: crypto },
        { provide: I18nService, useValue: i18n },
        { provide: DataSource, useValue: dataSource },
      ],
    }).compile();

    service = module.get(AuthService);
  });

  // ===========================================================================
  // Helper: seed an active user directly into the mock repo
  // ===========================================================================
  async function seedActiveUser(overrides: Partial<User> = {}): Promise<User> {
    const passwordHash = await bcrypt.hash('Password123', 4);
    const user: User = {
      id: uuid(),
      email: 'test@example.com',
      phoneNumber: '+251911234567',
      passwordHash,
      fullName: 'Test User',
      role: UserRole.USER,
      status: UserStatus.ACTIVE,
      is2faEnabled: false,
      kycStatus: KycStatus.UNVERIFIED,
      kycSubmittedAt: null,
      kycVerifiedAt: null,
      kycDocumentType: null,
      kycDocumentNumberEncrypted: null,
      totpSecretEncrypted: null,
      preferredLanguage: 'en',
      timezone: 'Africa/Addis_Ababa',
      lastLoginAt: null,
      lastLoginIp: null,
      failedLoginAttempts: 0,
      lockedUntil: null,
      createdAt: new Date(),
      updatedAt: new Date(),
      wallets: [] as unknown as User['wallets'],
      ...overrides,
    } as unknown as User;
    userRepo._seed(user);
    return user;
  }

  // ===========================================================================
  // REGISTER
  // ===========================================================================
  describe('register', () => {
    it('creates a new user and issues access + refresh tokens', async () => {
      const { user, tokens } = await service.register({
        email: 'newuser@example.com',
        phoneNumber: '+251911234567',
        password: 'Password123',
        fullName: 'New User',
      });

      expect(user.id).toBeDefined();
      expect(user.email).toBe('newuser@example.com');
      expect(user.status).toBe(UserStatus.ACTIVE);
      expect(user.role).toBe(UserRole.USER);
      expect(user.kycStatus).toBe(KycStatus.UNVERIFIED);

      expect(tokens.accessToken).toBeDefined();
      expect(tokens.refreshToken).toBeDefined();
      expect(tokens.expiresIn).toBe(900); // 15m in seconds

      // Access token should be decodable and contain the right payload.
      const decoded = await jwtService.verifyAsync(tokens.accessToken, {
        secret: process.env.JWT_ACCESS_SECRET,
      });
      expect(decoded.sub).toBe(user.id);
      expect(decoded.email).toBe('newuser@example.com');
      expect(decoded.type).toBe('access');
    });

    it('rejects duplicate email with a generic conflict message (no enumeration)', async () => {
      await seedActiveUser({ email: 'dup@example.com' });

      await expect(
        service.register({
          email: 'dup@example.com',
          phoneNumber: '+251922234567',
          password: 'Password123',
          fullName: 'Dup User',
        }),
      ).rejects.toMatchObject({
        errorCode: ErrorCode.CONFLICT,
        message: expect.not.stringContaining('email'),
      });
    });

    it('rejects duplicate phone number with the same generic conflict message', async () => {
      await seedActiveUser({ phoneNumber: '+251911234567' });

      await expect(
        service.register({
          email: 'different@example.com',
          phoneNumber: '+251911234567',
          password: 'Password123',
          fullName: 'Dup Phone',
        }),
      ).rejects.toMatchObject({
        errorCode: ErrorCode.CONFLICT,
      });
    });

    it('canonicalizes email to lowercase + trims whitespace', async () => {
      const { user } = await service.register({
        email: '  MixedCase@Example.COM  ',
        phoneNumber: '+251911234567',
        password: 'Password123',
        fullName: 'Mixed',
      });
      expect(user.email).toBe('mixedcase@example.com');
    });
  });

  // ===========================================================================
  // LOGIN
  // ===========================================================================
  describe('login', () => {
    it('returns tokens on valid credentials', async () => {
      await seedActiveUser({ email: 'login@example.com' });

      const { user, tokens } = await service.login({
        email: 'login@example.com',
        password: 'Password123',
      });

      expect(user.email).toBe('login@example.com');
      expect(tokens.accessToken).toBeDefined();
      expect(tokens.refreshToken).toBeDefined();
    });

    it('throws INVALID_CREDENTIALS on wrong password (constant-time)', async () => {
      await seedActiveUser({ email: 'wrong@example.com' });

      await expect(
        service.login({ email: 'wrong@example.com', password: 'WrongPassword123' }),
      ).rejects.toMatchObject({ errorCode: ErrorCode.INVALID_CREDENTIALS });
    });

    it('throws INVALID_CREDENTIALS on unknown email (no account enumeration)', async () => {
      await expect(
        service.login({ email: 'nonexistent@example.com', password: 'Password123' }),
      ).rejects.toMatchObject({ errorCode: ErrorCode.INVALID_CREDENTIALS });
    });

    it('rejects login for non-ACTIVE accounts', async () => {
      await seedActiveUser({ email: 'pending@example.com', status: UserStatus.PENDING });

      await expect(
        service.login({ email: 'pending@example.com', password: 'Password123' }),
      ).rejects.toMatchObject({ errorCode: ErrorCode.ACCOUNT_NOT_ACTIVE });
    });

    it('increments failed login attempts + locks after RATE_LIMIT_LOGIN tries', async () => {
      const user = await seedActiveUser({ email: 'lockme@example.com' });

      // Attempt 5 failed logins (RATE_LIMIT_LOGIN = 5).
      for (let i = 0; i < 5; i++) {
        await expect(
          service.login({ email: 'lockme@example.com', password: 'wrong' }),
        ).rejects.toMatchObject({ errorCode: ErrorCode.INVALID_CREDENTIALS });
      }

      // 6th attempt — even with correct password — should be locked.
      await expect(
        service.login({ email: 'lockme@example.com', password: 'Password123' }),
      ).rejects.toMatchObject({ errorCode: ErrorCode.ACCOUNT_LOCKED });

      // The user record should now have lockedUntil set in the future.
      const updated = userRepo._get(user.id)!;
      expect(updated.lockedUntil).not.toBeNull();
      expect(updated.lockedUntil!.getTime()).toBeGreaterThan(Date.now());
    });
  });

  // ===========================================================================
  // REFRESH TOKEN ROTATION
  // ===========================================================================
  describe('refresh', () => {
    it('issues new tokens from a valid refresh token', async () => {
      const user = await seedActiveUser();
      const { tokens } = await service.login({
        email: user.email,
        password: 'Password123',
      });

      // Add a small delay so the new JWT's iat differs from the original
      // (JWT timestamps are second-resolution).
      await new Promise((resolve) => setTimeout(resolve, 1100));

      const rotated = await service.refresh(tokens.refreshToken);
      expect(rotated.accessToken).toBeDefined();
      expect(rotated.refreshToken).toBeDefined();
      // New refresh token must be different (jti rotation).
      expect(rotated.refreshToken).not.toBe(tokens.refreshToken);
    });

    it('rejects an access token used as a refresh token', async () => {
      const user = await seedActiveUser();
      const { tokens } = await service.login({
        email: user.email,
        password: 'Password123',
      });

      await expect(service.refresh(tokens.accessToken)).rejects.toMatchObject({
        errorCode: ErrorCode.TOKEN_EXPIRED,
      });
    });

    it('rejects a malformed refresh token', async () => {
      await expect(service.refresh('not-a-jwt')).rejects.toMatchObject({
        errorCode: ErrorCode.TOKEN_EXPIRED,
      });
    });

    it('rejects refresh for a non-existent user', async () => {
      // Mint a refresh token for a fake user ID.
      const fakeRefresh = await jwtService.signAsync(
        { sub: uuid(), jti: uuid(), type: 'refresh' },
        { secret: process.env.JWT_REFRESH_SECRET, expiresIn: '7d' },
      );

      await expect(service.refresh(fakeRefresh)).rejects.toMatchObject({
        errorCode: ErrorCode.INVALID_TOKEN,
      });
    });
  });

  // ===========================================================================
  // 2FA — SETUP, VERIFY, DISABLE
  // ===========================================================================
  describe('2FA', () => {
    it('setup generates a TOTP secret, encrypts it, and returns a QR data URL', async () => {
      const user = await seedActiveUser();
      const result = await service.setupTwoFactor(user.id);

      expect(result.secret).toMatch(/^[A-Z2-7]+$/); // base32 (RFC 4648)
      expect(result.secret.length).toBeGreaterThanOrEqual(16);
      expect(result.otpauthUrl).toContain('otpauth://totp/');
      expect(result.otpauthUrl).toContain(encodeURIComponent(user.email));
      expect(result.qrCodeDataUrl).toMatch(/^data:image\/png;base64,/);

      // Secret should be persisted (encrypted) on the user.
      const updated = userRepo._get(user.id)!;
      expect(updated.totpSecretEncrypted).not.toBeNull();
      // The decrypt stub returns the plain secret — verify round-trip.
      expect(crypto.decrypt(updated.totpSecretEncrypted!)).toBe(result.secret);
    });

    it('setup rejects users who already have 2FA enabled', async () => {
      const user = await seedActiveUser({ is2faEnabled: true });
      await expect(service.setupTwoFactor(user.id)).rejects.toMatchObject({
        errorCode: ErrorCode.CONFLICT,
      });
    });

    it('verify enables 2FA when the code matches the secret', async () => {
      const user = await seedActiveUser();
      const setup = await service.setupTwoFactor(user.id);

      // Generate a valid TOTP code for the secret.
      totp.options = { digits: 6, step: 30, window: 1 };
      const validCode = totp.generate(setup.secret);

      const result = await service.verifyTwoFactor(user.id, validCode);
      expect(result.enabled).toBe(true);

      const updated = userRepo._get(user.id)!;
      expect(updated.is2faEnabled).toBe(true);
    });

    it('verify rejects an invalid code (no enabling)', async () => {
      const user = await seedActiveUser();
      await service.setupTwoFactor(user.id);

      await expect(
        service.verifyTwoFactor(user.id, '000000'),
      ).rejects.toMatchObject({ errorCode: ErrorCode.INVALID_2FA_CODE });

      const updated = userRepo._get(user.id)!;
      expect(updated.is2faEnabled).toBe(false);
    });

    it('verify rejects users who skipped setup', async () => {
      const user = await seedActiveUser();
      await expect(
        service.verifyTwoFactor(user.id, '123456'),
      ).rejects.toMatchObject({ errorCode: ErrorCode.BAD_REQUEST });
    });

    it('login requires 2FA code when 2FA is enabled', async () => {
      // Enable 2FA for a user.
      const user = await seedActiveUser({ email: '2fa@example.com' });
      const setup = await service.setupTwoFactor(user.id);
      totp.options = { digits: 6, step: 30, window: 1 };
      const validCode = totp.generate(setup.secret);
      await service.verifyTwoFactor(user.id, validCode);

      // Login WITHOUT a code → must fail.
      await expect(
        service.login({ email: '2fa@example.com', password: 'Password123' }),
      ).rejects.toMatchObject({ errorCode: ErrorCode.INVALID_2FA_CODE });

      // Login WITH a valid code → must succeed.
      const freshCode = totp.generate(setup.secret);
      const { tokens } = await service.login({
        email: '2fa@example.com',
        password: 'Password123',
        twoFactorCode: freshCode,
      });
      expect(tokens.accessToken).toBeDefined();
    });

    it('login rejects a stale 2FA code', async () => {
      const user = await seedActiveUser({ email: 'stale@example.com' });
      const setup = await service.setupTwoFactor(user.id);
      totp.options = { digits: 6, step: 30, window: 1 };
      const validCode = totp.generate(setup.secret);
      await service.verifyTwoFactor(user.id, validCode);

      // Wrong code (off by one digit)
      const wrongCode = validCode === '000000' ? '111111' : '000000';
      await expect(
        service.login({
          email: 'stale@example.com',
          password: 'Password123',
          twoFactorCode: wrongCode,
        }),
      ).rejects.toMatchObject({ errorCode: ErrorCode.INVALID_2FA_CODE });
    });

    it('disable requires both the current password AND a valid TOTP code', async () => {
      const user = await seedActiveUser({ email: 'disable@example.com' });
      const setup = await service.setupTwoFactor(user.id);
      totp.options = { digits: 6, step: 30, window: 1 };
      const validCode = totp.generate(setup.secret);
      await service.verifyTwoFactor(user.id, validCode);

      // Wrong password + valid code → must fail.
      const freshCode1 = totp.generate(setup.secret);
      await expect(
        service.disableTwoFactor(user.id, 'WrongPassword123', freshCode1),
      ).rejects.toMatchObject({ errorCode: ErrorCode.INVALID_CREDENTIALS });

      // Right password + wrong code → must fail.
      await expect(
        service.disableTwoFactor(user.id, 'Password123', '000000'),
      ).rejects.toMatchObject({ errorCode: ErrorCode.INVALID_2FA_CODE });

      // Right password + right code → succeeds.
      const freshCode2 = totp.generate(setup.secret);
      const result = await service.disableTwoFactor(user.id, 'Password123', freshCode2);
      expect(result.enabled).toBe(false);

      const updated = userRepo._get(user.id)!;
      expect(updated.is2faEnabled).toBe(false);
      expect(updated.totpSecretEncrypted).toBeNull();
    });
  });
});

// Suppress unused-import warnings for things referenced via JSDoc only.
void authenticator;
