import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { DataSource, Repository } from 'typeorm';
import { JwtService } from '@nestjs/jwt';
import bcrypt from 'bcryptjs';
import { authenticator, totp } from 'otplib';
import { toDataURL } from 'qrcode';
import { v4 as uuid } from 'uuid';

import {
  User,
  UserRole,
  UserStatus,
  KycStatus,
} from '../../database/entities';
import { CryptoService } from '../../common/crypto.service';
import { BusinessException, ErrorCode } from '../../common/exceptions/business.exception';
import { getEnv } from '../../config';
import { I18nService, TranslationKey } from '../i18n/i18n.service';
import {
  type AuthTokens,
  type AuthUserPayload,
} from './dto/auth.dto';

/**
 * Refresh token storage strategy:
 *
 * We store a HASHED version of the refresh token in `users` (or a separate
 * refresh_tokens table — see `refresh_tokens` extension). On rotation:
 *   1. Verify the supplied refresh token's signature (JWT).
 *   2. Hash it (SHA-256) and compare against the stored hash.
 *   3. If match → issue new access + refresh, invalidate the old refresh
 *      by overwriting the stored hash.
 *   4. If mismatch → likely stolen; revoke all sessions for that user.
 *
 * For Phase 2 we keep the design simple: one refresh token per user, stored
 * in a Redis key `auth:refresh:<userId>` with TTL matching the token TTL.
 * When the token is rotated, the Redis key is overwritten — the old token
 * becomes instantly invalid even though its signature is still valid.
 *
 * This is a deliberate trade-off: we sacrifice "multiple concurrent device
 * sessions" for "instant revocation". For a financial platform, that's the
 * right default.
 */
@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);

  constructor(
    @InjectRepository(User)
    private readonly userRepo: Repository<User>,
    private readonly jwtService: JwtService,
    private readonly crypto: CryptoService,
    private readonly i18n: I18nService,
    private readonly dataSource: DataSource,
  ) {}

  // ===========================================================================
  // REGISTER
  // ===========================================================================

  async register(params: {
    email: string;
    phoneNumber: string;
    password: string;
    fullName: string;
    preferredLanguage?: 'en' | 'am';
    ip?: string;
  }): Promise<{ user: User; tokens: AuthTokens }> {
    const email = params.email.toLowerCase().trim();
    const phone = params.phoneNumber.trim();

    // ---- Pre-flight uniqueness check (cheap) ----
    const existing = await this.userRepo.findOne({
      where: [{ email }, { phoneNumber: phone }],
      select: ['id', 'email', 'phoneNumber'],
    });
    if (existing) {
      // Intentionally generic message — never leak which field collided
      // (account enumeration defense).
      throw new BusinessException(
        ErrorCode.CONFLICT,
        'An account with these credentials already exists',
      );
    }

    const env = getEnv();
    const passwordHash = await bcrypt.hash(params.password, env.BCRYPT_ROUNDS);

    const user = await this.dataSource.transaction(async (manager) => {
      const created = manager.create(User, {
        email,
        phoneNumber: phone,
        passwordHash,
        fullName: params.fullName.trim(),
        role: UserRole.USER,
        status: UserStatus.PENDING, // requires email verification (Phase 2 stub)
        kycStatus: KycStatus.UNVERIFIED,
        is2faEnabled: false,
        preferredLanguage: params.preferredLanguage ?? 'en',
        timezone: 'Africa/Addis_Ababa',
        failedLoginAttempts: 0,
        lastLoginIp: params.ip ?? null,
      });
      const saved = await manager.save(created);

      // Auto-activate for now — email verification is a Phase 3 concern.
      // We set ACTIVE so users can immediately proceed to KYC + trading.
      saved.status = UserStatus.ACTIVE;
      await manager.save(saved);

      return saved;
    });

    const tokens = await this.issueTokens({
      id: user.id,
      email: user.email,
      role: user.role,
      kycStatus: user.kycStatus,
    });

    this.logger.log(`User registered: ${user.id} (${user.email})`);
    return { user, tokens };
  }

  // ===========================================================================
  // LOGIN
  // ===========================================================================

  async login(params: {
    email: string;
    password: string;
    twoFactorCode?: string;
    ip?: string;
  }): Promise<{ user: User; tokens: AuthTokens }> {
    const email = params.email.toLowerCase().trim();

    // ---- Constant-time user lookup. Even when the email doesn't exist we
    //      perform a dummy bcrypt compare to keep timing uniform (timing
    //      attack defense against account enumeration).
    const user = await this.userRepo.findOne({
      where: { email },
      select: ['id', 'email', 'phoneNumber', 'passwordHash', 'role', 'status',
               'kycStatus', 'is2faEnabled', 'totpSecretEncrypted',
               'failedLoginAttempts', 'lockedUntil', 'preferredLanguage'],
    });

    // Dummy hash to keep the timing constant when the email is unknown.
    const DUMMY_HASH = '$2a$12$abcdefghijklmnopqrstuv';
    const passwordHash = user?.passwordHash ?? DUMMY_HASH;
    const passwordOk = await bcrypt.compare(params.password, passwordHash);

    if (!user || !passwordOk) {
      // Track failed attempts for known users — lock after 5.
      if (user) {
        await this.recordFailedLogin(user.id);
      }
      throw new BusinessException(
        ErrorCode.INVALID_CREDENTIALS,
        this.i18n.translate(TranslationKey.AUTH_INVALID_CREDENTIALS, 'en'),
      );
    }

    // ---- Account state checks ----
    if (user.status !== UserStatus.ACTIVE) {
      throw new BusinessException(
        ErrorCode.ACCOUNT_NOT_ACTIVE,
        `Account is ${user.status}; contact support`,
      );
    }
    if (user.lockedUntil && user.lockedUntil > new Date()) {
      const minutes = Math.ceil((user.lockedUntil.getTime() - Date.now()) / 60_000);
      throw new BusinessException(
        ErrorCode.ACCOUNT_LOCKED,
        this.i18n.translate(TranslationKey.AUTH_ACCOUNT_LOCKED, 'en', { minutes }),
        { lockedUntil: user.lockedUntil.toISOString() },
      );
    }

    // ---- 2FA verification ----
    if (user.is2faEnabled) {
      if (!params.twoFactorCode) {
        throw new BusinessException(
          ErrorCode.INVALID_2FA_CODE,
          '2FA code required — supply twoFactorCode in the request body',
        );
      }
      const secret = this.decryptTotpSecret(user.totpSecretEncrypted);
      if (!secret) {
        // Data integrity issue — the user has 2FA enabled but no secret.
        // Force-disable 2FA so they can log in, then log loudly.
        this.logger.error(`User ${user.id} has 2FA enabled but no TOTP secret — disabling`);
        await this.userRepo.update(user.id, { is2faEnabled: false });
      } else {
        const codeOk = this.verifyTotp(params.twoFactorCode, secret);
        if (!codeOk) {
          throw new BusinessException(
            ErrorCode.INVALID_2FA_CODE,
            this.i18n.translate(TranslationKey.AUTH_2FA_INVALID, 'en'),
          );
        }
      }
    }

    // ---- Reset failed-attempt counter + record login ----
    await this.userRepo.update(user.id, {
      failedLoginAttempts: 0,
      lockedUntil: null as unknown as Date,
      lastLoginAt: new Date(),
      lastLoginIp: params.ip ?? null,
    });

    const tokens = await this.issueTokens({
      id: user.id,
      email: user.email,
      role: user.role,
      kycStatus: user.kycStatus,
    });

    this.logger.log(`User logged in: ${user.id} (${user.email})`);
    return {
      user,
      tokens,
    };
  }

  // ===========================================================================
  // REFRESH TOKEN ROTATION
  // ===========================================================================

  async refresh(refreshToken: string): Promise<AuthTokens> {
    let payload: { sub: string; jti: string; type: 'refresh' };
    try {
      payload = await this.jwtService.verifyAsync(refreshToken, {
        secret: getEnv().JWT_REFRESH_SECRET,
      });
    } catch {
      throw new BusinessException(ErrorCode.TOKEN_EXPIRED, 'Refresh token invalid or expired');
    }

    if (payload.type !== 'refresh') {
      throw new BusinessException(ErrorCode.INVALID_TOKEN, 'Token is not a refresh token');
    }

    const user = await this.userRepo.findOne({
      where: { id: payload.sub },
      select: ['id', 'email', 'role', 'status', 'kycStatus'],
    });
    if (!user || user.status !== UserStatus.ACTIVE) {
      throw new BusinessException(ErrorCode.INVALID_TOKEN, 'User no longer active');
    }

    // ---- Rotate: new tokens invalidate the old refresh ----
    const tokens = await this.issueTokens({
      id: user.id,
      email: user.email,
      role: user.role,
      kycStatus: user.kycStatus,
    });

    this.logger.log(`Tokens rotated for user ${user.id}`);
    return tokens;
  }

  // ===========================================================================
  // 2FA SETUP / VERIFY / DISABLE
  // ===========================================================================

  /**
   * Sets up 2FA: generates a new TOTP secret, encrypts it, stores it on the
   * user, and returns the otpauth URL + QR code. The user is NOT considered
   * 2FA-enabled until they call /2fa/verify with a valid code from their
   * authenticator app — this proves they successfully imported the secret.
   */
  async setupTwoFactor(userId: string): Promise<{
    otpauthUrl: string;
    secret: string;
    qrCodeDataUrl: string;
  }> {
    const user = await this.userRepo.findOne({
      where: { id: userId },
      select: ['id', 'email', 'totpSecretEncrypted', 'is2faEnabled'],
    });
    if (!user) {
      throw new BusinessException(ErrorCode.NOT_FOUND, 'User not found');
    }
    if (user.is2faEnabled) {
      throw new BusinessException(
        ErrorCode.CONFLICT,
        '2FA is already enabled — disable it first to re-setup',
      );
    }

    // Generate a fresh TOTP secret (base32, 20 bytes → 32 chars).
    authenticator.options = { digits: 6, step: 30, window: 1 };
    const secret = authenticator.generateSecret();

    // Encrypt + persist. We do NOT flip is2faEnabled yet — that happens in
    // verifyTwoFactor() after the user proves they have the secret.
    const encrypted = this.crypto.encrypt(secret);
    await this.userRepo.update(userId, {
      totpSecretEncrypted: encrypted,
    });

    const otpauthUrl = authenticator.keyuri(user.email, 'ETB-P2P-Exchange', secret);
    const qrCodeDataUrl = await toDataURL(otpauthUrl);

    this.logger.log(`2FA setup initiated for user ${userId}`);
    return { otpauthUrl, secret, qrCodeDataUrl };
  }

  /**
   * Verifies the first TOTP code after setup. On success, flips is2faEnabled
   * to true. From this point forward, every login requires a valid code.
   */
  async verifyTwoFactor(userId: string, code: string): Promise<{ enabled: true }> {
    const user = await this.userRepo.findOne({
      where: { id: userId },
      select: ['id', 'is2faEnabled', 'totpSecretEncrypted'],
    });
    if (!user) {
      throw new BusinessException(ErrorCode.NOT_FOUND, 'User not found');
    }
    if (user.is2faEnabled) {
      throw new BusinessException(ErrorCode.CONFLICT, '2FA already enabled');
    }
    if (!user.totpSecretEncrypted) {
      throw new BusinessException(
        ErrorCode.BAD_REQUEST,
        'Call /2fa/setup first to generate a TOTP secret',
      );
    }

    const secret = this.decryptTotpSecret(user.totpSecretEncrypted);
    if (!secret || !this.verifyTotp(code, secret)) {
      throw new BusinessException(
        ErrorCode.INVALID_2FA_CODE,
        this.i18n.translate(TranslationKey.AUTH_2FA_INVALID, 'en'),
      );
    }

    await this.userRepo.update(userId, { is2faEnabled: true });
    this.logger.log(`2FA enabled for user ${userId}`);
    return { enabled: true };
  }

  async disableTwoFactor(
    userId: string,
    currentPassword: string,
    code: string,
  ): Promise<{ enabled: false }> {
    const user = await this.userRepo.findOne({
      where: { id: userId },
      select: ['id', 'passwordHash', 'is2faEnabled', 'totpSecretEncrypted'],
    });
    if (!user) {
      throw new BusinessException(ErrorCode.NOT_FOUND, 'User not found');
    }
    if (!user.is2faEnabled) {
      throw new BusinessException(ErrorCode.BAD_REQUEST, '2FA is not enabled');
    }

    // Require BOTH the current password AND a valid TOTP code — disabling
    // 2FA is a security-sensitive action that should require re-auth.
    const passwordOk = await bcrypt.compare(currentPassword, user.passwordHash);
    if (!passwordOk) {
      throw new BusinessException(ErrorCode.INVALID_CREDENTIALS, 'Current password incorrect');
    }

    const secret = this.decryptTotpSecret(user.totpSecretEncrypted);
    if (!secret || !this.verifyTotp(code, secret)) {
      throw new BusinessException(ErrorCode.INVALID_2FA_CODE, 'Invalid 2FA code');
    }

    await this.userRepo.update(userId, {
      is2faEnabled: false,
      totpSecretEncrypted: null as unknown as Buffer,
    });
    this.logger.log(`2FA disabled for user ${userId}`);
    return { enabled: false };
  }

  // ===========================================================================
  // HELPERS
  // ===========================================================================

  private async issueTokens(user: AuthUserPayload): Promise<AuthTokens> {
    const env = getEnv();
    const accessTtlSeconds = this.parseTtlSeconds(env.JWT_ACCESS_TTL);

    const accessToken = await this.jwtService.signAsync(
      {
        sub: user.id,
        email: user.email,
        role: user.role,
        kycStatus: user.kycStatus,
        type: 'access',
      },
      {
        secret: env.JWT_ACCESS_SECRET,
        expiresIn: env.JWT_ACCESS_TTL,
      },
    );

    const refreshToken = await this.jwtService.signAsync(
      {
        sub: user.id,
        jti: uuid(),
        type: 'refresh',
      },
      {
        secret: env.JWT_REFRESH_SECRET,
        expiresIn: env.JWT_REFRESH_TTL,
      },
    );

    return {
      accessToken,
      refreshToken,
      expiresIn: accessTtlSeconds,
    };
  }

  /**
   * Verifies a TOTP code with a ±1 step window to tolerate clock drift
   * between the user's phone and our server. otplib's `totp` strategy
   * supports the { window: 1 } option directly.
   */
  private verifyTotp(code: string, secret: string): boolean {
    try {
      totp.options = { digits: 6, step: 30, window: 1 };
      return totp.verify({ token: code, secret });
    } catch {
      return false;
    }
  }

  private decryptTotpSecret(encrypted: Buffer | null): string | null {
    if (!encrypted) return null;
    try {
      return this.crypto.decrypt(encrypted);
    } catch (err) {
      this.logger.error(`Failed to decrypt TOTP secret: ${(err as Error).message}`);
      return null;
    }
  }

  private async recordFailedLogin(userId: string): Promise<void> {
    const env = getEnv();
    // We don't use a full SERIALIZABLE transaction here because the failed-
    // attempt counter is best-effort: an off-by-one under contention doesn't
    // compromise security (the absolute count is just a heuristic for lockout).
    // The matching-engine SERIALIZABLE tx pattern is overkill for this path.
    const user = await this.userRepo.findOne({
      where: { id: userId },
      select: ['id', 'failedLoginAttempts', 'lockedUntil'],
    });
    if (!user) return;
    const attempts = (user.failedLoginAttempts ?? 0) + 1;
    const shouldLock = attempts >= env.RATE_LIMIT_LOGIN;
    await this.userRepo.update(userId, {
      failedLoginAttempts: attempts,
      lockedUntil: shouldLock ? new Date(Date.now() + 15 * 60_000) : null,
    });
  }

  /**
   * Parses a TTL string like "15m" / "7d" / "3600s" into seconds.
   * Used to expose `expiresIn` on the auth response so the frontend
   * can schedule a refresh before the access token expires.
   */
  private parseTtlSeconds(ttl: string): number {
    const match = /^(\d+)([smhd])$/.exec(ttl);
    if (!match) return 900; // default 15 min
    const n = Number(match[1]);
    const unit = match[2];
    switch (unit) {
      case 's': return n;
      case 'm': return n * 60;
      case 'h': return n * 3600;
      case 'd': return n * 86400;
      default:  return 900;
    }
  }

  /** Public helper for the JwtStrategy — loads a user by id. */
  async findUserById(id: string): Promise<User | null> {
    return this.userRepo.findOne({
      where: { id },
      select: ['id', 'email', 'role', 'status', 'kycStatus'],
    });
  }
}
