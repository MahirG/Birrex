import {
  IsEmail,
  IsString,
  Matches,
  MinLength,
  MaxLength,
  IsOptional,
} from 'class-validator';

/**
 * RegisterDto — payload for POST /api/v1/auth/register.
 *
 * Security notes:
 *   - Password MUST be ≥ 10 chars. We enforce ≥ 1 letter + ≥ 1 number
 *     at the API layer; bcryptjs handles the hashing (12 rounds by default).
 *   - Phone must be in E.164 format — every Telebirr/CBE/SMS notification
 *     relies on this canonical form.
 *   - Email is canonicalized to lowercase before insertion.
 */
export class RegisterDto {
  @IsEmail()
  email: string;

  @IsString()
  @Matches(/^\+?[1-9]\d{7,14}$/, {
    message: 'phone must be in E.164 format, e.g. +251911234567',
  })
  phoneNumber: string;

  @IsString()
  @MinLength(10)
  @MaxLength(128)
  // At least one letter and one digit. We do NOT enforce symbols because
  // Ethiopian users on mobile keyboards often can't easily type them.
  @Matches(/[A-Za-z]/, { message: 'password must contain at least one letter' })
  @Matches(/\d/, { message: 'password must contain at least one digit' })
  password: string;

  @IsString()
  @MinLength(2)
  @MaxLength(100)
  fullName: string;

  @IsOptional()
  @IsString()
  @Matches(/^(en|am)$/, { message: 'preferredLanguage must be en or am' })
  preferredLanguage?: 'en' | 'am';
}

export class LoginDto {
  @IsEmail()
  email: string;

  @IsString()
  @MinLength(1)
  password: string;

  /**
   * Required IF the user has 2FA enabled. The 6-digit TOTP code from
   * their authenticator app (Google Authenticator, Authy, etc.).
   * Validated against the user's encrypted TOTP secret.
   */
  @IsOptional()
  @IsString()
  @Matches(/^\d{6}$/, { message: 'twoFactorCode must be exactly 6 digits' })
  twoFactorCode?: string;
}

export class RefreshDto {
  @IsString()
  @MinLength(1)
  refreshToken: string;
}

export class TwoFactorSetupResponseDto {
  /** The OTP auth URL — encodes issuer + secret + account. */
  otpauthUrl: string;
  /** Base32 secret for manual entry (in case QR scan fails). */
  secret: string;
  /** Data-URL PNG of the QR code — frontend embeds this in <img src>. */
  qrCodeDataUrl: string;
}

export class TwoFactorVerifyDto {
  @IsString()
  @Matches(/^\d{6}$/, { message: 'twoFactorCode must be exactly 6 digits' })
  twoFactorCode: string;
}

export class TwoFactorDisableDto {
  @IsString()
  @MinLength(10)
  currentPassword: string;

  @IsString()
  @Matches(/^\d{6}$/)
  twoFactorCode: string;
}

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
  /** Access token TTL in seconds — frontend uses this for refresh scheduling. */
  expiresIn: number;
}

export interface AuthUserPayload {
  id: string;
  email: string;
  role: string;
  kycStatus: string;
}
