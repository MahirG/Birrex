import {
  Body,
  Controller,
  Get,
  HttpCode,
  HttpStatus,
  Post,
  Req,
  Res,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { ThrottlerGuard } from '@nestjs/throttler';
import type { Response } from 'express';

import { AuthService } from './auth.service';
import { CsrfGuard } from './guards/csrf.guard';
import { JwtAuthGuard } from './guards/jwt-auth.guard';
import { LoggingInterceptor } from '../../common/interceptors/logging.interceptor';
import { CurrentUser, type AuthUser } from '../../common/decorators/current-user.decorator';
import {
  RegisterDto,
  LoginDto,
  RefreshDto,
  TwoFactorVerifyDto,
  TwoFactorDisableDto,
} from './dto/auth.dto';
import { BusinessException, ErrorCode } from '../../common/exceptions/business.exception';

interface ClientRequest {
  ip?: string;
  headers: Record<string, string | undefined>;
}

/**
 * AuthController — REST entry points for authentication.
 *
 * All routes are throttled. Login + register have a tighter per-IP limit
 * configured in the ThrottlerModule override (Phase 2 todo).
 *
 * CSRF:
 *   - GET endpoints are CSRF-exempt by default (CsrfGuard skips GET/HEAD/OPTIONS).
 *   - Login / register / refresh are explicitly exempt (pre-auth).
 *   - 2FA setup / verify / disable REQUIRE the CSRF token because they
 *     mutate state on an authenticated session.
 */
@Controller('v1/auth')
@UseInterceptors(LoggingInterceptor)
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  /**
   * POST /api/v1/auth/register
   * Creates a new user account and issues the initial access + refresh tokens.
   */
  @Post('register')
  @HttpCode(HttpStatus.CREATED)
  @UseGuards(ThrottlerGuard)
  async register(
    @Body() dto: RegisterDto,
    @Req() req: ClientRequest,
    @Res({ passthrough: true }) res: Response,
  ) {
    const { user, tokens } = await this.authService.register({
      email: dto.email,
      phoneNumber: dto.phoneNumber,
      password: dto.password,
      fullName: dto.fullName,
      preferredLanguage: dto.preferredLanguage,
      ip: req.ip,
    });
    CsrfGuard.issueCsrfCookie(res);
    this.setRefreshCookie(res, tokens.refreshToken);
    return {
      user: this.sanitizeUser(user),
      accessToken: tokens.accessToken,
      expiresIn: tokens.expiresIn,
    };
  }

  /**
   * POST /api/v1/auth/login
   * Verifies credentials (+ optional 2FA) and issues new tokens.
   */
  @Post('login')
  @HttpCode(HttpStatus.OK)
  @UseGuards(ThrottlerGuard)
  async login(
    @Body() dto: LoginDto,
    @Req() req: ClientRequest,
    @Res({ passthrough: true }) res: Response,
  ) {
    const { user, tokens } = await this.authService.login({
      email: dto.email,
      password: dto.password,
      twoFactorCode: dto.twoFactorCode,
      ip: req.ip,
    });
    CsrfGuard.issueCsrfCookie(res);
    this.setRefreshCookie(res, tokens.refreshToken);
    return {
      user: this.sanitizeUser(user),
      accessToken: tokens.accessToken,
      expiresIn: tokens.expiresIn,
    };
  }

  /**
   * POST /api/v1/auth/refresh
   * Exchanges a valid refresh token for a fresh access + refresh pair.
   * The old refresh token is invalidated server-side (rotation).
   */
  @Post('refresh')
  @HttpCode(HttpStatus.OK)
  @UseGuards(ThrottlerGuard)
  async refresh(
    @Body() dto: RefreshDto,
    @Res({ passthrough: true }) res: Response,
  ) {
    const tokens = await this.authService.refresh(dto.refreshToken);
    this.setRefreshCookie(res, tokens.refreshToken);
    return {
      accessToken: tokens.accessToken,
      expiresIn: tokens.expiresIn,
    };
  }

  /**
   * POST /api/v1/auth/logout
   * Clears the refresh + CSRF cookies. The refresh token rotation on the
   * server side happens implicitly — the next /refresh call with the old
   * token will fail because the server overwrote the stored hash.
   */
  @Post('logout')
  @HttpCode(HttpStatus.OK)
  @UseGuards(JwtAuthGuard, CsrfGuard)
  async logout(@Res({ passthrough: true }) res: Response) {
    res.clearCookie('refresh_token', { path: '/api/v1/auth' });
    res.clearCookie('csrf_token', { path: '/' });
    return { loggedOut: true };
  }

  /**
   * GET /api/v1/auth/me
   * Returns the currently-authenticated user's profile.
   */
  @Get('me')
  @UseGuards(JwtAuthGuard)
  async me(@CurrentUser() user: AuthUser) {
    return {
      id: user.id,
      email: user.email,
      role: user.role,
      kycStatus: user.kycStatus,
    };
  }

  /**
   * GET /api/v1/auth/csrf-token
   * Issues a fresh CSRF token cookie for SPAs that need one before the
   * user logs in (e.g. for the login form's POST request — though /login
   * is CSRF-exempt, having a cookie simplifies frontend middleware).
   */
  @Get('csrf-token')
  @HttpCode(HttpStatus.OK)
  csrfToken(@Res({ passthrough: true }) res: Response) {
    const token = CsrfGuard.issueCsrfCookie(res);
    return { csrfToken: token };
  }

  // ===========================================================================
  // 2FA endpoints — require JWT + CSRF
  // ===========================================================================

  @Post('2fa/setup')
  @HttpCode(HttpStatus.OK)
  @UseGuards(JwtAuthGuard, CsrfGuard)
  async setup2fa(@CurrentUser() user: AuthUser) {
    return this.authService.setupTwoFactor(user.id);
  }

  @Post('2fa/verify')
  @HttpCode(HttpStatus.OK)
  @UseGuards(JwtAuthGuard, CsrfGuard)
  async verify2fa(
    @CurrentUser() user: AuthUser,
    @Body() dto: TwoFactorVerifyDto,
  ) {
    return this.authService.verifyTwoFactor(user.id, dto.twoFactorCode);
  }

  @Post('2fa/disable')
  @HttpCode(HttpStatus.OK)
  @UseGuards(JwtAuthGuard, CsrfGuard)
  async disable2fa(
    @CurrentUser() user: AuthUser,
    @Body() dto: TwoFactorDisableDto,
  ) {
    return this.authService.disableTwoFactor(user.id, dto.currentPassword, dto.twoFactorCode);
  }

  // ===========================================================================
  // PRIVATE
  // ===========================================================================

  /**
   * Strip sensitive fields from the user object before returning to client.
   * NEVER expose passwordHash or totpSecretEncrypted.
   */
  private sanitizeUser(user: unknown): {
    id: string;
    email: string;
    phoneNumber: string;
    fullName: string;
    role: string;
    status: string;
    kycStatus: string;
    is2faEnabled: boolean;
    preferredLanguage: string;
  } {
    const u = user as Record<string, unknown>;
    if (!u.id || !u.email) {
      throw new BusinessException(ErrorCode.INTERNAL_ERROR, 'User object missing required fields');
    }
    return {
      id: u.id as string,
      email: u.email as string,
      phoneNumber: u.phoneNumber as string,
      fullName: u.fullName as string,
      role: u.role as string,
      status: u.status as string,
      kycStatus: u.kycStatus as string,
      is2faEnabled: Boolean(u.is2faEnabled),
      preferredLanguage: u.preferredLanguage as string,
    };
  }

  /**
   * Sets the refresh token as an HttpOnly cookie — accessible only via HTTP,
   * never via JavaScript. This prevents XSS from stealing the refresh token.
   * The frontend exchanges it via POST /api/v1/auth/refresh.
   */
  private setRefreshCookie(res: Response, refreshToken: string): void {
    res.cookie('refresh_token', refreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      path: '/api/v1/auth',
      maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days, matches JWT_REFRESH_TTL default
    });
  }
}
