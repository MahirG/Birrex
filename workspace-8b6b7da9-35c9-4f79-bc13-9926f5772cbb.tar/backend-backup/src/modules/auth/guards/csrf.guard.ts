import {
  Injectable,
  CanActivate,
  ExecutionContext,
  Logger,
} from '@nestjs/common';
import { Request, Response } from 'express';
import { randomUUID } from 'crypto';
import { BusinessException, ErrorCode } from '../../../common/exceptions/business.exception';

/**
 * CSRF protection via the Double-Submit Cookie pattern.
 *
 * Why double-submit and not synchronizer-token?
 *   - Synchronizer tokens require server-side storage per session — extra
 *     Redis round-trip on every state-changing request.
 *   - Double-submit relies on the Same-Origin Policy: a malicious site
 *     cannot read the CSRF cookie value (it's HttpOnly=false but the
 *     cross-origin JS can't access cookies from OUR domain), so it cannot
 *     forge the matching `X-CSRF-Token` header.
 *
 * How it works:
 *   1. On login (or via GET /auth/csrf-token), the server issues a CSRF
 *      cookie: `csrf_token=<random>` with SameSite=Strict, Secure, Path=/.
 *   2. The frontend reads the cookie via document.cookie (it's readable
 *      because HttpOnly=false on this specific cookie only).
 *   3. On every state-changing request (POST/PUT/PATCH/DELETE), the
 *      frontend includes the same token in the `X-CSRF-Token` header.
 *   4. This guard compares the cookie value with the header value.
 *      Mismatch → 403.
 *
 * Defense-in-depth:
 *   - We ALSO rely on SameSite=Strict cookies (browsers will not send the
 *     csrf cookie on cross-site requests at all).
 *   - We require the `Origin` header to match our allowed origins on
 *     state-changing requests.
 *
 * Exempt routes:
 *   - GET / HEAD / OPTIONS (no state change).
 *   - /api/v1/auth/login, /api/v1/auth/register, /api/v1/auth/refresh
 *     (these are pre-auth — no session yet, so no CSRF risk).
 */
@Injectable()
export class CsrfGuard implements CanActivate {
  private readonly logger = new Logger(CsrfGuard.name);
  private readonly exemptPaths = new Set<string>([
    '/api/v1/auth/login',
    '/api/v1/auth/register',
    '/api/v1/auth/refresh',
  ]);

  canActivate(ctx: ExecutionContext): boolean {
    const request = ctx.switchToHttp().getRequest<Request>();
    const method = request.method.toUpperCase();

    // Read-only methods are exempt.
    if (method === 'GET' || method === 'HEAD' || method === 'OPTIONS') {
      return true;
    }

    // Pre-auth endpoints are exempt.
    if (this.exemptPaths.has(request.path)) {
      return true;
    }

    const cookieToken = this.readCookie(request, 'csrf_token');
    const headerToken = request.headers['x-csrf-token'] as string | undefined;

    if (!cookieToken || !headerToken) {
      throw new BusinessException(
        ErrorCode.FORBIDDEN,
        'Missing CSRF token — supply X-CSRF-Token header matching the csrf_token cookie',
      );
    }
    if (cookieToken !== headerToken) {
      this.logger.warn(
        `CSRF token mismatch: cookie=${cookieToken.slice(0, 8)}… header=${headerToken.slice(0, 8)}… path=${request.path}`,
      );
      throw new BusinessException(
        ErrorCode.FORBIDDEN,
        'CSRF token mismatch',
      );
    }

    // Origin check — defense-in-depth against same-site bypass via subdomain.
    const origin = request.headers['origin'];
    if (origin && !this.isAllowedOrigin(origin)) {
      throw new BusinessException(ErrorCode.FORBIDDEN, 'Origin not allowed');
    }

    return true;
  }

  /**
   * Issues a fresh CSRF token cookie. Called by AuthController on successful
   * login/register and on GET /auth/csrf-token (for SPA initial load).
   */
  static issueCsrfCookie(res: Response): string {
    const token = randomUUID();
    res.cookie('csrf_token', token, {
      httpOnly: false,         // must be readable by frontend JS
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      path: '/',
      maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
    });
    return token;
  }

  private readCookie(req: Request, name: string): string | undefined {
    const header = req.headers.cookie;
    if (!header) return undefined;
    for (const part of header.split(';')) {
      const [k, v] = part.trim().split('=');
      if (k === name) return v;
    }
    return undefined;
  }

  private isAllowedOrigin(origin: string): boolean {
    const allowed = (process.env.CORS_ORIGINS ?? '').split(',').map((s) => s.trim());
    return allowed.includes(origin);
  }
}
