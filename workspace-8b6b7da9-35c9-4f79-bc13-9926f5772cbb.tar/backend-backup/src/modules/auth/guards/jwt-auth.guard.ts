import { Injectable } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { BusinessException, ErrorCode } from '../../../common/exceptions/business.exception';

/**
 * JwtAuthGuard — delegates to the 'jwt' Passport strategy (JwtStrategy).
 *
 * On success, `request.user` is populated with the validated payload:
 *   { id, email, role, kycStatus }
 *
 * On failure (no token / expired / invalid signature / user inactive),
 * throws BusinessException(UNAUTHORIZED) for the global filter to translate.
 */
@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {
  override handleRequest<TUser = unknown>(
    err: unknown,
    user: TUser | undefined,
    _info: unknown,
    _context: unknown,
  ): TUser {
    if (err) throw err;
    if (!user) {
      throw new BusinessException(
        ErrorCode.UNAUTHORIZED,
        'Authentication required — supply a valid Bearer token',
      );
    }
    return user;
  }
}
