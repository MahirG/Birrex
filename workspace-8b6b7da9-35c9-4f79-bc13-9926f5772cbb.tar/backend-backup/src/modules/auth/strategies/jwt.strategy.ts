import { Injectable, UnauthorizedException } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { getEnv } from '../../../config';
import { AuthService } from '../auth.service';
import { UserStatus } from '../../../database/entities';
import { BusinessException, ErrorCode } from '../../../common/exceptions/business.exception';

interface JwtAccessTokenPayload {
  sub: string;
  email: string;
  role: string;
  kycStatus: string;
  type: 'access' | 'refresh';
}

/**
 * JwtStrategy — used by Passport via @nestjs/passport.
 *
 * Extracts the Bearer token from the Authorization header, verifies the
 * signature with JWT_ACCESS_SECRET, and resolves the user from Postgres.
 *
 * We do NOT trust the JWT payload alone — we re-load the user from DB on
 * every request to catch recently-suspended accounts. The latency cost is
 * acceptable because every request also needs the latest kycStatus + role
 * anyway (those fields are on `request.user` and drive downstream guards).
 */
@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy, 'jwt') {
  constructor(private readonly authService: AuthService) {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: getEnv().JWT_ACCESS_SECRET,
    });
  }

  async validate(payload: JwtAccessTokenPayload): Promise<{
    id: string;
    email: string;
    role: string;
    kycStatus: string;
  }> {
    if (payload.type !== 'access') {
      throw new BusinessException(
        ErrorCode.INVALID_TOKEN,
        'Refresh tokens cannot be used for API access',
      );
    }
    const user = await this.authService.findUserById(payload.sub);
    if (!user) {
      throw new UnauthorizedException('User no longer exists');
    }
    if (user.status !== UserStatus.ACTIVE) {
      throw new BusinessException(
        ErrorCode.ACCOUNT_NOT_ACTIVE,
        `Account is ${user.status}`,
      );
    }
    // Return the LIVE role + kycStatus from DB — never trust the JWT payload
    // for authorization decisions because the user might have been promoted
    // (or had KYC revoked) after the token was issued.
    return {
      id: user.id,
      email: user.email,
      role: user.role,
      kycStatus: user.kycStatus,
    };
  }
}
