import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Dispute, DisputeEvidence, Trade } from '../../database/entities';
import { AuthModule } from '../auth/auth.module';
import { EscrowModule } from '../escrow/escrow.module';
import { WebSocketModule } from '../websocket/websocket.module';
import { StorageService } from '../../common/storage.service';
import { DisputeService } from './dispute.service';
import { DisputeController, AdminDisputeController } from './dispute.controller';

@Module({
  imports: [
    TypeOrmModule.forFeature([Dispute, DisputeEvidence, Trade]),
    AuthModule,
    EscrowModule,
    WebSocketModule,
  ],
  controllers: [DisputeController, AdminDisputeController],
  providers: [DisputeService, StorageService],
  exports: [DisputeService],
})
export class DisputesModule {}
