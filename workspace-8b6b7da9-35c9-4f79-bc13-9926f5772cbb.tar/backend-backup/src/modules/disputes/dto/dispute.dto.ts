import {
  IsEnum,
  IsOptional,
  IsString,
  IsUUID,
  IsArray,
  ValidateNested,
  Matches,
  MinLength,
  MaxLength,
} from 'class-validator';
import { Type } from 'class-transformer';
import {
  DisputePriority,
  DisputeStatus,
} from '../../../database/entities';

/**
 * EvidenceUploadDto — metadata for a single file attached to a dispute.
 * Same shape as KycDocumentUploadDto but kept separate because dispute
 * evidence supports more file types (zip, txt logs) than KYC documents.
 */
export class EvidenceUploadDto {
  @IsString()
  @Matches(/^(image\/(png|jpeg|webp)|application\/pdf|text\/plain|application\/zip)$/, {
    message: 'fileType must be image/png, image/jpeg, image/webp, application/pdf, text/plain, or application/zip',
  })
  fileType: string;

  @IsString()
  @Matches(/^\d+$/, { message: 'fileSizeBytes must be a positive integer string' })
  fileSizeBytes: string;

  @IsString()
  @Matches(/^[a-f0-9]{64}$/, { message: 'fileHash must be a SHA-256 hex digest' })
  fileHash: string;

  @IsString()
  fileContentBase64: string;

  @IsOptional()
  @IsString()
  @MaxLength(500)
  description?: string;
}

export class OpenDisputeDto {
  @IsUUID('4')
  tradeId: string;

  @IsString()
  @MinLength(5)
  @MaxLength(200)
  reason: string;

  @IsOptional()
  @IsString()
  @MaxLength(5000)
  description?: string;

  @IsOptional()
  @IsEnum(DisputePriority)
  priority?: DisputePriority;

  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => EvidenceUploadDto)
  evidence?: EvidenceUploadDto[];
}

export class AddEvidenceDto {
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => EvidenceUploadDto)
  evidence: EvidenceUploadDto[];
}

export class AssignDisputeDto {
  // Self-assignment: moderator calls assign with their own ID implicit via JWT.
  // This DTO is intentionally empty — the controller uses the JWT user ID.
}

export class ResolveDisputeDto {
  @IsEnum(DisputeStatus)
  resolution: DisputeStatus.RESOLVED_MAKER | DisputeStatus.RESOLVED_TAKER | DisputeStatus.RESOLVED_REFUND | DisputeStatus.ESCALATED;

  @IsString()
  @MinLength(5)
  @MaxLength(2000)
  resolutionNotes: string;
}

export interface DisputeResponse {
  id: string;
  tradeId: string;
  openedBy: string;
  againstUserId: string;
  reason: string;
  description: string | null;
  priority: string;
  status: string;
  assignedModeratorId: string | null;
  resolutionNotes: string | null;
  resolvedBy: string | null;
  resolvedAt: string | null;
  createdAt: string;
  updatedAt: string;
  evidence: Array<{
    id: string;
    uploadedBy: string;
    fileUrl: string;
    fileType: string;
    fileSizeBytes: string;
    fileHash: string;
    description: string | null;
    createdAt: string;
  }>;
}
