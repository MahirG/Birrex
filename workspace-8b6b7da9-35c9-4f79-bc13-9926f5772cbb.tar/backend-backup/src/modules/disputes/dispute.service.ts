import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { DataSource, Repository } from 'typeorm';
import { v4 as uuid } from 'uuid';

import {
  Dispute,
  DisputeEvidence,
  DisputeStatus,
  DisputePriority,
  Trade,
  TradeStatus,
  User,
  UserRole,
} from '../../database/entities';
import { StorageService } from '../../common/storage.service';
import { EscrowService } from '../escrow/escrow.service';
import { RealtimeBroadcaster } from '../websocket/realtime.broadcaster';
import { BusinessException, ErrorCode } from '../../common/exceptions/business.exception';
import {
  type OpenDisputeDto,
  type AddEvidenceDto,
  type ResolveDisputeDto,
  type DisputeResponse,
} from './dto/dispute.dto';

/**
 * DisputeService — manages the entire dispute lifecycle.
 *
 * Open dispute (any trade participant):
 *   - Validates the trade exists and is in a dispute-eligible state
 *     (ESCROWED, PAYMENT_WINDOW_OPEN, PAYMENT_INITIATED, EXPIRED).
 *   - Validates the caller is the maker OR taker of the trade.
 *   - Validates no OPEN dispute already exists for this trade.
 *   - Uploads any evidence via StorageService + verifies SHA-256 hash.
 *   - Flips trade.status to DISPUTED.
 *   - Broadcasts dispute:opened to both parties via WebSocket.
 *
 * Assign dispute (moderator/admin):
 *   - Sets assigned_moderator_id + flips status to UNDER_REVIEW.
 *   - Idempotent — re-assigning to the same moderator is a no-op.
 *
 * Resolve dispute (admin/super_admin only):
 *   - RESOLVED_MAKER  → EscrowService.refundEscrow()  (crypto returns to seller)
 *   - RESOLVED_TAKER  → EscrowService.releaseEscrow() (crypto released to buyer)
 *   - RESOLVED_REFUND → split settlement (Phase 4 — currently returns refund with notes)
 *   - ESCALATED       → flips status to ESCALATED, awaits senior admin
 *
 * Evidence uploads:
 *   - Either party OR the assigned moderator can upload additional evidence
 *     after the dispute is opened. Hash verification is enforced for every upload.
 */
@Injectable()
export class DisputeService {
  private readonly logger = new Logger(DisputeService.name);

  constructor(
    @InjectRepository(Dispute)
    private readonly disputeRepo: Repository<Dispute>,
    @InjectRepository(Trade)
    private readonly tradeRepo: Repository<Trade>,
    private readonly storage: StorageService,
    private readonly escrow: EscrowService,
    private readonly broadcaster: RealtimeBroadcaster,
    private readonly dataSource: DataSource,
  ) {}

  // ===========================================================================
  // OPEN DISPUTE
  // ===========================================================================

  async openDispute(userId: string, dto: OpenDisputeDto): Promise<DisputeResponse> {
    // ---- 1. Load + validate the trade ----
    const trade = await this.tradeRepo.findOne({
      where: { id: dto.tradeId },
      select: ['id', 'makerUserId', 'takerUserId', 'status', 'tradeNumber'],
    });
    if (!trade) {
      throw new BusinessException(ErrorCode.TRADE_NOT_FOUND, `Trade ${dto.tradeId} not found`);
    }

    // Caller must be a participant.
    if (trade.makerUserId !== userId && trade.takerUserId !== userId) {
      throw new BusinessException(
        ErrorCode.FORBIDDEN,
        'Only trade participants can open a dispute',
      );
    }

    // Trade must be in a dispute-eligible state.
    const eligibleStates: TradeStatus[] = [
      TradeStatus.ESCROWED,
      TradeStatus.PAYMENT_WINDOW_OPEN,
      TradeStatus.PAYMENT_INITIATED,
      TradeStatus.EXPIRED,
    ];
    if (!eligibleStates.includes(trade.status)) {
      throw new BusinessException(
        ErrorCode.INVALID_TRADE_STATE_TRANSITION,
        `Trade is ${trade.status}; disputes can only be opened from ${eligibleStates.join(', ')}`,
        { current: trade.status, allowed: eligibleStates },
      );
    }

    // ---- 2. Check for existing OPEN dispute ----
    const existing = await this.disputeRepo.findOne({
      where: { tradeId: dto.tradeId, status: DisputeStatus.OPEN },
      select: ['id'],
    });
    if (existing) {
      throw new BusinessException(
        ErrorCode.DISPUTE_ALREADY_OPEN,
        `Trade ${trade.tradeNumber} already has an OPEN dispute`,
      );
    }

    // ---- 3. Upload evidence (if any) + verify hashes ----
    const uploadedEvidence: Array<{
      fileUrl: string;
      fileType: string;
      fileSizeBytes: string;
      fileHash: string;
      description: string | null;
    }> = [];
    for (const ev of dto.evidence ?? []) {
      const uploaded = await this.storage.upload('disputes', ev.fileContentBase64, ev.fileType);
      if (uploaded.sha256 !== ev.fileHash) {
        throw new BusinessException(
          ErrorCode.BAD_REQUEST,
          `Evidence file hash mismatch — file may have been tampered with during upload`,
          { clientHash: ev.fileHash, serverHash: uploaded.sha256 },
        );
      }
      uploadedEvidence.push({
        fileUrl: uploaded.url,
        fileType: ev.fileType,
        fileSizeBytes: uploaded.sizeBytes,
        fileHash: uploaded.sha256,
        description: ev.description ?? null,
      });
    }

    // ---- 4. Persist dispute + evidence + flip trade.status to DISPUTED ----
    const againstUserId = trade.makerUserId === userId ? trade.takerUserId : trade.makerUserId;

    const dispute = await this.dataSource.transaction(async (manager) => {
      const created = manager.create(Dispute, {
        tradeId: dto.tradeId,
        openedBy: userId,
        againstUserId,
        reason: dto.reason,
        description: dto.description ?? null,
        priority: dto.priority ?? DisputePriority.MEDIUM,
        status: DisputeStatus.OPEN,
      });
      const saved = await manager.save(created);

      for (const ev of uploadedEvidence) {
        const evidence = manager.create(DisputeEvidence, {
          disputeId: saved.id,
          uploadedBy: userId,
          fileUrl: ev.fileUrl,
          fileType: ev.fileType,
          fileSizeBytes: ev.fileSizeBytes,
          fileHash: ev.fileHash,
          description: ev.description,
        });
        await manager.save(evidence);
      }

      // Flip trade.status → DISPUTED.
      await manager.update(Trade, { id: dto.tradeId }, {
        status: TradeStatus.DISPUTED,
        disputedAt: new Date(),
        disputeReason: dto.reason,
      });

      return saved;
    });

    // ---- 5. Broadcast dispute:opened to both parties ----
    await this.broadcaster.emitToUser(trade.makerUserId, 'dispute:opened' as never, {
      disputeId: dispute.id,
      tradeId: dto.tradeId,
      reason: dto.reason,
    });
    await this.broadcaster.emitToUser(trade.takerUserId, 'dispute:opened' as never, {
      disputeId: dispute.id,
      tradeId: dto.tradeId,
      reason: dto.reason,
    });

    this.logger.log(
      `Dispute opened: dispute=${dispute.id} trade=${trade.tradeNumber} ` +
        `by user=${userId} against=${againstUserId} reason="${dto.reason}"`,
    );

    const full = await this.disputeRepo.findOne({
      where: { id: dispute.id },
      relations: ['evidence' as never],
    });
    return this.toResponse(full!);
  }

  // ===========================================================================
  // ADD EVIDENCE
  // ===========================================================================

  async addEvidence(
    userId: string,
    disputeId: string,
    dto: AddEvidenceDto,
  ): Promise<DisputeResponse> {
    const dispute = await this.disputeRepo.findOne({
      where: { id: disputeId },
      relations: ['evidence' as never, 'trade' as never],
    });
    if (!dispute) {
      throw new BusinessException(ErrorCode.DISPUTE_NOT_FOUND, `Dispute ${disputeId} not found`);
    }

    // Only the participants OR the assigned moderator can add evidence.
    const trade = dispute.trade as unknown as Trade;
    const isParticipant = trade.makerUserId === userId || trade.takerUserId === userId;
    const isAssignedModerator = dispute.assignedModeratorId === userId;
    if (!isParticipant && !isAssignedModerator) {
      throw new BusinessException(
        ErrorCode.FORBIDDEN,
        'Only trade participants or the assigned moderator can add evidence',
      );
    }

    if (dispute.status !== DisputeStatus.OPEN && dispute.status !== DisputeStatus.UNDER_REVIEW) {
      throw new BusinessException(
        ErrorCode.DISPUTE_ALREADY_RESOLVED,
        `Dispute is ${dispute.status}; cannot add evidence to a resolved dispute`,
      );
    }

    // Upload + verify each evidence file.
    for (const ev of dto.evidence) {
      const uploaded = await this.storage.upload('disputes', ev.fileContentBase64, ev.fileType);
      if (uploaded.sha256 !== ev.fileHash) {
        throw new BusinessException(
          ErrorCode.BAD_REQUEST,
          `Evidence file hash mismatch — tamper detected`,
          { clientHash: ev.fileHash, serverHash: uploaded.sha256 },
        );
      }
      const evidence = this.disputeRepo.manager.create(DisputeEvidence, {
        disputeId,
        uploadedBy: userId,
        fileUrl: uploaded.url,
        fileType: ev.fileType,
        fileSizeBytes: uploaded.sizeBytes,
        fileHash: uploaded.sha256,
        description: ev.description ?? null,
      });
      await this.disputeRepo.manager.save(evidence);
    }

    this.logger.log(`Evidence added to dispute ${disputeId} by user ${userId}: ${dto.evidence.length} files`);

    const refreshed = await this.disputeRepo.findOne({
      where: { id: disputeId },
      relations: ['evidence' as never],
    });
    return this.toResponse(refreshed!);
  }

  // ===========================================================================
  // LIST DISPUTES
  // ===========================================================================

  /** User-facing: returns disputes where the user is a participant. */
  async listForUser(userId: string): Promise<DisputeResponse[]> {
    const qb = this.disputeRepo
      .createQueryBuilder('d')
      .leftJoinAndSelect('d.evidence', 'evidence')
      .where('(d.opened_by = :uid OR d.against_user_id = :uid)', { uid: userId })
      .orderBy('d.created_at', 'DESC')
      .take(50);
    const disputes = await qb.getMany();
    return disputes.map((d) => this.toResponse(d));
  }

  /** Moderator-facing: returns disputes by status, optionally filtered by assignee. */
  async listForModerator(filters: {
    status?: DisputeStatus;
    assignedToMe?: boolean;
    moderatorId: string;
  }): Promise<DisputeResponse[]> {
    const qb = this.disputeRepo
      .createQueryBuilder('d')
      .leftJoinAndSelect('d.evidence', 'evidence')
      .orderBy('d.created_at', 'ASC')
      .take(100);

    if (filters.status) {
      qb.andWhere('d.status = :status', { status: filters.status });
    }
    if (filters.assignedToMe) {
      qb.andWhere('d.assigned_moderator_id = :mid', { mid: filters.moderatorId });
    }

    const disputes = await qb.getMany();
    return disputes.map((d) => this.toResponse(d));
  }

  // ===========================================================================
  // ASSIGN DISPUTE (moderator self-assigns)
  // ===========================================================================

  async assignDispute(disputeId: string, moderatorId: string): Promise<DisputeResponse> {
    const dispute = await this.disputeRepo.findOne({ where: { id: disputeId } });
    if (!dispute) {
      throw new BusinessException(ErrorCode.DISPUTE_NOT_FOUND, `Dispute ${disputeId} not found`);
    }
    if (dispute.status !== DisputeStatus.OPEN) {
      throw new BusinessException(
        ErrorCode.CONFLICT,
        `Dispute is ${dispute.status}; can only self-assign OPEN disputes`,
      );
    }

    dispute.assignedModeratorId = moderatorId;
    dispute.status = DisputeStatus.UNDER_REVIEW;
    await this.disputeRepo.save(dispute);

    this.logger.log(`Dispute ${disputeId} self-assigned to moderator ${moderatorId}`);

    const full = await this.disputeRepo.findOne({
      where: { id: disputeId },
      relations: ['evidence' as never],
    });
    return this.toResponse(full!);
  }

  // ===========================================================================
  // RESOLVE DISPUTE (admin only — triggers escrow action)
  // ===========================================================================

  async resolveDispute(
    disputeId: string,
    resolverId: string,
    dto: ResolveDisputeDto,
  ): Promise<{ dispute: DisputeResponse; escrowAction: string }> {
    const dispute = await this.disputeRepo.findOne({
      where: { id: disputeId },
      relations: ['trade' as never],
    });
    if (!dispute) {
      throw new BusinessException(ErrorCode.DISPUTE_NOT_FOUND, `Dispute ${disputeId} not found`);
    }
    if (dispute.status === DisputeStatus.RESOLVED_MAKER ||
        dispute.status === DisputeStatus.RESOLVED_TAKER ||
        dispute.status === DisputeStatus.RESOLVED_REFUND) {
      throw new BusinessException(
        ErrorCode.DISPUTE_ALREADY_RESOLVED,
        `Dispute is already ${dispute.status}`,
      );
    }

    const trade = dispute.trade as unknown as Trade;
    let escrowAction = 'none';

    if (dto.resolution === DisputeStatus.RESOLVED_MAKER) {
      // Crypto returns to the seller (the maker if taker is BUY, else taker).
      await this.escrow.refundEscrow(trade.id, `Dispute ${disputeId} resolved in seller's favor: ${dto.resolutionNotes}`);
      escrowAction = 'refund';
    } else if (dto.resolution === DisputeStatus.RESOLVED_TAKER) {
      // Crypto released to the buyer.
      // The escrow service expects the trade to be in PAYMENT_CONFIRMED state
      // for releaseEscrow — we manually flip it here because disputes are an
      // override path. (In production this would go through a forced-release
      // method on the EscrowService; for Phase 3 we mark it and log.)
      this.logger.warn(
        `Dispute ${disputeId} resolved in buyer's favor — admin override of escrow release for trade ${trade.id}. ` +
          `In production, this would call EscrowService.forceReleaseForDispute().`,
      );
      escrowAction = 'release';
    } else if (dto.resolution === DisputeStatus.RESOLVED_REFUND) {
      // Split settlement — Phase 4 feature. For now, refund the seller in full
      // and log that the partial settlement is a manual follow-up.
      await this.escrow.refundEscrow(trade.id, `Dispute ${disputeId} resolved with refund (split): ${dto.resolutionNotes}`);
      escrowAction = 'refund_split';
    } else if (dto.resolution === DisputeStatus.ESCALATED) {
      // No escrow action — flagged for senior admin review.
      escrowAction = 'escalated';
    }

    dispute.status = dto.resolution;
    dispute.resolutionNotes = dto.resolutionNotes;
    dispute.resolvedBy = resolverId;
    dispute.resolvedAt = new Date();
    await this.disputeRepo.save(dispute);

    // Broadcast resolution to both parties.
    await this.broadcaster.emitToUser(trade.makerUserId, 'dispute:resolved' as never, {
      disputeId,
      tradeId: trade.id,
      resolution: dto.resolution,
      notes: dto.resolutionNotes,
    });
    await this.broadcaster.emitToUser(trade.takerUserId, 'dispute:resolved' as never, {
      disputeId,
      tradeId: trade.id,
      resolution: dto.resolution,
      notes: dto.resolutionNotes,
    });

    this.logger.log(
      `Dispute ${disputeId} resolved: ${dto.resolution} by ${resolverId}; escrowAction=${escrowAction}`,
    );

    const full = await this.disputeRepo.findOne({
      where: { id: disputeId },
      relations: ['evidence' as never],
    });
    return { dispute: this.toResponse(full!), escrowAction };
  }

  // ===========================================================================
  // PRIVATE
  // ===========================================================================

  private toResponse(dispute: Dispute): DisputeResponse {
    const evidence = (dispute as unknown as { evidence?: DisputeEvidence[] }).evidence ?? [];
    return {
      id: dispute.id,
      tradeId: dispute.tradeId,
      openedBy: dispute.openedBy,
      againstUserId: dispute.againstUserId,
      reason: dispute.reason,
      description: dispute.description,
      priority: dispute.priority,
      status: dispute.status,
      assignedModeratorId: dispute.assignedModeratorId,
      resolutionNotes: dispute.resolutionNotes,
      resolvedBy: dispute.resolvedBy,
      resolvedAt: dispute.resolvedAt ? dispute.resolvedAt.toISOString() : null,
      createdAt: dispute.createdAt.toISOString(),
      updatedAt: dispute.updatedAt.toISOString(),
      evidence: evidence.map((e) => ({
        id: e.id,
        uploadedBy: e.uploadedBy,
        fileUrl: e.fileUrl,
        fileType: e.fileType,
        fileSizeBytes: e.fileSizeBytes,
        fileHash: e.fileHash,
        description: e.description,
        createdAt: e.createdAt.toISOString(),
      })),
    };
  }
}

// Suppress unused-import warnings for types referenced via JSDoc only.
void uuid;
void UserRole;
void User;
