import {
  Body,
  Controller,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  Post,
  Query,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { ThrottlerGuard } from '@nestjs/throttler';

import { DisputeService } from './dispute.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CsrfGuard } from '../auth/guards/csrf.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { CurrentUser, type AuthUser } from '../../common/decorators/current-user.decorator';
import { LoggingInterceptor } from '../../common/interceptors/logging.interceptor';
import {
  OpenDisputeDto,
  AddEvidenceDto,
  ResolveDisputeDto,
  type DisputeResponse,
} from './dto/dispute.dto';
import { DisputeStatus, UserRole } from '../../database/entities';

/**
 * DisputeController — user-facing dispute endpoints.
 *
 *   POST /v1/disputes                    — open a dispute against a trade
 *   POST /v1/disputes/:id/evidence       — add evidence to an existing dispute
 *   GET  /v1/disputes                    — list my disputes (as participant)
 *   GET  /v1/disputes/:id                — get a single dispute
 */
@Controller('v1/disputes')
@UseGuards(JwtAuthGuard, ThrottlerGuard)
@UseInterceptors(LoggingInterceptor)
export class DisputeController {
  constructor(private readonly disputeService: DisputeService) {}

  @Post()
  @HttpCode(HttpStatus.CREATED)
  @UseGuards(CsrfGuard)
  async open(@CurrentUser() user: AuthUser, @Body() dto: OpenDisputeDto): Promise<DisputeResponse> {
    return this.disputeService.openDispute(user.id, dto);
  }

  @Post(':id/evidence')
  @HttpCode(HttpStatus.OK)
  @UseGuards(CsrfGuard)
  async addEvidence(
    @CurrentUser() user: AuthUser,
    @Param('id') disputeId: string,
    @Body() dto: AddEvidenceDto,
  ): Promise<DisputeResponse> {
    return this.disputeService.addEvidence(user.id, disputeId, dto);
  }

  @Get()
  @HttpCode(HttpStatus.OK)
  async listMine(@CurrentUser() user: AuthUser): Promise<DisputeResponse[]> {
    return this.disputeService.listForUser(user.id);
  }
}

/**
 * AdminDisputeController — moderator/admin-only dispute review endpoints.
 *
 *   GET  /v1/admin/disputes               — list disputes (filterable by status/assignee)
 *   POST /v1/admin/disputes/:id/assign    — self-assign an OPEN dispute
 *   POST /v1/admin/disputes/:id/resolve   — resolve (admin only; triggers escrow action)
 */
@Controller('v1/admin/disputes')
@UseGuards(JwtAuthGuard, RolesGuard, CsrfGuard, ThrottlerGuard)
@UseInterceptors(LoggingInterceptor)
export class AdminDisputeController {
  constructor(private readonly disputeService: DisputeService) {}

  @Get()
  @HttpCode(HttpStatus.OK)
  @Roles(UserRole.MODERATOR, UserRole.ADMIN, UserRole.SUPER_ADMIN)
  async list(
    @CurrentUser() user: AuthUser,
    @Query('status') status?: DisputeStatus,
    @Query('assignedToMe') assignedToMe?: string,
  ): Promise<DisputeResponse[]> {
    return this.disputeService.listForModerator({
      status,
      assignedToMe: assignedToMe === 'true',
      moderatorId: user.id,
    });
  }

  @Post(':id/assign')
  @HttpCode(HttpStatus.OK)
  @Roles(UserRole.MODERATOR, UserRole.ADMIN, UserRole.SUPER_ADMIN)
  async assign(
    @CurrentUser() user: AuthUser,
    @Param('id') disputeId: string,
  ): Promise<DisputeResponse> {
    return this.disputeService.assignDispute(disputeId, user.id);
  }

  @Post(':id/resolve')
  @HttpCode(HttpStatus.OK)
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN)
  async resolve(
    @CurrentUser() user: AuthUser,
    @Param('id') disputeId: string,
    @Body() dto: ResolveDisputeDto,
  ) {
    return this.disputeService.resolveDispute(disputeId, user.id, dto);
  }
}
