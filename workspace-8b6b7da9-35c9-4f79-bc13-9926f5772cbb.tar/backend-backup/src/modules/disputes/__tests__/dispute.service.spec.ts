import { Test, type TestingModule } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { v4 as uuid } from 'uuid';
import { createHash } from 'crypto';

import { DisputeService } from '../dispute.service';
import { StorageService, type UploadedFile } from '../../../common/storage.service';
import { EscrowService } from '../../escrow/escrow.service';
import { RealtimeBroadcaster } from '../../websocket/realtime.broadcaster';
import {
  Dispute,
  DisputeEvidence,
  DisputeStatus,
  DisputePriority,
  Trade,
  TradeStatus,
  OrderSide,
} from '../../../database/entities';
import {
  ErrorCode,
} from '../../../common/exceptions/business.exception';
import type { OpenDisputeDto, ResolveDisputeDto } from '../dto/dispute.dto';

/**
 * Dispute tests verify:
 *   1. Happy-path open: dispute created + trade flipped to DISPUTED.
 *   2. Non-participant cannot open a dispute (FORBIDDEN).
 *   3. Trade not in dispute-eligible state → rejected.
 *   4. Cannot open a second OPEN dispute for the same trade.
 *   5. Evidence upload with hash mismatch → tamper detected.
 *   6. Self-assign flips to UNDER_REVIEW.
 *   7. Resolve RESOLVED_MAKER triggers escrow.refundEscrow.
 *   8. Cannot resolve an already-resolved dispute.
 *   9. Non-moderator cannot self-assign (role guard — tested in e2e).
 *  10. addEvidence: only participants + assigned moderator can upload.
 */

class MockState {
  trades = new Map<string, Trade>();
  disputes = new Map<string, Dispute>();
  evidence = new Map<string, DisputeEvidence>();
}

class MockDisputeRepo {
  constructor(private readonly state: MockState) {}

  create<E extends object>(entity: new (...args: unknown[]) => E, data: Partial<E>): E {
    return Object.assign(new entity(), data) as E;
  }

  get manager(): { create: <E extends object>(e: new (...args: unknown[]) => E, d: Partial<E>) => E; save: <E>(e: E) => Promise<E> } {
    const self = this;
    return {
      create: <E extends object>(entity: new (...args: unknown[]) => E, data: Partial<E>): E =>
        Object.assign(new entity(), data) as E,
      save: async <E,>(entity: E): Promise<E> => {
        const obj = entity as unknown as { id?: string };
        if (obj instanceof DisputeEvidence) {
          if (!obj.id) obj.id = uuid();
          if (!obj.createdAt) obj.createdAt = new Date();
          self.state.evidence.set(obj.id, obj);
        }
        return entity;
      },
    };
  }

  async findOne(options: {
    where: Record<string, unknown>;
    relations?: string[];
    select?: string[];
  }): Promise<Dispute | null> {
    const where = options.where;
    let matched: Dispute | undefined;
    for (const d of this.state.disputes.values()) {
      let allMatch = true;
      for (const [k, v] of Object.entries(where)) {
        if ((d as unknown as Record<string, unknown>)[k] !== v) {
          allMatch = false;
          break;
        }
      }
      if (allMatch) {
        matched = d;
        break;
      }
    }
    if (!matched) return null;
    if (options.relations?.includes('evidence')) {
      (matched as unknown as { evidence: DisputeEvidence[] }).evidence = [...this.state.evidence.values()]
        .filter((e) => e.disputeId === matched!.id);
    }
    if (options.relations?.includes('trade')) {
      (matched as unknown as { trade: Trade }).trade = this.state.trades.get(matched.tradeId)!;
    }
    return matched;
  }

  async find(): Promise<Dispute[]> {
    return [...this.state.disputes.values()];
  }

  async save<E>(entity: E | E[]): Promise<E | E[]> {
    if (Array.isArray(entity)) {
      return Promise.all(entity.map((e) => this.save(e))) as unknown as Promise<E[]>;
    }
    const obj = entity as unknown as { id?: string };
    if (obj instanceof Dispute) {
      if (!obj.id) obj.id = uuid();
      if (!obj.createdAt) obj.createdAt = new Date();
      obj.updatedAt = new Date();
      this.state.disputes.set(obj.id, obj);
    } else if (obj instanceof DisputeEvidence) {
      if (!obj.id) obj.id = uuid();
      if (!obj.createdAt) obj.createdAt = new Date();
      this.state.evidence.set(obj.id, obj);
    }
    return entity;
  }

  createQueryBuilder(_alias: string) {
    const self = this;
    const filters: { userId?: string; status?: string; assignedModeratorId?: string } = {};
    let orderByField = 'created_at';
    let orderDir: 'ASC' | 'DESC' = 'DESC';
    let take = 50;

    const builder = {
      leftJoinAndSelect() { return builder; },
      where(_clause: string, params: Record<string, unknown>) {
        if ('uid' in params) filters.userId = params.uid as string;
        return builder;
      },
      andWhere(_clause: string, params: Record<string, unknown>) {
        if ('status' in params) filters.status = params.status as string;
        if ('mid' in params) filters.assignedModeratorId = params.mid as string;
        return builder;
      },
      orderBy(field: string, dir: 'ASC' | 'DESC') {
        orderByField = field;
        orderDir = dir;
        return builder;
      },
      take(n: number) { take = n; return builder; },
      async getMany(): Promise<Dispute[]> {
        let arr = [...self.state.disputes.values()];
        if (filters.userId) {
          arr = arr.filter((d) => d.openedBy === filters.userId || d.againstUserId === filters.userId);
        }
        if (filters.status) {
          arr = arr.filter((d) => d.status === filters.status);
        }
        if (filters.assignedModeratorId) {
          arr = arr.filter((d) => d.assignedModeratorId === filters.assignedModeratorId);
        }
        arr.sort((a, b) => {
          const cmp = a.createdAt.getTime() - b.createdAt.getTime();
          return orderDir === 'ASC' ? cmp : -cmp;
        });
        return arr.slice(0, take);
      },
    };
    void orderByField;
    return builder;
  }
}

class MockTradeRepo {
  constructor(private readonly state: MockState) {}

  async findOne(options: { where: Record<string, unknown>; select?: string[] }): Promise<Trade | null> {
    const id = options.where.id as string;
    return this.state.trades.get(id) ?? null;
  }

  async update(criteria: { id: string }, partial: Partial<Trade>): Promise<{ affected: number }> {
    const t = this.state.trades.get(criteria.id);
    if (!t) return { affected: 0 };
    Object.assign(t, partial);
    return { affected: 1 };
  }
}

class MockEntityManager {
  constructor(private readonly state: MockState) {}

  create<E extends object>(entity: new (...args: unknown[]) => E, data: Partial<E>): E {
    return Object.assign(new entity(), data) as E;
  }

  async save<E>(entity: E | E[]): Promise<E | E[]> {
    if (Array.isArray(entity)) {
      return Promise.all(entity.map((e) => this.save(e))) as unknown as Promise<E[]>;
    }
    const obj = entity as unknown as { id?: string };
    if (obj instanceof Dispute) {
      if (!obj.id) obj.id = uuid();
      if (!obj.createdAt) obj.createdAt = new Date();
      obj.updatedAt = new Date();
      this.state.disputes.set(obj.id, obj);
    } else if (obj instanceof DisputeEvidence) {
      if (!obj.id) obj.id = uuid();
      if (!obj.createdAt) obj.createdAt = new Date();
      this.state.evidence.set(obj.id, obj);
    }
    return entity;
  }

  async update(
    entity: new (...args: unknown[]) => unknown,
    criteria: { id: string },
    partial: Record<string, unknown>,
  ): Promise<{ affected: number }> {
    if (entity === Trade) {
      const t = this.state.trades.get(criteria.id);
      if (!t) return { affected: 0 };
      Object.assign(t, partial);
      return { affected: 1 };
    }
    return { affected: 0 };
  }
}

class MockDataSource {
  state = new MockState();

  async transaction<T>(fn: (manager: MockEntityManager) => Promise<T>): Promise<T> {
    return fn(new MockEntityManager(this.state));
  }
}

describe('DisputeService', () => {
  let service: DisputeService;
  let ds: MockDataSource;
  let disputeRepo: MockDisputeRepo;
  let tradeRepo: MockTradeRepo;
  let storage: StorageService;
  let escrow: EscrowService;
  let broadcaster: RealtimeBroadcaster;
  let trade: Trade;
  let makerId: string;
  let takerId: string;
  let strangerId: string;

  beforeEach(async () => {
    ds = new MockDataSource();
    disputeRepo = new MockDisputeRepo(ds.state);
    tradeRepo = new MockTradeRepo(ds.state);

    storage = {
      upload: async (namespace: 'kyc' | 'disputes', contentBase64: string, mimeType: string): Promise<UploadedFile> => {
        const bytes = Buffer.from(contentBase64, 'base64');
        const sha256 = createHash('sha256').update(bytes).digest('hex');
        return {
          url: `s3://${namespace}-bucket/${sha256.slice(0, 16)}`,
          sha256,
          sizeBytes: bytes.length.toString(),
          mimeType,
        };
      },
    } as unknown as StorageService;

    escrow = {
      refundEscrow: jest.fn().mockResolvedValue({ id: 'refund-txn' }),
      releaseEscrow: jest.fn().mockResolvedValue({ id: 'release-txn' }),
    } as unknown as EscrowService;

    broadcaster = {
      emitToUser: jest.fn().mockResolvedValue(undefined),
      initForTesting: jest.fn(),
    } as unknown as RealtimeBroadcaster;
    broadcaster.initForTesting();

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        DisputeService,
        { provide: getRepositoryToken(Dispute), useValue: disputeRepo },
        { provide: getRepositoryToken(Trade), useValue: tradeRepo },
        { provide: StorageService, useValue: storage },
        { provide: EscrowService, useValue: escrow },
        { provide: RealtimeBroadcaster, useValue: broadcaster },
        { provide: DataSource, useValue: ds },
      ],
    }).compile();

    service = module.get(DisputeService);

    // Seed a trade with both maker and taker.
    makerId = uuid();
    takerId = uuid();
    strangerId = uuid();
    trade = {
      id: uuid(),
      tradeNumber: 'TRD-20260625-00001',
      makerOrderId: uuid(),
      takerOrderId: uuid(),
      makerUserId: makerId,
      takerUserId: takerId,
      pair: 'USD_ETB',
      side: OrderSide.BUY,
      price: '120',
      quantity: '100',
      totalValue: '12000',
      escrowWalletId: uuid(),
      cryptoLockedAmount: '100',
      paymentMethodId: null,
      paymentReference: null,
      paymentScreenshotUrl: null,
      paymentInitiatedAt: null,
      paymentConfirmedAt: null,
      paymentWindowMinutes: 30,
      paymentWindowExpiresAt: new Date(Date.now() + 30 * 60_000),
      status: TradeStatus.ESCROWED,
      makerFee: '0',
      takerFee: '0.5',
      disputedAt: null,
      disputeReason: null,
      createdAt: new Date(),
      updatedAt: new Date(),
      completedAt: null,
      cancelledAt: null,
      cancelledBy: null,
      cancelReason: null,
    } as unknown as Trade;
    ds.state.trades.set(trade.id, trade);
  });

  // ===========================================================================
  // OPEN DISPUTE
  // ===========================================================================
  describe('openDispute', () => {
    it('creates a dispute + flips trade.status to DISPUTED + broadcasts to both parties', async () => {
      const dto: OpenDisputeDto = {
        tradeId: trade.id,
        reason: 'Taker marked payment sent but I never received the Telebirr transfer',
        description: 'I checked my Telebirr app and there is no incoming transaction.',
        priority: DisputePriority.HIGH,
      };

      const result = await service.openDispute(makerId, dto);

      expect(result.status).toBe(DisputeStatus.OPEN);
      expect(result.openedBy).toBe(makerId);
      expect(result.againstUserId).toBe(takerId);
      expect(result.priority).toBe(DisputePriority.HIGH);

      // Trade should have been flipped to DISPUTED.
      const updatedTrade = ds.state.trades.get(trade.id)!;
      expect(updatedTrade.status).toBe(TradeStatus.DISPUTED);
      expect(updatedTrade.disputedAt).not.toBeNull();
      expect(updatedTrade.disputeReason).toContain('Taker marked payment sent');

      // Broadcast to both parties.
      expect(broadcaster.emitToUser).toHaveBeenCalledWith(
        makerId,
        'dispute:opened',
        expect.objectContaining({ disputeId: result.id, tradeId: trade.id }),
      );
      expect(broadcaster.emitToUser).toHaveBeenCalledWith(
        takerId,
        'dispute:opened',
        expect.objectContaining({ disputeId: result.id, tradeId: trade.id }),
      );
    });

    it('rejects a non-participant from opening a dispute (FORBIDDEN)', async () => {
      const dto: OpenDisputeDto = {
        tradeId: trade.id,
        reason: 'Some reason',
      };
      await expect(service.openDispute(strangerId, dto)).rejects.toMatchObject({
        errorCode: ErrorCode.FORBIDDEN,
      });
    });

    it('rejects opening a dispute on a trade that is already RELEASED', async () => {
      trade.status = TradeStatus.RELEASED;
      ds.state.trades.set(trade.id, trade);

      await expect(
        service.openDispute(makerId, { tradeId: trade.id, reason: 'some reason' }),
      ).rejects.toMatchObject({
        errorCode: ErrorCode.INVALID_TRADE_STATE_TRANSITION,
      });
    });

    it('prevents a second dispute on the same trade (trade is already DISPUTED)', async () => {
      await service.openDispute(makerId, { tradeId: trade.id, reason: 'first dispute' });

      // The trade's status is now DISPUTED, which is not in the eligible set —
      // so the second open attempt fails with INVALID_TRADE_STATE_TRANSITION
      // (the eligibility check runs before the duplicate-dispute check).
      await expect(
        service.openDispute(takerId, { tradeId: trade.id, reason: 'second dispute' }),
      ).rejects.toMatchObject({
        errorCode: ErrorCode.INVALID_TRADE_STATE_TRANSITION,
      });
    });

    it('uploads evidence + verifies SHA-256 hash + persists DisputeEvidence rows', async () => {
      const content = Buffer.from('telebirr-screenshot-bytes').toString('base64');
      const hash = createHash('sha256').update('telebirr-screenshot-bytes').digest('hex');

      const result = await service.openDispute(makerId, {
        tradeId: trade.id,
        reason: 'No payment received',
        evidence: [
          {
            fileType: 'image/png',
            fileSizeBytes: '24',
            fileHash: hash,
            fileContentBase64: content,
            description: 'My Telebirr inbox showing no incoming transfer',
          },
        ],
      });

      expect(result.evidence).toHaveLength(1);
      expect(result.evidence[0]!.fileHash).toBe(hash);
      expect(result.evidence[0]!.description).toContain('Telebirr inbox');
    });

    it('detects tampering when client hash ≠ server hash', async () => {
      const content = Buffer.from('real-bytes').toString('base64');
      const wrongHash = 'a'.repeat(64); // wrong hash

      await expect(
        service.openDispute(makerId, {
          tradeId: trade.id,
          reason: 'No payment',
          evidence: [
            { fileType: 'image/png', fileSizeBytes: '9', fileHash: wrongHash, fileContentBase64: content },
          ],
        }),
      ).rejects.toMatchObject({
        errorCode: ErrorCode.BAD_REQUEST,
        message: expect.stringContaining('hash mismatch'),
      });

      // Trade should NOT be flipped to DISPUTED (atomic rollback).
      expect(ds.state.trades.get(trade.id)!.status).toBe(TradeStatus.ESCROWED);
    });
  });

  // ===========================================================================
  // ADD EVIDENCE
  // ===========================================================================
  describe('addEvidence', () => {
    it('allows a participant to add evidence to an OPEN dispute', async () => {
      const dispute = await service.openDispute(makerId, { tradeId: trade.id, reason: 'test' });

      const content = Buffer.from('extra-evidence').toString('base64');
      const hash = createHash('sha256').update('extra-evidence').digest('hex');

      const result = await service.addEvidence(takerId, dispute.id, {
        evidence: [
          { fileType: 'image/png', fileSizeBytes: '14', fileHash: hash, fileContentBase64: content },
        ],
      });

      // Original dispute has 0 evidence; after add it should have 1.
      expect(result.evidence).toHaveLength(1);
      expect(result.evidence[0]!.uploadedBy).toBe(takerId);
    });

    it('rejects a stranger from adding evidence', async () => {
      const dispute = await service.openDispute(makerId, { tradeId: trade.id, reason: 'test' });

      const content = Buffer.from('x').toString('base64');
      const hash = createHash('sha256').update('x').digest('hex');

      await expect(
        service.addEvidence(strangerId, dispute.id, {
          evidence: [
            { fileType: 'image/png', fileSizeBytes: '1', fileHash: hash, fileContentBase64: content },
          ],
        }),
      ).rejects.toMatchObject({ errorCode: ErrorCode.FORBIDDEN });
    });
  });

  // ===========================================================================
  // ASSIGN
  // ===========================================================================
  describe('assignDispute', () => {
    it('self-assigns an OPEN dispute + flips to UNDER_REVIEW', async () => {
      const dispute = await service.openDispute(makerId, { tradeId: trade.id, reason: 'test' });
      const moderatorId = uuid();

      const result = await service.assignDispute(dispute.id, moderatorId);

      expect(result.status).toBe(DisputeStatus.UNDER_REVIEW);
      expect(result.assignedModeratorId).toBe(moderatorId);
    });

    it('refuses to assign an already-UNDER_REVIEW dispute', async () => {
      const dispute = await service.openDispute(makerId, { tradeId: trade.id, reason: 'test' });
      await service.assignDispute(dispute.id, uuid());

      await expect(
        service.assignDispute(dispute.id, uuid()),
      ).rejects.toMatchObject({ errorCode: ErrorCode.CONFLICT });
    });
  });

  // ===========================================================================
  // RESOLVE
  // ===========================================================================
  describe('resolveDispute', () => {
    it('RESOLVED_MAKER triggers escrow.refundEscrow + flips dispute status', async () => {
      const dispute = await service.openDispute(makerId, { tradeId: trade.id, reason: 'test' });
      const adminId = uuid();

      const dto: ResolveDisputeDto = {
        resolution: DisputeStatus.RESOLVED_MAKER,
        resolutionNotes: 'Maker provided bank statement showing no incoming transfer; taker failed to provide proof of payment.',
      };

      const result = await service.resolveDispute(dispute.id, adminId, dto);

      expect(result.dispute.status).toBe(DisputeStatus.RESOLVED_MAKER);
      expect(result.dispute.resolvedBy).toBe(adminId);
      expect(result.dispute.resolvedAt).not.toBeNull();
      expect(result.dispute.resolutionNotes).toContain('bank statement');
      expect(result.escrowAction).toBe('refund');

      expect(escrow.refundEscrow).toHaveBeenCalledWith(
        trade.id,
        expect.stringContaining(`Dispute ${dispute.id} resolved in seller's favor`),
      );
    });

    it('RESOLVED_TAKER triggers escrow release path', async () => {
      const dispute = await service.openDispute(makerId, { tradeId: trade.id, reason: 'test' });
      const adminId = uuid();

      const result = await service.resolveDispute(dispute.id, adminId, {
        resolution: DisputeStatus.RESOLVED_TAKER,
        resolutionNotes: 'Taker provided Telebirr receipt; maker failed to release crypto.',
      });

      expect(result.dispute.status).toBe(DisputeStatus.RESOLVED_TAKER);
      expect(result.escrowAction).toBe('release');
    });

    it('ESCALATED does not trigger escrow action', async () => {
      const dispute = await service.openDispute(makerId, { tradeId: trade.id, reason: 'test' });

      const result = await service.resolveDispute(dispute.id, uuid(), {
        resolution: DisputeStatus.ESCALATED,
        resolutionNotes: 'Suspicious pattern — escalating to senior admin.',
      });

      expect(result.dispute.status).toBe(DisputeStatus.ESCALATED);
      expect(result.escrowAction).toBe('escalated');
      expect(escrow.refundEscrow).not.toHaveBeenCalled();
    });

    it('refuses to resolve an already-resolved dispute', async () => {
      const dispute = await service.openDispute(makerId, { tradeId: trade.id, reason: 'test' });
      await service.resolveDispute(dispute.id, uuid(), {
        resolution: DisputeStatus.RESOLVED_MAKER,
        resolutionNotes: 'first resolution',
      });

      await expect(
        service.resolveDispute(dispute.id, uuid(), {
          resolution: DisputeStatus.RESOLVED_TAKER,
          resolutionNotes: 'trying again',
        }),
      ).rejects.toMatchObject({ errorCode: ErrorCode.DISPUTE_ALREADY_RESOLVED });
    });
  });
});
