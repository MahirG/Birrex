import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { DataSource, Repository } from 'typeorm';
import { v4 as uuid } from 'uuid';

import {
  PaymentMethod,
  PaymentProvider,
  PaymentMethodType,
} from '../../database/entities';
import { CryptoService } from '../../common/crypto.service';
import { BusinessException, ErrorCode } from '../../common/exceptions/business.exception';
import { PaymentProviderRegistry } from './providers/payment-providers';
import {
  type CreatePaymentMethodDto,
  type UpdatePaymentMethodDto,
  type InitiatePaymentDto,
  type ProviderWebhookDto,
  type PaymentMethodResponse,
  type PaymentIntentResponse,
} from './dto/payment.dto';

/**
 * PaymentService — manages user payment methods + outbound payment initiation.
 *
 * Payment methods:
 *   - Each user can register multiple payment methods (Telebirr phone, CBE
 *     account, etc.). Account names + numbers are RSA-256 encrypted at the
 *     application layer; the DB only ever sees ciphertext.
 *   - On read, the service masks the account number (last 4 chars visible)
 *     so the frontend never sees the full value.
 *
 * Payment initiation:
 *   - User requests a withdrawal to a registered payment method (or an
 *     ad-hoc destination). The service routes to the appropriate provider
 *     adapter via the PaymentProviderRegistry.
 *   - The adapter returns a provider reference + status. Phase 3 returns
 *     'PENDING'; the actual settlement is asynchronous via webhook.
 *
 * Webhook verification:
 *   - The provider's webhook hits POST /v1/payments/webhook.
 *   - The service looks up the adapter by provider, calls verifyWebhook().
 *   - On valid signature, the service credits the user's wallet via
 *     WalletService.adminDeposit() (in Phase 4 — currently logged only).
 */
@Injectable()
export class PaymentService {
  private readonly logger = new Logger(PaymentService.name);

  constructor(
    @InjectRepository(PaymentMethod)
    private readonly paymentMethodRepo: Repository<PaymentMethod>,
    private readonly crypto: CryptoService,
    private readonly registry: PaymentProviderRegistry,
    private readonly dataSource: DataSource,
  ) {}

  // ===========================================================================
  // PAYMENT METHOD CRUD
  // ===========================================================================

  async createPaymentMethod(userId: string, dto: CreatePaymentMethodDto): Promise<PaymentMethodResponse> {
    const accountNameEnc = this.crypto.encrypt(dto.accountName);
    const accountNumberEnc = this.crypto.encrypt(dto.accountNumber);

    const pm = await this.dataSource.transaction(async (manager) => {
      const created = manager.create(PaymentMethod, {
        userId,
        provider: dto.provider,
        type: dto.type,
        accountNameEncrypted: accountNameEnc,
        accountNumberEncrypted: accountNumberEnc,
        bankBranch: dto.bankBranch ?? null,
        label: dto.label ?? null,
        isVerified: false, // moderators verify via admin endpoint
        isActive: true,
      });
      return manager.save(created);
    });

    this.logger.log(`Payment method created: user=${userId} provider=${dto.provider} id=${pm.id}`);
    return this.toResponse(pm);
  }

  async listPaymentMethods(userId: string): Promise<PaymentMethodResponse[]> {
    const methods = await this.paymentMethodRepo.find({
      where: { userId },
      order: { createdAt: 'DESC' },
    });
    return methods.map((m) => this.toResponse(m));
  }

  async getPaymentMethod(userId: string, id: string): Promise<PaymentMethodResponse> {
    const pm = await this.paymentMethodRepo.findOne({ where: { id, userId } });
    if (!pm) {
      throw new BusinessException(ErrorCode.PAYMENT_METHOD_NOT_FOUND, `Payment method ${id} not found`);
    }
    return this.toResponse(pm);
  }

  async updatePaymentMethod(
    userId: string,
    id: string,
    dto: UpdatePaymentMethodDto,
  ): Promise<PaymentMethodResponse> {
    const pm = await this.paymentMethodRepo.findOne({ where: { id, userId } });
    if (!pm) {
      throw new BusinessException(ErrorCode.PAYMENT_METHOD_NOT_FOUND, `Payment method ${id} not found`);
    }
    if (dto.accountName !== undefined) {
      pm.accountNameEncrypted = this.crypto.encrypt(dto.accountName);
    }
    if (dto.bankBranch !== undefined) pm.bankBranch = dto.bankBranch;
    if (dto.label !== undefined) pm.label = dto.label;
    if (dto.isActive !== undefined) pm.isActive = dto.isActive;
    await this.paymentMethodRepo.save(pm);
    return this.toResponse(pm);
  }

  async deletePaymentMethod(userId: string, id: string): Promise<{ deleted: true }> {
    const pm = await this.paymentMethodRepo.findOne({ where: { id, userId } });
    if (!pm) {
      throw new BusinessException(ErrorCode.PAYMENT_METHOD_NOT_FOUND, `Payment method ${id} not found`);
    }
    // Soft-delete: set isActive = false instead of removing the row.
    // We need to keep the record for audit + reconciliation.
    pm.isActive = false;
    await this.paymentMethodRepo.save(pm);
    return { deleted: true };
  }

  /** Admin verifies a user's payment method (e.g. after a micro-deposit check). */
  async verifyPaymentMethod(
    id: string,
    adminId: string,
  ): Promise<PaymentMethodResponse> {
    const pm = await this.paymentMethodRepo.findOne({ where: { id } });
    if (!pm) {
      throw new BusinessException(ErrorCode.PAYMENT_METHOD_NOT_FOUND, `Payment method ${id} not found`);
    }
    pm.isVerified = true;
    pm.verifiedAt = new Date();
    await this.paymentMethodRepo.save(pm);
    this.logger.log(`Payment method ${id} verified by admin ${adminId}`);
    return this.toResponse(pm);
  }

  // ===========================================================================
  // PAYMENT INITIATION (withdrawal to external provider)
  // ===========================================================================

  async initiatePayment(userId: string, dto: InitiatePaymentDto): Promise<PaymentIntentResponse> {
    const adapter = this.registry.get(dto.provider);
    const result = await adapter.initiate({
      amount: dto.amount,
      currency: dto.currency ?? 'ETB',
      destination: dto.destination,
      description: dto.description,
    });

    const intentId = uuid();
    this.logger.log(
      `Payment initiated: intent=${intentId} user=${userId} provider=${dto.provider} ` +
        `amount=${dto.amount} ${dto.currency ?? 'ETB'} → ${dto.destination} ` +
        `providerRef=${result.providerReference} status=${result.status}`,
    );

    return {
      intentId,
      provider: dto.provider,
      amount: dto.amount,
      currency: dto.currency ?? 'ETB',
      destination: dto.destination,
      status: result.status,
      providerReference: result.providerReference,
      estimatedSettlementSeconds: result.estimatedSettlementSeconds,
    };
  }

  // ===========================================================================
  // WEBHOOK (called by providers when a payment settles)
  // ===========================================================================

  async handleWebhook(dto: ProviderWebhookDto): Promise<{ accepted: true; status: string }> {
    const adapter = this.registry.get(dto.provider);
    const verification = await adapter.verifyWebhook({
      rawBody: dto.rawBody,
      signature: dto.signature,
      timestamp: dto.timestamp,
      payload: dto.payload,
    });

    if (!verification.isValid) {
      this.logger.warn(`Webhook from ${dto.provider} rejected — signature invalid`);
      throw new BusinessException(ErrorCode.FORBIDDEN, 'Webhook signature verification failed');
    }

    // Phase 4: credit the user's wallet via WalletService.adminDeposit() here.
    // For Phase 3 we log the confirmation so ops can manually reconcile.
    this.logger.log(
      `Webhook accepted: provider=${dto.provider} ref=${verification.providerReference} ` +
        `amount=${verification.amount} status=${verification.status}`,
    );

    return { accepted: true, status: verification.status };
  }

  // ===========================================================================
  // HELPERS
  // ===========================================================================

  listSupportedProviders(): PaymentProvider[] {
    return this.registry.listSupportedProviders();
  }

  private toResponse(pm: PaymentMethod): PaymentMethodResponse {
    return {
      id: pm.id,
      provider: pm.provider,
      type: pm.type,
      // Decrypt for the response so the frontend can show the account name.
      accountName: this.safeDecrypt(pm.accountNameEncrypted),
      accountNumberMasked: this.maskAccountNumber(this.safeDecrypt(pm.accountNumberEncrypted)),
      bankBranch: pm.bankBranch,
      label: pm.label,
      isVerified: pm.isVerified,
      isActive: pm.isActive,
      createdAt: pm.createdAt.toISOString(),
    };
  }

  private safeDecrypt(buf: Buffer): string {
    try {
      return this.crypto.decrypt(buf);
    } catch {
      return '';
    }
  }

  /**
   * Masks an account number so only the last 4 chars are visible.
   *   '1234567890'    → '******7890'
   *   '+251911234567' → '********4567'
   */
  private maskAccountNumber(num: string): string {
    if (num.length <= 4) return '*'.repeat(num.length);
    return '*'.repeat(num.length - 4) + num.slice(-4);
  }
}

// Suppress unused-import warnings for types referenced via JSDoc only.
void PaymentMethodType;
