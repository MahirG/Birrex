import {
  IsEnum,
  IsOptional,
  IsString,
  Matches,
  MinLength,
  MaxLength,
} from 'class-validator';
import {
  PaymentProvider,
  PaymentMethodType,
} from '../../../database/entities';

/**
 * CreatePaymentMethodDto — user adds a new bank account / mobile money
 * account to their profile. The account number + holder name are RSA-256
 * encrypted at the application layer BEFORE reaching the DB.
 *
 * For mobile money (Telebirr/M-PESA): accountNumber is the phone number.
 * For bank transfers (CBE/Awash/Dashen): accountNumber is the bank account.
 */
export class CreatePaymentMethodDto {
  @IsEnum(PaymentProvider)
  provider: PaymentProvider;

  @IsEnum(PaymentMethodType)
  type: PaymentMethodType;

  @IsString()
  @MinLength(2)
  @MaxLength(255)
  accountName: string;

  @IsString()
  @Matches(/^[\w\-+]{5,30}$/, {
    message: 'accountNumber must be 5-30 alphanumeric chars (+, -, _ allowed)',
  })
  accountNumber: string;

  @IsOptional()
  @IsString()
  @MaxLength(255)
  bankBranch?: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  label?: string;
}

export class UpdatePaymentMethodDto {
  @IsOptional()
  @IsString()
  @MaxLength(255)
  accountName?: string;

  @IsOptional()
  @IsString()
  @MaxLength(255)
  bankBranch?: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  label?: string;

  @IsOptional()
  @IsString()
  isActive?: boolean;
}

/**
 * InitiatePaymentDto — kicks off an outbound payment via the requested
 * provider (e.g. user requests ETB withdrawal to their Telebirr wallet).
 *
 * The service routes to the appropriate adapter based on `provider` and
 * returns a payment intent ID + status. The actual fund movement is
 * asynchronous — the provider's webhook later confirms completion.
 */
export class InitiatePaymentDto {
  @IsEnum(PaymentProvider)
  provider: PaymentProvider;

  @IsString()
  @Matches(/^\d+(\.\d{1,8})?$/)
  amount: string;

  /** ETB by default; some providers support USD for cross-border payouts. */
  @IsOptional()
  @IsString()
  currency?: string;

  /** Destination: phone number (mobile money) or bank account number. */
  @IsString()
  @MinLength(5)
  @MaxLength(64)
  destination: string;

  @IsOptional()
  @IsString()
  description?: string;
}

/**
 * ProviderWebhookDto — incoming webhook payload from any payment provider.
 * The signature is provider-specific:
 *   - Telebirr: HMAC-SHA256 of the raw body with the app key.
 *   - M-PESA:   base64(password + timestamp) compared against Daraja API.
 *   - Banks:    IP allowlist + JWT signed by the bank's private key.
 *
 * The service validates the signature per provider, then queues the
 * confirmation for the wallet module to credit the user.
 */
export class ProviderWebhookDto {
  @IsEnum(PaymentProvider)
  provider: PaymentProvider;

  /** Raw body — used for signature verification (HMAC over raw bytes). */
  rawBody: string;

  /** Provider-specific signature header value. */
  signature: string;

  /** Provider-specific timestamp (used for replay-attack prevention). */
  timestamp?: string;

  /** Parsed payload — provider-specific shape. */
  payload: Record<string, unknown>;
}

export interface PaymentMethodResponse {
  id: string;
  provider: string;
  type: string;
  accountName: string;
  /** Masked — only last 4 chars visible, rest replaced with asterisks. */
  accountNumberMasked: string;
  bankBranch: string | null;
  label: string | null;
  isVerified: boolean;
  isActive: boolean;
  createdAt: string;
}

export interface PaymentIntentResponse {
  intentId: string;
  provider: string;
  amount: string;
  currency: string;
  destination: string;
  status: 'PENDING' | 'COMPLETED' | 'FAILED';
  providerReference: string | null;
  estimatedSettlementSeconds: number;
}
