import { Injectable, Logger } from '@nestjs/common';
import { createHmac, randomUUID } from 'crypto';
import { getEnv } from '../../../config';
import { PaymentProvider } from '../../../database/entities';
import { BusinessException, ErrorCode } from '../../../common/exceptions/business.exception';

/**
 * The result of initiating a payment via a provider.
 * Each adapter returns this shape so the PaymentService can persist a
 * uniform record regardless of which provider handled the request.
 */
export interface ProviderPaymentResult {
  providerReference: string;
  status: 'PENDING' | 'COMPLETED' | 'FAILED';
  estimatedSettlementSeconds: number;
  rawResponse?: Record<string, unknown>;
}

/**
 * PaymentProviderAdapter — implemented by every Ethiopian payment integration.
 *
 * Each adapter encapsulates:
 *   1. The provider's REST API contract (initiate / verify / status).
 *   2. The provider's signature scheme (HMAC / JWT / IP allowlist).
 *   3. Provider-specific idempotency + retry semantics.
 *
 * Phase 3 ships STUB implementations that simulate API calls. Phase 4
 * will replace these with real HTTP calls using axios + provider SDKs.
 */
export interface PaymentProviderAdapter {
  readonly provider: PaymentProvider;
  initiate(params: {
    amount: string;
    currency: string;
    destination: string;
    description?: string;
  }): Promise<ProviderPaymentResult>;
  verifyWebhook(params: {
    rawBody: string;
    signature: string;
    timestamp?: string;
    payload: Record<string, unknown>;
  }): Promise<{ isValid: boolean; providerReference: string; amount: string; status: 'COMPLETED' | 'FAILED' }>;
}

// =============================================================================
// Telebirr — Ethiopia's dominant mobile money service (Ethio Telecom).
// =============================================================================

@Injectable()
export class TelebirrAdapter implements PaymentProviderAdapter {
  private readonly logger = new Logger(TelebirrAdapter.name);
  readonly provider = PaymentProvider.TELEBIRR;

  async initiate(params: {
    amount: string;
    currency: string;
    destination: string;
    description?: string;
  }): Promise<ProviderPaymentResult> {
    const env = getEnv();
    if (!env.TELEBIRR_APP_ID || !env.TELEBIRR_APP_KEY) {
      throw new BusinessException(
        ErrorCode.SERVICE_UNAVAILABLE,
        'Telebirr credentials not configured',
      );
    }

    // Phase 3 stub: simulate an API call by generating a provider reference.
    // In production this would POST to ${TELEBIRR_API_BASE}/service-openapi
    // with an RSA-signed payload (uomDigest) + return the actual TX ID.
    const providerReference = `TELEBIRR-${randomUUID().slice(0, 16).toUpperCase()}`;
    this.logger.log(
      `Telebirr initiate: ${params.amount} ${params.currency} → ${params.destination} [stub: ${providerReference}]`,
    );

    return {
      providerReference,
      status: 'PENDING',
      estimatedSettlementSeconds: 30, // Telebirr typically settles in <30s
    };
  }

  async verifyWebhook(params: {
    rawBody: string;
    signature: string;
    timestamp?: string;
    payload: Record<string, unknown>;
  }): Promise<{ isValid: boolean; providerReference: string; amount: string; status: 'COMPLETED' | 'FAILED' }> {
    const env = getEnv();
    // Telebirr signs webhooks with HMAC-SHA256 using the app key.
    const expected = createHmac('sha256', env.TELEBIRR_APP_KEY ?? 'stub-key')
      .update(params.rawBody)
      .digest('hex');

    if (expected !== params.signature) {
      this.logger.warn(`Telebirr webhook signature mismatch`);
      return {
        isValid: false,
        providerReference: '',
        amount: '0',
        status: 'FAILED',
      };
    }

    // Replay-attack defense: reject if timestamp is > 5 minutes old.
    if (params.timestamp) {
      const age = Date.now() - Number(params.timestamp);
      if (age > 5 * 60_000) {
        this.logger.warn(`Telebirr webhook rejected — stale timestamp (age=${age}ms)`);
        return { isValid: false, providerReference: '', amount: '0', status: 'FAILED' };
      }
    }

    const payload = params.payload as { outTradeNo?: string; totalAmount?: string; tradeStatus?: string };
    return {
      isValid: true,
      providerReference: payload.outTradeNo ?? '',
      amount: String(payload.totalAmount ?? '0'),
      status: payload.tradeStatus === 'Completed' ? 'COMPLETED' : 'FAILED',
    };
  }
}

// =============================================================================
// M-PESA — Safaricom's M-PESA Ethiopia (Daraja API).
// =============================================================================

@Injectable()
export class MpesaAdapter implements PaymentProviderAdapter {
  private readonly logger = new Logger(MpesaAdapter.name);
  readonly provider = PaymentProvider.MPESA;

  async initiate(params: {
    amount: string;
    currency: string;
    destination: string;
    description?: string;
  }): Promise<ProviderPaymentResult> {
    const env = getEnv();
    if (!env.MPESA_CONSUMER_KEY || !env.MPESA_CONSUMER_SECRET) {
      throw new BusinessException(
        ErrorCode.SERVICE_UNAVAILABLE,
        'M-PESA credentials not configured',
      );
    }

    // Phase 3 stub — production would call Daraja's B2C API.
    const providerReference = `MPESA-${randomUUID().slice(0, 16).toUpperCase()}`;
    this.logger.log(`M-PESA initiate: ${params.amount} ${params.currency} → ${params.destination} [stub: ${providerReference}]`);

    return {
      providerReference,
      status: 'PENDING',
      estimatedSettlementSeconds: 60,
    };
  }

  async verifyWebhook(params: {
    rawBody: string;
    signature: string;
    timestamp?: string;
    payload: Record<string, unknown>;
  }): Promise<{ isValid: boolean; providerReference: string; amount: string; status: 'COMPLETED' | 'FAILED' }> {
    // M-PESA Daraja uses a Base64-encoded password (shortcode + passkey + timestamp).
    // For Phase 3 we just check the signature length is reasonable.
    if (params.signature.length < 16) {
      this.logger.warn('M-PESA webhook signature too short');
      return { isValid: false, providerReference: '', amount: '0', status: 'FAILED' };
    }

    const payload = params.payload as { ConversationID?: string; Amount?: number; ResultCode?: number };
    return {
      isValid: true,
      providerReference: payload.ConversationID ?? '',
      amount: String(payload.Amount ?? '0'),
      status: payload.ResultCode === 0 ? 'COMPLETED' : 'FAILED',
    };
  }
}

// =============================================================================
// Bank adapters (CBE, Awash, Dashen) — share the same OAuth2 + signed JWT
// pattern. Each bank exposes a slightly different API shape but the security
// model is identical: client-credentials OAuth2 token + IP allowlist.
// =============================================================================

@Injectable()
export class CbeAdapter implements PaymentProviderAdapter {
  private readonly logger = new Logger(CbeAdapter.name);
  readonly provider = PaymentProvider.CBE;

  async initiate(params: { amount: string; currency: string; destination: string; description?: string }): Promise<ProviderPaymentResult> {
    const env = getEnv();
    if (!env.CBE_CLIENT_ID) {
      throw new BusinessException(ErrorCode.SERVICE_UNAVAILABLE, 'CBE credentials not configured');
    }
    const providerReference = `CBE-${randomUUID().slice(0, 16).toUpperCase()}`;
    this.logger.log(`CBE initiate: ${params.amount} ${params.currency} → ${params.destination} [stub: ${providerReference}]`);
    return { providerReference, status: 'PENDING', estimatedSettlementSeconds: 300 };
  }

  async verifyWebhook(params: { rawBody: string; signature: string; timestamp?: string; payload: Record<string, unknown> }): Promise<{ isValid: boolean; providerReference: string; amount: string; status: 'COMPLETED' | 'FAILED' }> {
    // CBE uses RSA-signed JWT. For Phase 3 stub we trust the signature presence.
    if (!params.signature) {
      return { isValid: false, providerReference: '', amount: '0', status: 'FAILED' };
    }
    const payload = params.payload as { traceNumber?: string; amount?: string; status?: string };
    return {
      isValid: true,
      providerReference: payload.traceNumber ?? '',
      amount: String(payload.amount ?? '0'),
      status: payload.status === 'SETTLED' ? 'COMPLETED' : 'FAILED',
    };
  }
}

@Injectable()
export class AwashAdapter implements PaymentProviderAdapter {
  private readonly logger = new Logger(AwashAdapter.name);
  readonly provider = PaymentProvider.AWASH;

  async initiate(params: { amount: string; currency: string; destination: string; description?: string }): Promise<ProviderPaymentResult> {
    const env = getEnv();
    if (!env.AWASH_CLIENT_ID) {
      throw new BusinessException(ErrorCode.SERVICE_UNAVAILABLE, 'Awash Bank credentials not configured');
    }
    const providerReference = `AWASH-${randomUUID().slice(0, 16).toUpperCase()}`;
    this.logger.log(`Awash initiate: ${params.amount} ${params.currency} → ${params.destination} [stub: ${providerReference}]`);
    return { providerReference, status: 'PENDING', estimatedSettlementSeconds: 180 };
  }

  async verifyWebhook(params: { rawBody: string; signature: string; timestamp?: string; payload: Record<string, unknown> }): Promise<{ isValid: boolean; providerReference: string; amount: string; status: 'COMPLETED' | 'FAILED' }> {
    if (!params.signature) {
      return { isValid: false, providerReference: '', amount: '0', status: 'FAILED' };
    }
    const payload = params.payload as { txnRef?: string; amount?: string; resultCode?: string };
    return {
      isValid: true,
      providerReference: payload.txnRef ?? '',
      amount: String(payload.amount ?? '0'),
      status: payload.resultCode === '00' ? 'COMPLETED' : 'FAILED',
    };
  }
}

@Injectable()
export class DashenAdapter implements PaymentProviderAdapter {
  private readonly logger = new Logger(DashenAdapter.name);
  readonly provider = PaymentProvider.DASHEN;

  async initiate(params: { amount: string; currency: string; destination: string; description?: string }): Promise<ProviderPaymentResult> {
    const env = getEnv();
    if (!env.DASHEN_CLIENT_ID) {
      throw new BusinessException(ErrorCode.SERVICE_UNAVAILABLE, 'Dashen Bank credentials not configured');
    }
    const providerReference = `DASHEN-${randomUUID().slice(0, 16).toUpperCase()}`;
    this.logger.log(`Dashen initiate: ${params.amount} ${params.currency} → ${params.destination} [stub: ${providerReference}]`);
    return { providerReference, status: 'PENDING', estimatedSettlementSeconds: 240 };
  }

  async verifyWebhook(params: { rawBody: string; signature: string; timestamp?: string; payload: Record<string, unknown> }): Promise<{ isValid: boolean; providerReference: string; amount: string; status: 'COMPLETED' | 'FAILED' }> {
    if (!params.signature) {
      return { isValid: false, providerReference: '', amount: '0', status: 'FAILED' };
    }
    const payload = params.payload as { reference?: string; amount?: string; status?: string };
    return {
      isValid: true,
      providerReference: payload.reference ?? '',
      amount: String(payload.amount ?? '0'),
      status: payload.status === 'SUCCESS' ? 'COMPLETED' : 'FAILED',
    };
  }
}

/**
 * PaymentProviderRegistry — central registry mapping PaymentProvider enum
 * to its adapter. The PaymentService looks up the adapter here so it
 * doesn't need to know about individual providers.
 */
@Injectable()
export class PaymentProviderRegistry {
  private readonly adapters: Map<PaymentProvider, PaymentProviderAdapter>;

  constructor(
    telebirr: TelebirrAdapter,
    mpesa: MpesaAdapter,
    cbe: CbeAdapter,
    awash: AwashAdapter,
    dashen: DashenAdapter,
  ) {
    this.adapters = new Map<PaymentProvider, PaymentProviderAdapter>();
    this.adapters.set(PaymentProvider.TELEBIRR, telebirr);
    this.adapters.set(PaymentProvider.MPESA, mpesa);
    this.adapters.set(PaymentProvider.CBE, cbe);
    this.adapters.set(PaymentProvider.AWASH, awash);
    this.adapters.set(PaymentProvider.DASHEN, dashen);
  }

  get(provider: PaymentProvider): PaymentProviderAdapter {
    const adapter = this.adapters.get(provider);
    if (!adapter) {
      throw new BusinessException(
        ErrorCode.BAD_REQUEST,
        `No adapter registered for provider ${provider}`,
      );
    }
    return adapter;
  }

  listSupportedProviders(): PaymentProvider[] {
    return [...this.adapters.keys()];
  }
}
