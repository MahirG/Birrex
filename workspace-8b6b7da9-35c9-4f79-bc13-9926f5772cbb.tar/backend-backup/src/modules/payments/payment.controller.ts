import {
  Body,
  Controller,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  Post,
  UseGuards,
  UseInterceptors,
  Req,
} from '@nestjs/common';
import { ThrottlerGuard } from '@nestjs/throttler';
import type { Request } from 'express';

import { PaymentService } from './payment.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CsrfGuard } from '../auth/guards/csrf.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { CurrentUser, type AuthUser } from '../../common/decorators/current-user.decorator';
import { LoggingInterceptor } from '../../common/interceptors/logging.interceptor';
import {
  CreatePaymentMethodDto,
  UpdatePaymentMethodDto,
  InitiatePaymentDto,
  type PaymentMethodResponse,
  type PaymentIntentResponse,
} from './dto/payment.dto';
import { UserRole } from '../../database/entities';

/**
 * PaymentController — user-facing payment method management + outbound payment initiation.
 *
 *   POST   /v1/payments/methods              — register a new bank/mobile-money account
 *   GET    /v1/payments/methods              — list user's payment methods
 *   GET    /v1/payments/methods/:id          — get one (masked)
 *   PATCH  /v1/payments/methods/:id          — update label/branch/active
 *   DELETE /v1/payments/methods/:id          — soft-delete (isActive=false)
 *   POST   /v1/payments/initiate             — kick off outbound payment via provider
 *   GET    /v1/payments/providers            — list supported providers
 *
 *   POST   /v1/payments/webhook              — public endpoint (no JWT, signature-verified)
 *
 * Note: webhook is exempt from JwtAuthGuard + CsrfGuard because providers
 * cannot authenticate via JWT. The PaymentService.verifyWebhook() path
 * enforces provider-specific signature schemes.
 */
@Controller('v1/payments')
@UseGuards(JwtAuthGuard, ThrottlerGuard)
@UseInterceptors(LoggingInterceptor)
export class PaymentController {
  constructor(private readonly paymentService: PaymentService) {}

  @Post('methods')
  @HttpCode(HttpStatus.CREATED)
  @UseGuards(CsrfGuard)
  async createMethod(
    @CurrentUser() user: AuthUser,
    @Body() dto: CreatePaymentMethodDto,
  ): Promise<PaymentMethodResponse> {
    return this.paymentService.createPaymentMethod(user.id, dto);
  }

  @Get('methods')
  @HttpCode(HttpStatus.OK)
  async listMethods(@CurrentUser() user: AuthUser): Promise<PaymentMethodResponse[]> {
    return this.paymentService.listPaymentMethods(user.id);
  }

  @Get('methods/:id')
  @HttpCode(HttpStatus.OK)
  async getMethod(
    @CurrentUser() user: AuthUser,
    @Param('id') id: string,
  ): Promise<PaymentMethodResponse> {
    return this.paymentService.getPaymentMethod(user.id, id);
  }

  @Post('methods/:id')
  @HttpCode(HttpStatus.OK)
  @UseGuards(CsrfGuard)
  async updateMethod(
    @CurrentUser() user: AuthUser,
    @Param('id') id: string,
    @Body() dto: UpdatePaymentMethodDto,
  ): Promise<PaymentMethodResponse> {
    return this.paymentService.updatePaymentMethod(user.id, id, dto);
  }

  @Post('methods/:id/delete')
  @HttpCode(HttpStatus.OK)
  @UseGuards(CsrfGuard)
  async deleteMethod(
    @CurrentUser() user: AuthUser,
    @Param('id') id: string,
  ): Promise<{ deleted: true }> {
    return this.paymentService.deletePaymentMethod(user.id, id);
  }

  @Post('initiate')
  @HttpCode(HttpStatus.CREATED)
  @UseGuards(CsrfGuard)
  async initiatePayment(
    @CurrentUser() user: AuthUser,
    @Body() dto: InitiatePaymentDto,
  ): Promise<PaymentIntentResponse> {
    return this.paymentService.initiatePayment(user.id, dto);
  }

  @Get('providers')
  @HttpCode(HttpStatus.OK)
  async listProviders() {
    return { providers: this.paymentService.listSupportedProviders() };
  }

  // ===========================================================================
  // WEBHOOK — provider callbacks (NO auth guard — signature-verified instead)
  // ===========================================================================
  //
  // We override the @Controller-level JwtAuthGuard by registering this route
  // on a separate controller below.
}

/**
 * PaymentWebhookController — separate controller for provider webhooks.
 * Inherits the same prefix but disables JwtAuthGuard + CsrfGuard.
 */
@Controller('v1/payments')
@UseInterceptors(LoggingInterceptor)
export class PaymentWebhookController {
  constructor(private readonly paymentService: PaymentService) {}

  @Post('webhook')
  @HttpCode(HttpStatus.OK)
  async webhook(@Req() req: Request, @Body() body: unknown): Promise<{ accepted: true; status: string }> {
    // The webhook body is provider-specific; we extract the standard fields
    // (provider, signature, timestamp) from headers + the raw body from req.
    const provider = req.headers['x-provider'] as string;
    const signature = req.headers['x-signature'] as string;
    const timestamp = req.headers['x-timestamp'] as string | undefined;
    const rawBody = JSON.stringify(body);

    return this.paymentService.handleWebhook({
      provider: provider as never,
      rawBody,
      signature,
      timestamp,
      payload: body as Record<string, unknown>,
    });
  }
}

/**
 * AdminPaymentController — moderator-only endpoints for verifying user
 * payment methods (e.g. after a micro-deposit confirmation flow).
 */
@Controller('v1/admin/payments')
@UseGuards(JwtAuthGuard, RolesGuard, CsrfGuard, ThrottlerGuard)
@UseInterceptors(LoggingInterceptor)
export class AdminPaymentController {
  constructor(private readonly paymentService: PaymentService) {}

  @Post('methods/:id/verify')
  @HttpCode(HttpStatus.OK)
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN)
  async verifyMethod(
    @CurrentUser() user: AuthUser,
    @Param('id') id: string,
  ): Promise<PaymentMethodResponse> {
    return this.paymentService.verifyPaymentMethod(id, user.id);
  }
}
