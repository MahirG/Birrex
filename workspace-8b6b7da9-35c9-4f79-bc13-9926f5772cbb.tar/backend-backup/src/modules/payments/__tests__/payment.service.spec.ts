import { Test, type TestingModule } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { v4 as uuid } from 'uuid';
import { createHmac } from 'crypto';

import { PaymentService } from '../payment.service';
import {
  TelebirrAdapter,
  MpesaAdapter,
  CbeAdapter,
  AwashAdapter,
  DashenAdapter,
  PaymentProviderRegistry,
} from '../providers/payment-providers';
import { CryptoService } from '../../../common/crypto.service';
import {
  PaymentMethod,
  PaymentProvider,
  PaymentMethodType,
} from '../../../database/entities';
import {
  ErrorCode,
} from '../../../common/exceptions/business.exception';
import { _resetEnvCacheForTesting } from '../../../config';
import type { CreatePaymentMethodDto, InitiatePaymentDto } from '../dto/payment.dto';

/**
 * Payment tests verify:
 *   1. CRUD: create + list + get + update + soft-delete payment methods.
 *   2. Account number encryption: persisted bytes ≠ plaintext; round-trip decrypts.
 *   3. Account number masking on read: only last 4 chars visible.
 *   4. Payment initiation routes to the correct provider adapter.
 *   5. Webhook signature verification (Telebirr HMAC-SHA256 path).
 *   6. Webhook rejects bad signature.
 *   7. Webhook rejects stale timestamp (>5 min old, replay-attack defense).
 */

class MockPaymentMethodRepo {
  private methods = new Map<string, PaymentMethod>();

  async findOne(options: { where: Record<string, unknown> }): Promise<PaymentMethod | null> {
    const where = options.where;
    for (const m of this.methods.values()) {
      let allMatch = true;
      for (const [k, v] of Object.entries(where)) {
        if ((m as unknown as Record<string, unknown>)[k] !== v) {
          allMatch = false;
          break;
        }
      }
      if (allMatch) return m;
    }
    return null;
  }

  async find(options?: { where?: Record<string, unknown>; order?: Record<string, string> }): Promise<PaymentMethod[]> {
    let arr = [...this.methods.values()];
    if (options?.where) {
      arr = arr.filter((m) => {
        for (const [k, v] of Object.entries(options.where!)) {
          if ((m as unknown as Record<string, unknown>)[k] !== v) return false;
        }
        return true;
      });
    }
    return arr;
  }

  async save<E>(entity: E): Promise<E> {
    const obj = entity as unknown as { id?: string };
    if (obj instanceof PaymentMethod) {
      if (!obj.id) obj.id = uuid();
      if (!obj.createdAt) obj.createdAt = new Date();
      obj.updatedAt = new Date();
      this.methods.set(obj.id, obj);
    }
    return entity;
  }

  _get(id: string): PaymentMethod | undefined {
    return this.methods.get(id);
  }

  _clear(): void {
    this.methods.clear();
  }
}

class MockEntityManager {
  constructor(private readonly repo: MockPaymentMethodRepo) {}

  create<E extends object>(entity: new (...args: unknown[]) => E, data: Partial<E>): E {
    return Object.assign(new entity(), data) as E;
  }

  async save<E>(entity: E): Promise<E> {
    return this.repo.save(entity);
  }
}

class MockDataSource {
  constructor(private readonly repo: MockPaymentMethodRepo) {}

  async transaction<T>(fn: (manager: MockEntityManager) => Promise<T>): Promise<T> {
    return fn(new MockEntityManager(this.repo));
  }
}

describe('PaymentService', () => {
  let service: PaymentService;
  let repo: MockPaymentMethodRepo;
  let crypto: CryptoService;
  let registry: PaymentProviderRegistry;

  beforeAll(() => {
    // Telebirr credentials required by TelebirrAdapter.initiate.
    process.env.TELEBIRR_APP_ID = 'test-app-id';
    process.env.TELEBIRR_APP_KEY = 'test-app-key';
    process.env.MPESA_CONSUMER_KEY = 'test-mpesa-key';
    process.env.MPESA_CONSUMER_SECRET = 'test-mpesa-secret';
    process.env.CBE_CLIENT_ID = 'test-cbe-id';
    process.env.AWASH_CLIENT_ID = 'test-awash-id';
    process.env.DASHEN_CLIENT_ID = 'test-dashen-id';
    _resetEnvCacheForTesting();
  });

  afterAll(() => {
    _resetEnvCacheForTesting();
  });

  beforeEach(async () => {
    repo = new MockPaymentMethodRepo();

    crypto = {
      encrypt: (plaintext: string) => Buffer.from(`ENC:${plaintext}`, 'utf8'),
      decrypt: (buf: Buffer) => {
        const s = buf.toString('utf8');
        return s.startsWith('ENC:') ? s.slice(4) : s;
      },
    } as unknown as CryptoService;

    const telebirr = new TelebirrAdapter();
    const mpesa = new MpesaAdapter();
    const cbe = new CbeAdapter();
    const awash = new AwashAdapter();
    const dashen = new DashenAdapter();
    registry = new PaymentProviderRegistry(telebirr, mpesa, cbe, awash, dashen);

    const ds = new MockDataSource(repo);

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        PaymentService,
        { provide: getRepositoryToken(PaymentMethod), useValue: repo },
        { provide: CryptoService, useValue: crypto },
        { provide: PaymentProviderRegistry, useValue: registry },
        { provide: DataSource, useValue: ds },
      ],
    }).compile();

    service = module.get(PaymentService);
  });

  // ===========================================================================
  // PAYMENT METHOD CRUD
  // ===========================================================================
  describe('createPaymentMethod + listPaymentMethods + getPaymentMethod', () => {
    it('creates a payment method with encrypted account name + number', async () => {
      const dto: CreatePaymentMethodDto = {
        provider: PaymentProvider.TELEBIRR,
        type: PaymentMethodType.MOBILE_MONEY,
        accountName: 'Abebe Bekele',
        accountNumber: '+251911234567',
      };

      const result = await service.createPaymentMethod(uuid(), dto);

      expect(result.provider).toBe(PaymentProvider.TELEBIRR);
      expect(result.accountName).toBe('Abebe Bekele');
      expect(result.accountNumberMasked).toBe('*********4567'); // 9 stars + last 4
      expect(result.isVerified).toBe(false);
      expect(result.isActive).toBe(true);

      // Verify the persisted record has ENCRYPTED bytes (not plaintext).
      const stored = repo._get(result.id)!;
      expect(stored.accountNameEncrypted.toString('utf8')).toBe('ENC:Abebe Bekele');
      expect(stored.accountNumberEncrypted.toString('utf8')).toBe('ENC:+251911234567');
    });

    it('masks the account number to show only the last 4 chars', async () => {
      const dto: CreatePaymentMethodDto = {
        provider: PaymentProvider.CBE,
        type: PaymentMethodType.BANK_TRANSFER,
        accountName: 'Sara Ahmed',
        accountNumber: '0123456789012345',
      };
      const result = await service.createPaymentMethod(uuid(), dto);
      expect(result.accountNumberMasked).toBe('************2345');
    });

    it('lists only the calling user\'s payment methods', async () => {
      const user1 = uuid();
      const user2 = uuid();
      await service.createPaymentMethod(user1, {
        provider: PaymentProvider.TELEBIRR,
        type: PaymentMethodType.MOBILE_MONEY,
        accountName: 'User One',
        accountNumber: '+251911111111',
      });
      await service.createPaymentMethod(user2, {
        provider: PaymentProvider.CBE,
        type: PaymentMethodType.BANK_TRANSFER,
        accountName: 'User Two',
        accountNumber: '9999888877776666',
      });

      const user1Methods = await service.listPaymentMethods(user1);
      expect(user1Methods).toHaveLength(1);
      expect(user1Methods[0]!.accountName).toBe('User One');

      const user2Methods = await service.listPaymentMethods(user2);
      expect(user2Methods).toHaveLength(1);
      expect(user2Methods[0]!.accountName).toBe('User Two');
    });

    it('getPaymentMethod rejects attempts to read another user\'s method', async () => {
      const owner = uuid();
      const attacker = uuid();
      const created = await service.createPaymentMethod(owner, {
        provider: PaymentProvider.TELEBIRR,
        type: PaymentMethodType.MOBILE_MONEY,
        accountName: 'Owner',
        accountNumber: '+251911000000',
      });

      await expect(
        service.getPaymentMethod(attacker, created.id),
      ).rejects.toMatchObject({ errorCode: ErrorCode.PAYMENT_METHOD_NOT_FOUND });
    });
  });

  describe('updatePaymentMethod + deletePaymentMethod', () => {
    it('updates the label + bankBranch + re-encrypts accountName', async () => {
      const userId = uuid();
      const created = await service.createPaymentMethod(userId, {
        provider: PaymentProvider.AWASH,
        type: PaymentMethodType.BANK_TRANSFER,
        accountName: 'Old Name',
        accountNumber: '1234567890',
      });

      const updated = await service.updatePaymentMethod(userId, created.id, {
        accountName: 'New Name',
        label: 'Primary Awash Account',
        bankBranch: 'Bole Branch',
      });

      expect(updated.accountName).toBe('New Name');
      expect(updated.label).toBe('Primary Awash Account');
      expect(updated.bankBranch).toBe('Bole Branch');
    });

    it('soft-deletes (isActive=false) instead of removing the row', async () => {
      const userId = uuid();
      const created = await service.createPaymentMethod(userId, {
        provider: PaymentProvider.DASHEN,
        type: PaymentMethodType.BANK_TRANSFER,
        accountName: 'X',
        accountNumber: '9876543210',
      });

      await service.deletePaymentMethod(userId, created.id);

      const stored = repo._get(created.id)!;
      expect(stored.isActive).toBe(false);
    });
  });

  describe('verifyPaymentMethod (admin)', () => {
    it('flips isVerified to true + sets verifiedAt', async () => {
      const userId = uuid();
      const created = await service.createPaymentMethod(userId, {
        provider: PaymentProvider.TELEBIRR,
        type: PaymentMethodType.MOBILE_MONEY,
        accountName: 'Y',
        accountNumber: '+251911999999',
      });

      const result = await service.verifyPaymentMethod(created.id, 'admin-1');
      expect(result.isVerified).toBe(true);
      expect(repo._get(created.id)!.isVerified).toBe(true);
      expect(repo._get(created.id)!.verifiedAt).not.toBeNull();
    });
  });

  // ===========================================================================
  // PAYMENT INITIATION (provider routing)
  // ===========================================================================
  describe('initiatePayment', () => {
    it('routes to the Telebirr adapter + returns a PENDING intent', async () => {
      const dto: InitiatePaymentDto = {
        provider: PaymentProvider.TELEBIRR,
        amount: '1500.00',
        destination: '+251911234567',
      };

      const result = await service.initiatePayment(uuid(), dto);

      expect(result.provider).toBe(PaymentProvider.TELEBIRR);
      expect(result.amount).toBe('1500.00');
      expect(result.status).toBe('PENDING');
      expect(result.providerReference).toMatch(/^TELEBIRR-/);
      expect(result.intentId).toBeDefined();
      expect(result.estimatedSettlementSeconds).toBeGreaterThan(0);
    });

    it('routes to the CBE adapter for bank transfers', async () => {
      const result = await service.initiatePayment(uuid(), {
        provider: PaymentProvider.CBE,
        amount: '50000',
        destination: '0123456789012345',
        currency: 'ETB',
      });

      expect(result.provider).toBe(PaymentProvider.CBE);
      expect(result.providerReference).toMatch(/^CBE-/);
      expect(result.estimatedSettlementSeconds).toBeGreaterThanOrEqual(300); // banks slower
    });
  });

  // ===========================================================================
  // WEBHOOK
  // ===========================================================================
  describe('handleWebhook', () => {
    it('accepts a valid Telebirr webhook (HMAC-SHA256 signature matches)', async () => {
      const payload = {
        outTradeNo: 'TELEBIRR-ABC123',
        totalAmount: '1500.00',
        tradeStatus: 'Completed',
      };
      const rawBody = JSON.stringify(payload);
      const signature = createHmac('sha256', 'test-app-key').update(rawBody).digest('hex');
      const timestamp = String(Date.now());

      const result = await service.handleWebhook({
        provider: PaymentProvider.TELEBIRR,
        rawBody,
        signature,
        timestamp,
        payload,
      });

      expect(result.accepted).toBe(true);
      expect(result.status).toBe('COMPLETED');
    });

    it('rejects a webhook with an invalid signature', async () => {
      const payload = { outTradeNo: 'X', totalAmount: '100', tradeStatus: 'Completed' };
      const result = service.handleWebhook({
        provider: PaymentProvider.TELEBIRR,
        rawBody: JSON.stringify(payload),
        signature: 'invalid-signature',
        timestamp: String(Date.now()),
        payload,
      });
      await expect(result).rejects.toMatchObject({ errorCode: ErrorCode.FORBIDDEN });
    });

    it('rejects a webhook with a stale timestamp (>5 min old, replay-attack defense)', async () => {
      const payload = { outTradeNo: 'X', totalAmount: '100', tradeStatus: 'Completed' };
      const rawBody = JSON.stringify(payload);
      const signature = createHmac('sha256', 'test-app-key').update(rawBody).digest('hex');
      const staleTimestamp = String(Date.now() - 10 * 60_000); // 10 min old

      await expect(
        service.handleWebhook({
          provider: PaymentProvider.TELEBIRR,
          rawBody,
          signature,
          timestamp: staleTimestamp,
          payload,
        }),
      ).rejects.toMatchObject({ errorCode: ErrorCode.FORBIDDEN });
    });
  });
});
