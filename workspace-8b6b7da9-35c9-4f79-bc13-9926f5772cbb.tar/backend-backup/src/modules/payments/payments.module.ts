import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PaymentMethod } from '../../database/entities';
import { AuthModule } from '../auth/auth.module';
import { CryptoService } from '../../common/crypto.service';
import {
  TelebirrAdapter,
  MpesaAdapter,
  CbeAdapter,
  AwashAdapter,
  DashenAdapter,
  PaymentProviderRegistry,
} from './providers/payment-providers';
import { PaymentService } from './payment.service';
import {
  PaymentController,
  PaymentWebhookController,
  AdminPaymentController,
} from './payment.controller';

@Module({
  imports: [TypeOrmModule.forFeature([PaymentMethod]), AuthModule],
  controllers: [PaymentController, PaymentWebhookController, AdminPaymentController],
  providers: [
    PaymentService,
    CryptoService,
    TelebirrAdapter,
    MpesaAdapter,
    CbeAdapter,
    AwashAdapter,
    DashenAdapter,
    PaymentProviderRegistry,
  ],
  exports: [PaymentService, PaymentProviderRegistry],
})
export class PaymentsModule {}
