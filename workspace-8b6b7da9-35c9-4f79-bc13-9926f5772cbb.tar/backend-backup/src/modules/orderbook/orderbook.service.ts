import { Injectable, OnModuleInit, Logger } from '@nestjs/common';
import Redis from 'ioredis';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { buildRedisConfig, RedisKeys } from '../../config';
import {
  OrderSide,
  OrderStatus,
  Order,
} from '../../database/entities';
import {
  type OrderbookEntry,
  type TopOfBook,
  type OrderbookSnapshot,
  type TradingPair,
  isTradingPair,
} from '../../types/orderbook.types';
import {
  computeOrderScore,
  subtractDecimal,
} from '../../utils/matching.utils';

/**
 * ORDERBOOK LUA SCRIPTS
 * -----------------------------------------------------------------------------
 * These scripts execute atomically inside Redis, which guarantees:
 *   - No interleaving between concurrent matching passes (no double-matching)
 *   - No interleaving between a cancel and a match (no phantom fills)
 *   - Atomic update of both the sorted set and the metadata hash
 *
 * Trade-offs:
 *   - Scripts that touch multiple keys MUST run on the same Redis shard.
 *     In cluster mode we use hash tags ({pair}) so all keys for one pair
 *     live on the same node.
 * -----------------------------------------------------------------------------
 */

/**
 * Atomic "peek best N makers that can cross this taker order".
 *
 * KEYS[1] = sellBookKey (used if takerSide == BUY)
 * KEYS[2] = buyBookKey  (used if takerSide == SELL)
 * KEYS[3] = orderMetaKey
 *
 * ARGV[1] = takerSide ('BUY' | 'SELL')
 * ARGV[2] = takerPrice (string)
 * ARGV[3] = maxResults  (number)
 *
 * Returns: array of [orderId, score, price, quantity, userId, createdAt]
 *          for up to maxResults makers whose price crosses the taker.
 *
 * Implementation note: we DO NOT pop here. The matching engine pops each
 * maker individually once it has committed the trade to Postgres. This
 * avoids losing an order from the book if the DB write fails.
 */
const PEEK_MATCHABLE_MAKERS = `
local bookKey
local opposite = 'SELL'
if ARGV[1] == 'BUY' then bookKey = KEYS[1] else bookKey = KEYS[2] opposite = 'BUY' end
local takerPrice = tonumber(ARGV[2])
local maxResults = tonumber(ARGV[3])
local metaKey = KEYS[3]

local results = {}
local cursor = '0'
local count = 0
repeat
  local batch = redis.call('ZRANGE', bookKey, 0, maxResults - 1, 'WITHSCORES')
  for i = 1, #batch, 2 do
    if count >= maxResults then break end
    local orderId = batch[i]
    local score = tonumber(batch[i+1])
    local meta = redis.call('HMGET', metaKey, orderId .. ':price', orderId .. ':qty', orderId .. ':user', orderId .. ':ts')
    local makerPrice = tonumber(meta[1])
    if makerPrice == nil then
      -- Stale meta; remove orphan
      redis.call('ZREM', bookKey, orderId)
    else
      local crosses = false
      if ARGV[1] == 'BUY' then crosses = makerPrice <= takerPrice
      else crosses = makerPrice >= takerPrice end
      if crosses then
        count = count + 1
        results[#results + 1] = orderId
        results[#results + 1] = tostring(score)
        results[#results + 1] = meta[1]
        results[#results + 1] = meta[2]
        results[#results + 5] = meta[3]
        results[#results + 6] = meta[4]
      else
        -- Sorted by score, so once the best doesn't cross, nothing else will.
        break
      end
    end
  end
  cursor = nil  -- single batch is enough; engine will re-peek if needed
until cursor == nil
return results
`;

/**
 * Atomically adds a new maker order to the book.
 *
 * KEYS[1] = bookKey (sell or buy depending on side)
 * KEYS[2] = metaKey
 *
 * ARGV[1] = orderId
 * ARGV[2] = score (string, will tonumber)
 * ARGV[3] = price
 * ARGV[4] = quantity
 * ARGV[5] = userId
 * ARGV[6] = createdAt (ms)
 */
const ADD_TO_BOOK = `
redis.call('ZADD', KEYS[1], ARGV[2], ARGV[1])
redis.call('HMSET', KEYS[2],
  ARGV[1] .. ':price', ARGV[3],
  ARGV[1] .. ':qty',   ARGV[4],
  ARGV[1] .. ':user',  ARGV[5],
  ARGV[1] .. ':ts',    ARGV[6])
return 1
`;

/**
 * Atomically removes a maker from the book AND its metadata.
 * Returns 1 if it was present, 0 if not (already matched/cancelled).
 *
 * KEYS[1] = bookKey
 * KEYS[2] = metaKey
 * ARGV[1] = orderId
 */
const REMOVE_FROM_BOOK = `
local existed = redis.call('ZREM', KEYS[1], ARGV[1])
if existed == 1 then
  redis.call('HDEL', KEYS[2],
    ARGV[1] .. ':price',
    ARGV[1] .. ':qty',
    ARGV[1] .. ':user',
    ARGV[1] .. ':ts')
end
return existed
`;

/**
 * Atomically updates a maker's remaining quantity in the metadata hash.
 * Used after a partial fill so the next peek sees the correct qty.
 *
 * KEYS[1] = metaKey
 * ARGV[1] = orderId
 * ARGV[2] = newRemainingQuantity (string)
 */
const UPDATE_REMAINING_QTY = `
redis.call('HSET', KEYS[1], ARGV[1] .. ':qty', ARGV[2])
return 1
`;

/**
 * OrderbookService — Redis-backed price-time-priority orderbook.
 *
 * Why two sorted sets per pair?
 *   SELL book is scored ASC by (price, createdAt)  → cheapest seller first.
 *   BUY  book is scored ASC by (-price, createdAt) → highest bidder first.
 *   Both can be queried with ZRANGE 0 N to get the top N matchable makers.
 *
 * Why a metadata hash per pair?
 *   The sorted set only stores orderId + score. We need price/qty/userId
 *   on every match, and a Redis hash lookup is O(1) — far cheaper than
 *   hitting Postgres for every candidate maker during a matching pass.
 *
 * Why Lua scripts?
 *   Pure Redis transactions (MULTI/EXEC) cannot read intermediate results.
 *   We need to: (1) peek N candidates, (2) filter by price-crossing,
 *   (3) skip stale entries. That logic MUST be atomic, hence Lua.
 */
@Injectable()
export class OrderbookService implements OnModuleInit {
  private readonly logger = new Logger(OrderbookService.name);
  private redis!: Redis;

  @InjectDataSource()
  private readonly dataSource!: DataSource;

  onModuleInit(): void {
    this.redis = new Redis(buildRedisConfig());
    this.redis.on('error', (err: Error) =>
      this.logger.error(`Redis error: ${err.message}`),
    );
  }

  // ===========================================================================
  // PUBLIC API
  // ===========================================================================

  /**
   * Adds a new resting maker order to the book.
   * Called by the matching engine when an order has remaining quantity after
   * the immediate-match pass.
   */
  async addMakerOrder(entry: OrderbookEntry): Promise<void> {
    const bookKey = this.bookKey(entry.pair, entry.side);
    const metaKey = RedisKeys.orderMeta(entry.pair);
    const score = computeOrderScore(entry.side, entry.price, entry.createdAt);

    await this.redis.eval(
      ADD_TO_BOOK,
      2,
      bookKey,
      metaKey,
      entry.orderId,
      score.toString(),
      entry.price,
      entry.quantity,
      entry.userId,
      entry.createdAt.toString(),
    );
  }

  /**
   * Removes a maker order from the book (used on cancel or full fill).
   * Returns true if the order was still on the book, false if it was already
   * gone (matched or cancelled concurrently).
   */
  async removeMakerOrder(
    pair: TradingPair,
    side: OrderSide,
    orderId: string,
  ): Promise<boolean> {
    const bookKey = this.bookKey(pair, side);
    const metaKey = RedisKeys.orderMeta(pair);
    const removed = (await this.redis.eval(
      REMOVE_FROM_BOOK,
      2,
      bookKey,
      metaKey,
      orderId,
    )) as number;
    return removed === 1;
  }

  /**
   * Updates the remaining quantity of a maker after a partial fill.
   * The score does NOT change — price is unchanged, only qty shrinks.
   */
  async updateRemainingQuantity(
    pair: TradingPair,
    orderId: string,
    newRemainingQty: string,
  ): Promise<void> {
    const metaKey = RedisKeys.orderMeta(pair);
    await this.redis.eval(UPDATE_REMAINING_QTY, 1, metaKey, orderId, newRemainingQty);
  }

  /**
   * Finds the next N maker orders whose price crosses the taker's price.
   * Returns them in price-time priority order (best price first, FIFO at same price).
   *
   * IMPORTANT: this is a peek, not a pop. The matching engine MUST call
   * removeMakerOrder() or updateRemainingQuantity() after each successful
   * DB commit. If the engine crashes between peek and commit, the maker
   * stays on the book — no harm done (idempotent retry).
   */
  async peekMatchableMakers(
    pair: TradingPair,
    takerSide: OrderSide,
    takerPrice: string,
    maxResults: number,
  ): Promise<OrderbookEntry[]> {
    const sellKey = RedisKeys.sellBook(pair);
    const buyKey = RedisKeys.buyBook(pair);
    const metaKey = RedisKeys.orderMeta(pair);

    const raw = (await this.redis.eval(
      PEEK_MATCHABLE_MAKERS,
      3,
      sellKey,
      buyKey,
      metaKey,
      takerSide,
      takerPrice,
      maxResults,
    )) as string[];

    const entries: OrderbookEntry[] = [];
    for (let i = 0; i < raw.length; i += 6) {
      const orderId = raw[i];
      const price = raw[i + 2];
      const quantity = raw[i + 3];
      const userId = raw[i + 4];
      const createdAt = Number(raw[i + 5]);
      if (!orderId || !price || !quantity || !userId) continue;
      entries.push({
        orderId,
        userId,
        pair,
        side: takerSide === OrderSide.BUY ? OrderSide.SELL : OrderSide.BUY,
        price,
        quantity,
        createdAt,
      });
    }
    return entries;
  }

  /**
   * Returns the best bid and best ask for a pair (the top of book).
   */
  async getTopOfBook(pair: TradingPair): Promise<TopOfBook> {
    const [bestAsk, bestBid] = await Promise.all([
      this.peekBest(pair, OrderSide.SELL),
      this.peekBest(pair, OrderSide.BUY),
    ]);

    const spread =
      bestAsk && bestBid
        ? subtractDecimal(bestAsk.price, bestBid.price)
        : null;

    return {
      pair,
      bestBid,
      bestAsk,
      spread,
    };
  }

  /**
   * Builds a full L2 snapshot aggregated by price level.
   * Used for the initial websocket subscription payload.
   */
  async getSnapshot(pair: TradingPair, depth: number = 50): Promise<OrderbookSnapshot> {
    const [askIds, bidIds] = await Promise.all([
      this.redis.zrange(RedisKeys.sellBook(pair), 0, depth - 1, 'WITHSCORES'),
      this.redis.zrange(RedisKeys.buyBook(pair), 0, depth - 1, 'WITHSCORES'),
    ]);

    const metaKey = RedisKeys.orderMeta(pair);
    const askLevels = await this.aggregateLevels(metaKey, askIds, pair, OrderSide.SELL);
    const bidLevels = await this.aggregateLevels(metaKey, bidIds, pair, OrderSide.BUY);

    return {
      pair,
      bids: bidLevels,
      asks: askLevels,
      timestamp: Date.now(),
    };
  }

  /**
   * Loads the entire orderbook from Postgres into Redis. Used on cold start
   * or after a Redis flush. Idempotent: clears existing keys first.
   */
  async rebuildFromDatabase(): Promise<{ pairs: number; orders: number }> {
    const repo = this.dataSource.getRepository(Order);
    const openOrders = await repo.find({
      where: { status: OrderStatus.OPEN },
      order: { createdAt: 'ASC' },
    });

    // Group by pair+side for batched pipeline.
    const byBook = new Map<string, Order[]>();
    for (const o of openOrders) {
      if (!isTradingPair(o.pair)) continue;
      const key = this.bookKey(o.pair, o.side);
      const arr = byBook.get(key) ?? [];
      arr.push(o);
      byBook.set(key, arr);
    }

    const pipeline = this.redis.pipeline();
    // Clear existing book + meta keys
    for (const pair of ['USD_ETB', 'USDT_ETB'] as const) {
      pipeline.del(RedisKeys.sellBook(pair));
      pipeline.del(RedisKeys.buyBook(pair));
      pipeline.del(RedisKeys.orderMeta(pair));
    }
    await pipeline.exec();

    // Re-add each open order
    let count = 0;
    for (const [, orders] of byBook) {
      const pair = orders[0]?.pair;
      if (!pair || !isTradingPair(pair)) continue;
      for (const o of orders) {
        const entry: OrderbookEntry = {
          orderId: o.id,
          userId: o.userId,
          pair,
          side: o.side,
          price: o.price,
          quantity: o.remainingQuantity,
          createdAt: o.createdAt.getTime(),
        };
        await this.addMakerOrder(entry);
        count++;
      }
    }

    this.logger.log(`Rebuilt orderbook: ${count} orders across ${byBook.size} books`);
    return { pairs: byBook.size, orders: count };
  }

  /**
   * Clears ALL orderbook data from Redis. Use with care — typically only
   * called from integration tests or an explicit operator command.
   */
  async clearAll(): Promise<void> {
    for (const pair of ['USD_ETB', 'USDT_ETB'] as const) {
      await this.redis.del(
        RedisKeys.sellBook(pair),
        RedisKeys.buyBook(pair),
        RedisKeys.orderMeta(pair),
      );
    }
  }

  // ===========================================================================
  // PRIVATE HELPERS
  // ===========================================================================

  private bookKey(pair: TradingPair, side: OrderSide): string {
    return side === 'SELL' ? RedisKeys.sellBook(pair) : RedisKeys.buyBook(pair);
  }

  private async peekBest(
    pair: TradingPair,
    side: OrderSide,
  ): Promise<{ price: string; quantity: string } | null> {
    const bookKey = this.bookKey(pair, side);
    const metaKey = RedisKeys.orderMeta(pair);
    const top = await this.redis.zrange(bookKey, 0, 0, 'WITHSCORES');
    if (top.length === 0) return null;
    const orderId = top[0];
    if (!orderId) return null;
    const [price, qty] = await this.redis.hmget(
      metaKey,
      `${orderId}:price`,
      `${orderId}:qty`,
    );
    if (!price || !qty) return null;
    return { price, quantity: qty };
  }

  private async aggregateLevels(
    metaKey: string,
    idScorePairs: string[],
    _pair: TradingPair,
    side: OrderSide,
  ): Promise<{ price: string; quantity: string; orderCount: number }[]> {
    if (idScorePairs.length === 0) return [];

    // Fetch all metadata in a single pipeline to minimize round-trips.
    const pipeline = this.redis.pipeline();
    for (let i = 0; i < idScorePairs.length; i += 2) {
      const id = idScorePairs[i];
      if (!id) continue;
      pipeline.hmget(metaKey, `${id}:price`, `${id}:qty`);
    }
    const results = await pipeline.exec();

    const levels = new Map<string, { quantity: string; orderCount: number }>();
    for (const r of results ?? []) {
      if (!r) continue;
      const [, value] = r;
      const [price, qty] = value as [string | null, string | null];
      if (!price || !qty) continue;
      const existing = levels.get(price);
      if (existing) {
        existing.quantity = this.add(existing.quantity, qty);
        existing.orderCount += 1;
      } else {
        levels.set(price, { quantity: qty, orderCount: 1 });
      }
    }

    // Sort: asks ascending, bids descending
    const arr = [...levels.entries()].map(([price, v]) => ({
      price,
      quantity: v.quantity,
      orderCount: v.orderCount,
    }));
    arr.sort((a, b) =>
      side === 'SELL' ? Number(a.price) - Number(b.price) : Number(b.price) - Number(a.price),
    );
    return arr;
  }

  private add(a: string, b: string): string {
    // Tiny inline add (we keep the matching.utils version for the engine).
    const aParts = a.split('.');
    const bParts = b.split('.');
    const scale = Math.max(aParts[1]?.length ?? 0, bParts[1]?.length ?? 0);
    const aInt = BigInt(aParts[0] + (aParts[1] ?? '').padEnd(scale, '0'));
    const bInt = BigInt(bParts[0] + (bParts[1] ?? '').padEnd(scale, '0'));
    const sum = aInt + bInt;
    const s = sum.toString().padStart(scale + 1, '0');
    if (scale === 0) return s;
    return `${s.slice(0, -scale) || '0'}.${s.slice(-scale)}`.replace(/0+$/, '') || '0';
  }

  /** Test-only: returns the underlying Redis client (for mocks). */
  getClient(): Redis {
    return this.redis;
  }

  /** Test-only: injects a mock Redis client. */
  setClientForTesting(client: Redis): void {
    this.redis = client;
  }
}
