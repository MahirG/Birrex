import { Module, Global } from '@nestjs/common';
import { OrderbookService } from './orderbook.service';

@Global()
@Module({
  providers: [OrderbookService],
  exports: [OrderbookService],
})
export class OrderbookModule {}
