import { Injectable, Logger } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, EntityManager, LessThan } from 'typeorm';
import { v4 as uuid } from 'uuid';
import {
  Order,
  OrderSide,
  OrderStatus,
  OrderType,
  Trade,
  TradeStatus,
  User,
  UserStatus,
  KycStatus,
} from '../../database/entities';
import {
  type TradingPair,
  type OrderbookEntry,
  type PlaceOrderResult,
  type MatchedTrade,
  isTradingPair,
} from '../../types/orderbook.types';
import {
  subtractDecimal,
  addDecimal,
  multiplyDecimal,
  lessThan,
  executionPrice,
} from '../../utils/matching.utils';
import { OrderbookService } from '../orderbook/orderbook.service';
import { EscrowService } from '../escrow/escrow.service';
import { RealtimeBroadcaster } from '../websocket/realtime.broadcaster';
import { I18nService, TranslationKey } from '../i18n/i18n.service';
import { BusinessException, ErrorCode } from '../../common/exceptions/business.exception';
import { getEnv } from '../../config';

/**
 * MatchingEngineService — the heart of the P2P exchange.
 *
 * ALGORITHM (Price-Time Priority):
 *
 *   1. Place an order.
 *   2. Validate the user (active + KYC verified) and the order params.
 *   3. Insert the order into Postgres as OPEN (the source of truth).
 *   4. Run the IMMEDIATE-MATCH pass:
 *        a. Peek the opposite-side book for up to N makers whose price crosses.
 *        b. For each matchable maker (in best-price-first, FIFO order):
 *             - Compute the trade quantity = min(takerRemaining, makerRemaining).
 *             - Call EscrowService.lockEscrow() which:
 *                 * Atomically locks the seller's crypto in a SERIALIZABLE tx.
 *                 * Inserts the Trade row in ESCROWED state.
 *                 * Updates makerOrder.filledQuantity.
 *                 * Writes a WalletTransaction ledger row.
 *             - Update the Redis orderbook:
 *                 * If maker fully filled  → removeMakerOrder()
 *                 * If maker partially filled → updateRemainingQuantity()
 *             - Broadcast trade:created to both users via WebSocket.
 *             - Decrement takerRemaining by the trade quantity.
 *             - If takerRemaining == 0 → break.
 *   5. If takerRemaining > 0 AND order type == LIMIT:
 *        Add the remaining quantity to the Redis orderbook as a new maker.
 *   6. Return PlaceOrderResult with all trades + remaining qty.
 *
 * RACE-CONDITION DEFENSES:
 *
 *   (a) Maker self-match prevention: a taker cannot match against the same
 *       user's own maker order. Checked before every escrow lock.
 *
 *   (b) Per-pair distributed lock via Redis SET NX (with TTL):
 *       Serializes matching passes for the same pair so two concurrent takers
 *       cannot both think they got the same maker. The lock has a 5s TTL so
 *       a crashed engine doesn't permanently block the pair.
 *
 *   (c) SERIALIZABLE Postgres transaction in EscrowService:
 *       Even if (b) somehow fails, the database will reject one of the two
 *       concurrent escrow locks (the second one will see the maker order as
 *       already FILLED).
 *
 *   (d) Maker order re-load inside escrow lock with pessimistic_write:
 *       The escrow service re-reads the maker order with FOR UPDATE, so even
 *       reads during the lock window cannot observe stale state.
 *
 *   (e) Redis peek is non-destructive:
 *       If the engine crashes between peek and escrow lock, the maker stays
 *       on the book — no state lost. The next matching pass will simply
 *       re-discover it.
 *
 * HORIZONTAL SCALABILITY:
 *   The engine is fully stateless — no in-memory state survives a restart.
 *   All state lives in Postgres (orders, trades, wallets) and Redis (book).
 *   Multiple NestJS instances can place orders concurrently; the per-pair
 *   Redis lock ensures only one matching pass executes at a time per pair.
 */
@Injectable()
export class MatchingEngineService {
  private readonly logger = new Logger(MatchingEngineService.name);

  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly orderbook: OrderbookService,
    private readonly escrow: EscrowService,
    private readonly broadcaster: RealtimeBroadcaster,
    private readonly i18n: I18nService,
  ) {}

  // ===========================================================================
  // PUBLIC: Place Order
  // ===========================================================================

  async placeOrder(params: {
    userId: string;
    pair: string;
    side: OrderSide;
    type?: OrderType;
    price?: string;
    quantity: string;
    paymentMethodId?: string;
    paymentWindowMinutes?: number;
    minOrderValue?: string;
    maxOrderValue?: string;
    terms?: string;
    traceId?: string;
  }): Promise<PlaceOrderResult> {
    const traceId = params.traceId ?? uuid();
    const env = getEnv();
    const pair = this.validatePair(params.pair);
    const orderType = params.type ?? OrderType.LIMIT;
    const paymentWindowMinutes = params.paymentWindowMinutes ?? env.DEFAULT_PAYMENT_WINDOW_MINUTES;

    // ---- 1. Validate user + business rules ----
    await this.validateUserForTrading(params.userId);
    this.validateOrderBusinessRules({
      pair,
      side: params.side,
      type: orderType,
      price: params.price,
      quantity: params.quantity,
      minOrderValue: params.minOrderValue,
      maxOrderValue: params.maxOrderValue,
    });

    // ---- 2. Insert the order into Postgres as OPEN ----
    const takerOrder = await this.dataSource.transaction(async (manager: EntityManager) => {
      const order = manager.create(Order, {
        userId: params.userId,
        pair,
        side: params.side,
        type: orderType,
        price: params.price ?? '0',
        quantity: params.quantity,
        filledQuantity: '0',
        status: OrderStatus.OPEN,
        paymentMethodId: params.paymentMethodId ?? null,
        paymentWindowMinutes,
        minOrderValue: params.minOrderValue ?? null,
        maxOrderValue: params.maxOrderValue ?? null,
        terms: params.terms ?? null,
        isMaker: false, // starts as a taker; becomes a maker if any qty remains
      });
      return manager.save(order);
    });

    // ---- 3. Acquire per-pair distributed lock ----
    // The lock has a TTL of 5s; if this instance crashes, the lock auto-expires
    // and another instance can take over. We use a per-pair lock (not global)
    // so USD_ETB and USDT_ETB can match concurrently.
    const lockKey = `lock:pair-match:${pair}`;
    const lockToken = uuid();
    const acquired = await this.tryAcquireLock(lockKey, lockToken, 5);
    if (!acquired) {
      // Another matching pass is in flight for this pair. We retry briefly
      // rather than failing the order — the user shouldn't see a 503 just
      // because two people placed orders at the same time.
      const retried = await this.retryAcquireLock(lockKey, lockToken, 5, 500);
      if (!retried) {
        throw new BusinessException(
          ErrorCode.SERVICE_UNAVAILABLE,
          `Orderbook for ${pair} is busy — please retry`,
        );
      }
    }

    try {
      // ---- 4. Run the immediate-match pass ----
      const trades = await this.runImmediateMatchPass({
        takerOrder,
        pair,
        side: params.side,
        takerPrice: params.price ?? '0',
        orderType,
        paymentWindowMinutes,
        traceId,
      });

      // ---- 5. Add remaining quantity to the orderbook (LIMIT only) ----
      const filledQty = trades.reduce(
        (sum, t) => addDecimal(sum, t.quantity),
        '0',
      );
      const remainingQty = subtractDecimal(params.quantity, filledQty);

      let finalStatus: OrderStatus;
      if (lessThan(remainingQty, '0.00000001')) {
        finalStatus = OrderStatus.FILLED;
      } else if (filledQty !== '0') {
        finalStatus = OrderStatus.PARTIALLY_FILLED;
      } else {
        finalStatus = OrderStatus.OPEN;
      }

      await this.dataSource.transaction(async (manager: EntityManager) => {
        takerOrder.filledQuantity = filledQty;
        takerOrder.status = finalStatus;
        takerOrder.isMaker = finalStatus !== OrderStatus.FILLED && orderType === OrderType.LIMIT;
        if (finalStatus === OrderStatus.FILLED) takerOrder.filledAt = new Date();
        await manager.save(takerOrder);
      });

      if (
        finalStatus !== OrderStatus.FILLED &&
        orderType === OrderType.LIMIT &&
        !lessThan(remainingQty, '0.00000001')
      ) {
        // Add as a resting maker.
        const entry: OrderbookEntry = {
          orderId: takerOrder.id,
          userId: params.userId,
          pair,
          side: params.side,
          price: params.price ?? '0',
          quantity: remainingQty,
          createdAt: takerOrder.createdAt.getTime(),
        };
        await this.orderbook.addMakerOrder(entry);

        // Broadcast orderbook delta.
        await this.broadcaster.emitOrderbookUpdate(
          pair,
          {
            pair,
            side: params.side,
            price: params.price ?? '0',
            quantityDelta: remainingQty,
          },
          traceId,
        );
      }

      // ---- 6. Broadcast order:placed to the taker ----
      await this.broadcaster.emitOrderPlaced(
        params.userId,
        {
          orderId: takerOrder.id,
          pair,
          side: params.side,
          price: params.price ?? '0',
          quantity: params.quantity,
          status: finalStatus,
        },
        traceId,
      );

      this.logger.log(
        `[${traceId}] Order ${takerOrder.id} placed: ${params.side} ${params.quantity} ${pair} ` +
          `@ ${params.price ?? 'MKT'} → ${finalStatus} (filled ${filledQty}, trades ${trades.length})`,
      );

      return {
        takerOrderId: takerOrder.id,
        status: finalStatus,
        filledQuantity: filledQty,
        remainingQuantity: remainingQty,
        trades,
      };
    } finally {
      await this.releaseLock(lockKey, lockToken);
    }
  }

  // ===========================================================================
  // PUBLIC: Cancel Order
  // ===========================================================================

  async cancelOrder(params: {
    userId: string;
    orderId: string;
    traceId?: string;
  }): Promise<{ orderId: string; cancelledAt: Date }> {
    const traceId = params.traceId ?? uuid();

    const order = await this.dataSource.transaction(async (manager: EntityManager) => {
      const o = await manager.findOne(Order, {
        where: { id: params.orderId },
        lock: { mode: 'pessimistic_write' },
      });
      if (!o) {
        throw new BusinessException(ErrorCode.ORDER_NOT_FOUND, `Order ${params.orderId} not found`);
      }
      if (o.userId !== params.userId) {
        throw new BusinessException(ErrorCode.FORBIDDEN, 'Cannot cancel another user\'s order');
      }
      if (o.status === OrderStatus.FILLED || o.status === OrderStatus.CANCELLED || o.status === OrderStatus.EXPIRED) {
        throw new BusinessException(
          ErrorCode.ORDER_NOT_CANCELLABLE,
          `Order is ${o.status} and cannot be cancelled`,
        );
      }
      o.status = OrderStatus.CANCELLED;
      o.cancelledAt = new Date();
      return manager.save(o);
    });

    // Remove from Redis book if it was a resting maker.
    // removeMakerOrder() is idempotent: returns false if it wasn't there.
    if (order.pair === 'USD_ETB' || order.pair === 'USDT_ETB') {
      const removed = await this.orderbook.removeMakerOrder(
        order.pair as TradingPair,
        order.side,
        order.id,
      );
      if (removed) {
        await this.broadcaster.emitOrderbookUpdate(
          order.pair,
          {
            pair: order.pair,
            side: order.side,
            price: order.price,
            quantityDelta: '-' + order.remainingQuantity,
          },
          traceId,
        );
      }
    }

    this.logger.log(`[${traceId}] Order ${order.id} cancelled by user ${params.userId}`);
    return { orderId: order.id, cancelledAt: order.cancelledAt ?? new Date() };
  }

  // ===========================================================================
  // SCHEDULED: Expire stale orders + payment windows
  // ===========================================================================

  /**
   * Sweeps the database for orders whose `expires_at` has passed and marks
   * them as EXPIRED. Intended to run on a cron (every minute).
   *
   * NOTE: This does NOT expire trades with open payment windows — that's a
   * separate concern handled by the trade lifecycle module (Phase 2).
   */
  async expireStaleOrders(): Promise<{ expired: number }> {
    const now = new Date();
    const result = await this.dataSource
      .getRepository(Order)
      .update(
        { status: OrderStatus.OPEN, expiresAt: LessThan(now) },
        { status: OrderStatus.EXPIRED },
      );
    if (result.affected && result.affected > 0) {
      this.logger.log(`Expired ${result.affected} stale orders`);
    }
    return { expired: result.affected ?? 0 };
  }

  // ===========================================================================
  // CORE: Immediate-Match Pass
  // ===========================================================================

  /**
   * The core matching loop. Runs inside the per-pair distributed lock.
   *
   * Returns the list of trades produced. The caller is responsible for:
   *   - Persisting the final taker order status.
   *   - Adding any remaining qty to the orderbook.
   *   - Broadcasting the order:placed event.
   */
  private async runImmediateMatchPass(params: {
    takerOrder: Order;
    pair: TradingPair;
    side: OrderSide;
    takerPrice: string;
    orderType: OrderType;
    paymentWindowMinutes: number;
    traceId: string;
  }): Promise<ReadonlyArray<MatchedTrade>> {
    const trades: MatchedTrade[] = [];
    let takerRemaining = params.takerOrder.quantity;
    let dailyCounter = await this.nextDailyTradeCounter();

    // MARKET orders match at any price — set takerPrice to a sentinel that
    // crosses everything. The execution price is still the maker's price.
    const effectiveTakerPrice =
      params.orderType === OrderType.MARKET
        ? params.side === OrderSide.BUY ? '99999999' : '0'
        : params.takerPrice;

    const MAX_ITERATIONS = 100; // safety bound
    let iterations = 0;

    while (!lessThan(takerRemaining, '0.00000001') && iterations < MAX_ITERATIONS) {
      iterations++;
      const candidates = await this.orderbook.peekMatchableMakers(
        params.pair,
        params.side,
        effectiveTakerPrice,
        10, // batch size — process 10 candidates per peek to amortize Redis RTT
      );

      if (candidates.length === 0) {
        // No more matchable makers — taker remaining becomes a resting order.
        break;
      }

      for (const maker of candidates) {
        if (lessThan(takerRemaining, '0.00000001')) break;

        // Self-match prevention — a user cannot trade with themselves.
        if (maker.userId === params.takerOrder.userId) {
          continue;
        }

        // Compute trade quantity = min(takerRemaining, makerRemaining).
        const tradeQty = lessThan(takerRemaining, maker.quantity)
          ? takerRemaining
          : maker.quantity;

        // The trade executes at the MAKER's price (price-time priority).
        const tradePrice = executionPrice(maker.price);
        const totalValue = multiplyDecimal(tradeQty, tradePrice);

        // Compute payment window expiry for this trade.
        const now = Date.now();
        const expiresAt = now + params.paymentWindowMinutes * 60_000;

        try {
          // ---- Escrow lock (atomic DB tx) ----
          // This is the financial commit point. If it succeeds, the trade is
          // real — crypto is locked, ledger is written, trade row exists.
          const lockParams = EscrowService.toLockParams(
            {
              tradeId: '', // escrow service will assign it
              tradeNumber: '',
              makerOrderId: maker.orderId,
              takerOrderId: params.takerOrder.id,
              makerUserId: maker.userId,
              takerUserId: params.takerOrder.userId,
              pair: params.pair,
              side: params.side,
              price: tradePrice,
              quantity: tradeQty,
              totalValue,
              paymentWindowMinutes: params.paymentWindowMinutes,
              paymentWindowExpiresAt: expiresAt,
            },
            params.paymentWindowMinutes,
            dailyCounter,
          );
          const { trade } = await this.escrow.lockEscrow(lockParams);
          dailyCounter++;

          // ---- Update Redis book ----
          const newMakerRemaining = subtractDecimal(maker.quantity, tradeQty);
          if (lessThan(newMakerRemaining, '0.00000001')) {
            await this.orderbook.removeMakerOrder(params.pair, maker.side, maker.orderId);
          } else {
            await this.orderbook.updateRemainingQuantity(
              params.pair,
              maker.orderId,
              newMakerRemaining,
            );
          }

          // ---- Build the MatchedTrade record ----
          const matchedTrade: MatchedTrade = {
            tradeId: trade.id,
            tradeNumber: trade.tradeNumber,
            makerOrderId: maker.orderId,
            takerOrderId: params.takerOrder.id,
            makerUserId: maker.userId,
            takerUserId: params.takerOrder.userId,
            pair: params.pair,
            side: params.side,
            price: tradePrice,
            quantity: tradeQty,
            totalValue,
            paymentWindowMinutes: params.paymentWindowMinutes,
            paymentWindowExpiresAt: expiresAt,
          };
          trades.push(matchedTrade);

          // ---- Broadcast trade:created to BOTH parties ----
          await this.broadcaster.emitTradeCreated(
            maker.userId,
            params.takerOrder.userId,
            {
              tradeId: trade.id,
              tradeNumber: trade.tradeNumber,
              pair: params.pair,
              side: params.side,
              price: tradePrice,
              quantity: tradeQty,
              totalValue,
              counterpartyId: '', // broadcaster sets this per recipient
              paymentWindowMinutes: params.paymentWindowMinutes,
              paymentWindowExpiresAt: expiresAt,
              status: TradeStatus.ESCROWED,
            },
            params.traceId,
          );

          // ---- Broadcast public orderbook update + trade tick ----
          await this.broadcaster.emitOrderbookUpdate(
            params.pair,
            {
              pair: params.pair,
              side: maker.side,
              price: maker.price,
              quantityDelta: '-' + tradeQty,
            },
            params.traceId,
          );
          await this.broadcaster.emitTradeTick(
            params.pair,
            {
              pair: params.pair,
              price: tradePrice,
              quantity: tradeQty,
              side: params.side,
              timestamp: now,
            },
            params.traceId,
          );

          // ---- Decrement taker remaining ----
          takerRemaining = subtractDecimal(takerRemaining, tradeQty);
        } catch (err) {
          // If the escrow lock fails (e.g. maker wallet insufficient, race
          // condition where maker got cancelled), log and skip to the next
          // candidate. We do NOT abort the entire pass.
          this.logger.warn(
            `[${params.traceId}] Escrow lock failed for maker ${maker.orderId}: ${(err as Error).message}`,
          );
          // Remove the orphan from the Redis book if it doesn't exist in DB.
          if (err instanceof BusinessException && err.errorCode === ErrorCode.ORDER_NOT_FOUND) {
            await this.orderbook.removeMakerOrder(params.pair, maker.side, maker.orderId);
          }
        }
      }
    }

    return trades;
  }

  // ===========================================================================
  // VALIDATION HELPERS
  // ===========================================================================

  private async validateUserForTrading(userId: string): Promise<void> {
    const user = await this.dataSource.getRepository(User).findOne({
      where: { id: userId },
      select: ['id', 'status', 'kycStatus', 'is2faEnabled'],
    });
    if (!user) {
      throw new BusinessException(ErrorCode.NOT_FOUND, `User ${userId} not found`);
    }
    if (user.status !== UserStatus.ACTIVE) {
      throw new BusinessException(
        ErrorCode.ACCOUNT_NOT_ACTIVE,
        `User account is ${user.status}; must be ACTIVE to trade`,
      );
    }
    if (user.kycStatus !== KycStatus.VERIFIED) {
      throw new BusinessException(
        ErrorCode.KYC_NOT_VERIFIED,
        `User KYC is ${user.kycStatus}; must be VERIFIED to trade`,
      );
    }
  }

  private validateOrderBusinessRules(params: {
    pair: TradingPair;
    side: OrderSide;
    type: OrderType;
    price?: string;
    quantity: string;
    minOrderValue?: string;
    maxOrderValue?: string;
  }): void {
    const env = getEnv();

    if (params.type === OrderType.LIMIT) {
      if (!params.price) {
        throw new BusinessException(
          ErrorCode.INVALID_ORDER_PRICE,
          'LIMIT order requires a price',
        );
      }
      if (lessThan(params.price, '0.00000001')) {
        throw new BusinessException(
          ErrorCode.INVALID_ORDER_PRICE,
          'Price must be greater than zero',
        );
      }
    }

    if (lessThan(params.quantity, '0.00000001')) {
      throw new BusinessException(
        ErrorCode.INVALID_ORDER_QUANTITY,
        'Quantity must be greater than zero',
      );
    }

    // Enforce ETB min/max trade value.
    // For a BUY: the user will pay qty * price in ETB.
    // For a SELL: the user will receive qty * price in ETB.
    // Either way, the trade value in ETB must fall within [min, max].
    if (params.price && params.type === OrderType.LIMIT) {
      const value = multiplyDecimal(params.quantity, params.price);
      if (lessThan(value, String(env.MIN_ORDER_VALUE_ETB))) {
        throw new BusinessException(
          ErrorCode.ORDER_BELOW_MIN_VALUE,
          this.i18n.translate(TranslationKey.ORDER_BELOW_MIN, 'en', {
            value,
            min: env.MIN_ORDER_VALUE_ETB,
          }),
          { value, min: env.MIN_ORDER_VALUE_ETB },
        );
      }
      if (lessThan(String(env.MAX_ORDER_VALUE_ETB), value)) {
        throw new BusinessException(
          ErrorCode.ORDER_ABOVE_MAX_VALUE,
          this.i18n.translate(TranslationKey.ORDER_ABOVE_MAX, 'en', {
            value,
            max: env.MAX_ORDER_VALUE_ETB,
          }),
          { value, max: env.MAX_ORDER_VALUE_ETB },
        );
      }
    }
  }

  private validatePair(pair: string): TradingPair {
    if (!isTradingPair(pair)) {
      throw new BusinessException(
        ErrorCode.INVALID_PAIR,
        `Pair ${pair} not supported. Supported: USD_ETB, USDT_ETB`,
      );
    }
    return pair;
  }

  // ===========================================================================
  // REDIS LOCK HELPERS
  // ===========================================================================

  private async tryAcquireLock(
    key: string,
    token: string,
    ttlSeconds: number,
  ): Promise<boolean> {
    const redis = this.orderbook.getClient();
    const result = await redis.set(key, token, 'EX', ttlSeconds, 'NX');
    return result === 'OK';
  }

  private async retryAcquireLock(
    key: string,
    token: string,
    ttlSeconds: number,
    totalTimeoutMs: number,
  ): Promise<boolean> {
    const start = Date.now();
    const intervalMs = 50;
    while (Date.now() - start < totalTimeoutMs) {
      await new Promise((resolve) => setTimeout(resolve, intervalMs));
      if (await this.tryAcquireLock(key, token, ttlSeconds)) return true;
    }
    return false;
  }

  /**
   * Releases the lock using a Lua CAS pattern so we only delete our own token
   * (never another instance's). This avoids the classic "lock auto-expired
   * then we deleted someone else's lock" bug.
   */
  private async releaseLock(key: string, token: string): Promise<void> {
    const redis = this.orderbook.getClient();
    const script = `
      if redis.call('GET', KEYS[1]) == ARGV[1] then
        return redis.call('DEL', KEYS[1])
      else
        return 0
      end
    `;
    await redis.eval(script, 1, key, token);
  }

  // ===========================================================================
  // DAILY COUNTER (for trade numbers like TRD-YYYYMMDD-XXXXX)
  // ===========================================================================

  /**
   * Returns the next sequence number for today's trades.
   * Uses a Redis INCR on a date-keyed counter — atomic, fast, and resets
   * naturally at midnight UTC when the key rolls over.
   *
   * If Redis is unavailable, falls back to counting today's trades in
   * Postgres. (Slow but correct.)
   */
  private async nextDailyTradeCounter(): Promise<number> {
    const today = new Date().toISOString().slice(0, 10).replaceAll('-', '');
    const key = `counter:trade:${today}`;
    try {
      const redis = this.orderbook.getClient();
      const next = await redis.incr(key);
      // Set TTL so the key auto-expires after 2 days (in case of timezone skew).
      if (next === 1) {
        await redis.expire(key, 172800); // 48h
      }
      return next;
    } catch {
      // Fallback: count today's trades.
      const count = await this.dataSource
        .getRepository(Trade)
        .count({
          where: { createdAt: LessThan(new Date(Date.now() + 86400_000)) },
        });
      return count + 1;
    }
  }

  /** Test-only: allows tests to override the daily counter. */
  async _testForceDailyCounter(_n: number): Promise<void> {
    // Intentionally a no-op in production. Tests mock the Redis client.
  }

  // Expose data source for tests that need direct DB access.
  _dataSource(): DataSource {
    return this.dataSource;
  }
}
