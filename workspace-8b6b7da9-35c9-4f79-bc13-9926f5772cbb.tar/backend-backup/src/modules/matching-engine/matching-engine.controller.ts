import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  Post,
  UseGuards,
  UseInterceptors,
  Logger,
  Req,
} from '@nestjs/common';
import { ThrottlerGuard } from '@nestjs/throttler';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CurrentUser, type AuthUser } from '../../common/decorators/current-user.decorator';
import { LoggingInterceptor } from '../../common/interceptors/logging.interceptor';
import { MatchingEngineService } from './matching-engine.service';
import { OrderbookService } from '../orderbook/orderbook.service';
import {
  PlaceOrderDto,
  type PlaceOrderResponse,
} from './dto/place-order.dto';
import { randomUUID } from 'crypto';
import type { Request } from 'express';
import type { TradingPair } from '../../types/orderbook.types';

interface TraceableRequest extends Request {
  traceId?: string;
}

/**
 * MatchingEngineController — REST entry points for order placement + cancel.
 *
 * All routes require JWT auth and are throttled by ThrottlerGuard.
 * Per-user rate limits are enforced via the ThrottlerModule configuration
 * in AppModule.
 */
@Controller('v1/orders')
@UseGuards(JwtAuthGuard, ThrottlerGuard)
@UseInterceptors(LoggingInterceptor)
export class MatchingEngineController {
  private readonly logger = new Logger(MatchingEngineController.name);

  constructor(
    private readonly matchingEngine: MatchingEngineService,
    private readonly orderbook: OrderbookService,
  ) {}

  /**
   * POST /v1/orders — place a new order.
   * The matching engine runs the immediate-match pass synchronously and
   * returns the list of trades produced + the order's final status.
   */
  @Post()
  @HttpCode(HttpStatus.CREATED)
  async placeOrder(
    @CurrentUser() user: AuthUser,
    @Body() dto: PlaceOrderDto,
    @Req() req: TraceableRequest,
  ): Promise<PlaceOrderResponse> {
    const traceId = (req.headers['x-trace-id'] as string | undefined) ?? randomUUID();
    this.logger.log(`[${traceId}] POST /v1/orders user=${user.id} pair=${dto.pair} side=${dto.side} qty=${dto.quantity}`);

    const result = await this.matchingEngine.placeOrder({
      userId: user.id,
      pair: dto.pair,
      side: dto.side,
      type: dto.type,
      price: dto.price,
      quantity: dto.quantity,
      paymentMethodId: dto.paymentMethodId,
      paymentWindowMinutes: dto.paymentWindowMinutes,
      minOrderValue: dto.minOrderValue,
      maxOrderValue: dto.maxOrderValue,
      terms: dto.terms,
      traceId,
    });

    return {
      orderId: result.takerOrderId,
      status: result.status,
      filledQuantity: result.filledQuantity,
      remainingQuantity: result.remainingQuantity,
      trades: result.trades.map((t) => ({
        tradeId: t.tradeId,
        tradeNumber: t.tradeNumber,
        price: t.price,
        quantity: t.quantity,
        totalValue: t.totalValue,
        paymentWindowExpiresAt: new Date(t.paymentWindowExpiresAt).toISOString(),
      })),
    };
  }

  /**
   * DELETE /v1/orders/:orderId — cancel a resting order.
   * Only the order's owner may cancel; only OPEN / PARTIALLY_FILLED orders
   * can be cancelled.
   */
  @Delete(':orderId')
  @HttpCode(HttpStatus.OK)
  async cancelOrder(
    @CurrentUser() user: AuthUser,
    @Param('orderId') orderId: string,
    @Req() req: TraceableRequest,
  ): Promise<{ orderId: string; cancelledAt: string }> {
    const traceId = (req.headers['x-trace-id'] as string | undefined) ?? randomUUID();
    const result = await this.matchingEngine.cancelOrder({
      userId: user.id,
      orderId,
      traceId,
    });
    return { orderId: result.orderId, cancelledAt: result.cancelledAt.toISOString() };
  }

  /**
   * GET /v1/orders/orderbook/:pair — fetch the current L2 orderbook snapshot.
   * Depth defaults to 50 price levels per side.
   */
  @Get('orderbook/:pair')
  @HttpCode(HttpStatus.OK)
  async getOrderbook(@Param('pair') pair: string) {
    if (pair !== 'USD_ETB' && pair !== 'USDT_ETB') {
      return { error: 'INVALID_PAIR', message: `Pair ${pair} not supported` };
    }
    return this.orderbook.getSnapshot(pair as TradingPair, 50);
  }

  /**
   * GET /v1/orders/top-of-book/:pair — fetch just the best bid/ask.
   */
  @Get('top-of-book/:pair')
  @HttpCode(HttpStatus.OK)
  async getTopOfBook(@Param('pair') pair: string) {
    if (pair !== 'USD_ETB' && pair !== 'USDT_ETB') {
      return { error: 'INVALID_PAIR', message: `Pair ${pair} not supported` };
    }
    return this.orderbook.getTopOfBook(pair as TradingPair);
  }
}
