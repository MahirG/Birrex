import { Test, type TestingModule } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { DataSource, EntityManager, Repository } from 'typeorm';
import { v4 as uuid } from 'uuid';
import Redis from 'ioredis';

import { MatchingEngineService } from '../matching-engine.service';
import { OrderbookService } from '../../orderbook/orderbook.service';
import { EscrowService } from '../../escrow/escrow.service';
import { RealtimeBroadcaster } from '../../websocket/realtime.broadcaster';
import { I18nService } from '../../i18n/i18n.service';

import {
  Order,
  OrderSide,
  OrderStatus,
  OrderType,
  Trade,
  TradeStatus,
  Wallet,
  WalletCurrency,
  User,
  UserStatus,
  KycStatus,
  UserRole,
  WalletTransaction,
} from '../../../database/entities';
import {
  ErrorCode,
} from '../../../common/exceptions/business.exception';
import type { OrderbookEntry } from '../../../types/orderbook.types';
import { _resetEnvCacheForTesting } from '../../../config';

// ---------------------------------------------------------------------------
// Test fixtures
// ---------------------------------------------------------------------------

interface TestUser {
  user: User;
  wallet: Wallet;
}

/**
 * Builds a minimal but realistic in-memory test environment:
 *   - Real DataSource backed by a SQLite-in-memory Postgres emulator? No —
 *     we use a mocked DataSource that simulates transactions and serializable
 *     behavior. The reason: the matching engine's correctness proof is in
 *     the LOGIC, not in the DB driver. We assert that the right SQL operations
 *     happen in the right order, and that the financial invariants hold at
 *     every step.
 *
 * For full integration tests (real Postgres + Redis), see
 * `test/matching-engine.e2e-spec.ts` (Phase 2 deliverable).
 */
class MockDataSource {
  // In-memory state — mirrors what real Postgres would store.
  users = new Map<string, User>();
  wallets = new Map<string, Wallet>();
  orders = new Map<string, Order>();
  trades = new Map<string, Trade>();
  transactions = new Map<string, WalletTransaction>();

  // Transaction simulation: each call to .transaction() gets a fresh
  // EntityManager that operates on the same in-memory maps.
  // Supports both TypeORM call signatures:
  //   transaction(fn)                           — default isolation
  //   transaction(isolationLevel, fn)           — explicit isolation
  async transaction<T>(
    isolationOrFn: string | ((manager: EntityManager) => Promise<T>),
    maybeFn?: (manager: EntityManager) => Promise<T>,
  ): Promise<T> {
    const fn = typeof isolationOrFn === 'function' ? isolationOrFn : maybeFn!;
    const manager = new MockEntityManager(this) as unknown as EntityManager;
    return fn(manager);
  }

  getRepository<T extends object>(entity: new (...args: unknown[]) => T): Repository<T> {
    return new MockRepository(this, entity) as unknown as Repository<T>;
  }
}

class MockEntityManager {
  constructor(private readonly ds: MockDataSource) {}

  async findOne(entity: new (...args: unknown[]) => unknown, options: { where: Record<string, unknown>; lock?: unknown }): Promise<unknown | null> {
    if (entity === Order) {
      const id = options.where.id as string;
      return this.ds.orders.get(id) ?? null;
    }
    if (entity === Trade) {
      const id = options.where.id as string;
      return this.ds.trades.get(id) ?? null;
    }
    if (entity === User) {
      const id = options.where.id as string;
      return this.ds.users.get(id) ?? null;
    }
    return null;
  }

  create<T extends object>(entity: new (...args: unknown[]) => T, data: Partial<T>): T {
    return Object.assign(new entity(), data) as T;
  }

  async save<T>(entity: T | T[]): Promise<T | T[]> {
    if (Array.isArray(entity)) {
      return Promise.all(entity.map((e) => this.save(e))) as unknown as Promise<T[]>;
    }
    const obj = entity as unknown as { id?: string; createdAt?: Date; updatedAt?: Date };
    const now = new Date();
    if (obj instanceof Order) {
      if (!obj.id) obj.id = uuid();
      if (!obj.createdAt) obj.createdAt = now;
      obj.updatedAt = now;
      this.ds.orders.set(obj.id, obj);
    } else if (obj instanceof Trade) {
      if (!obj.id) obj.id = uuid();
      if (!obj.createdAt) obj.createdAt = now;
      obj.updatedAt = now;
      this.ds.trades.set(obj.id, obj);
    } else if (obj instanceof Wallet) {
      if (!obj.id) obj.id = uuid();
      if (!obj.createdAt) obj.createdAt = now;
      obj.updatedAt = now;
      this.ds.wallets.set(obj.id, obj);
    } else if (obj instanceof WalletTransaction) {
      if (!obj.id) obj.id = uuid();
      if (!obj.createdAt) obj.createdAt = now;
      this.ds.transactions.set(obj.id, obj);
    }
    return entity;
  }

  async update(
    criteria: Record<string, unknown>,
    partial: Record<string, unknown>,
  ): Promise<{ affected: number }> {
    let count = 0;
    for (const order of this.ds.orders.values()) {
      let match = true;
      for (const [k, v] of Object.entries(criteria)) {
        if ((order as unknown as Record<string, unknown>)[k] !== v) {
          match = false;
          break;
        }
      }
      if (match) {
        Object.assign(order, partial);
        count++;
      }
    }
    return { affected: count };
  }

  /**
   * Mock query builder. Tracks where/andWhere parameters so getOne() can
   * filter the in-memory wallet collection by (userId, currency).
   *
   * The matching engine only uses createQueryBuilder() for wallet lookups,
   * so this mock only needs to support that use case.
   */
  createQueryBuilder() {
    const self = this;
    const params: Record<string, unknown> = {};
    return {
      setLock: function () { return this; },
      where: function (_clause: string, p: Record<string, unknown>) {
        Object.assign(params, p);
        return this;
      },
      andWhere: function (_clause: string, p: Record<string, unknown>) {
        Object.assign(params, p);
        return this;
      },
      getOne: async function (): Promise<Wallet | null> {
        // Find the wallet matching both user_id (params.uid) and currency (params.cur).
        for (const w of self.ds.wallets.values()) {
          if (params.uid && w.userId !== params.uid) continue;
          if (params.cur && w.currency !== params.cur) continue;
          return w;
        }
        return null;
      },
    };
  }

  count(options: { where: Record<string, unknown> }): number {
    let n = 0;
    for (const t of this.ds.trades.values()) {
      let match = true;
      for (const [k, v] of Object.entries(options.where)) {
        if ((t as unknown as Record<string, unknown>)[k] === v) match = false;
      }
      if (match) n++;
    }
    return n;
  }
}

class MockRepository<T extends object> {
  constructor(
    private readonly ds: MockDataSource,
    private readonly entity: new (...args: unknown[]) => T,
  ) {}

  async findOne(options: { where: Record<string, unknown>; select?: string[] }): Promise<T | null> {
    if (this.entity === User) {
      const id = options.where.id as string;
      const u = this.ds.users.get(id);
      if (!u) return null;
      if (options.select) {
        const picked: Record<string, unknown> = {};
        for (const s of options.select) {
          picked[s] = (u as unknown as Record<string, unknown>)[s];
        }
        return picked as unknown as T;
      }
      return u as unknown as T;
    }
    if (this.entity === Order) {
      const id = options.where.id as string;
      return (this.ds.orders.get(id) ?? null) as unknown as T | null;
    }
    if (this.entity === Trade) {
      const id = options.where.id as string;
      return (this.ds.trades.get(id) ?? null) as unknown as T | null;
    }
    return null;
  }

  async find(): Promise<T[]> {
    if (this.entity === Order) {
      return [...this.ds.orders.values()].sort(
        (a, b) => a.createdAt.getTime() - b.createdAt.getTime(),
      ) as unknown as T[];
    }
    return [];
  }

  async count(): Promise<number> {
    if (this.entity === Trade) return this.ds.trades.size;
    return 0;
  }

  async update(
    criteria: Record<string, unknown>,
    partial: Record<string, unknown>,
  ): Promise<{ affected: number }> {
    let n = 0;
    if (this.entity === Order) {
      for (const o of this.ds.orders.values()) {
        let match = true;
        for (const [k, v] of Object.entries(criteria)) {
          if ((o as unknown as Record<string, unknown>)[k] !== v) {
            match = false;
            break;
          }
        }
        if (match) {
          Object.assign(o, partial);
          n++;
        }
      }
    }
    return { affected: n };
  }

  create(data: Partial<T>): T {
    return Object.assign(new this.entity(), data) as T;
  }

  async save(entity: T): Promise<T> {
    const obj = entity as unknown as { id?: string };
    if (obj instanceof Order) {
      if (!obj.id) obj.id = uuid();
      obj.updatedAt = new Date();
      this.ds.orders.set(obj.id, obj);
    }
    return entity;
  }
}

// ---------------------------------------------------------------------------
// Mock Redis — backed by JS sorted arrays + a Map for metadata.
// Faithfully simulates ZADD/ZRANGE/HMSET/HMGET/HDEL semantics.
// ---------------------------------------------------------------------------

class MockRedis {
  private sortedSets = new Map<string, Array<{ member: string; score: number }>>();
  private hashes = new Map<string, Record<string, string>>();
  private strings = new Map<string, string>();

  // Used by matching engine's lock helpers.
  async set(key: string, value: string, ...rest: unknown[]): Promise<'OK' | null> {
    // Recognize SET key value EX ttl NX form.
    const args = rest as string[];
    const isNx = args.includes('NX');
    if (isNx && this.strings.has(key)) return null;
    this.strings.set(key, value);
    return 'OK';
  }

  async get(key: string): Promise<string | null> {
    return this.strings.get(key) ?? null;
  }

  async del(...keys: string[]): Promise<number> {
    let n = 0;
    for (const k of keys) {
      if (this.strings.delete(k)) n++;
      if (this.sortedSets.delete(k)) n++;
      if (this.hashes.delete(k)) n++;
    }
    return n;
  }

  async incr(key: string): Promise<number> {
    const v = Number(this.strings.get(key) ?? '0') + 1;
    this.strings.set(key, String(v));
    return v;
  }

  async expire(_key: string, _ttl: number): Promise<number> {
    return 1;
  }

  async eval(_script: string, _numKeys: number, ..._args: unknown[]): Promise<unknown> {
    // We don't actually execute Lua — we recognize the script by which keys
    // it touches. For our tests, we care about the OUTCOMES (entries added
    // / removed / peeked) not the script semantics themselves.
    // Tests will use the higher-level OrderbookService methods which call
    // specific Lua scripts; here we just provide enough to not crash.
    return 1;
  }

  async zrange(key: string, start: number, stop: number, withScores?: string): Promise<string[]> {
    const set = this.sortedSets.get(key);
    if (!set) return [];
    const sorted = [...set].sort((a, b) => a.score - b.score);
    const startIdx = start < 0 ? sorted.length + start : start;
    const stopIdx = stop < 0 ? sorted.length + stop : stop;
    const slice = sorted.slice(startIdx, stopIdx + 1);
    if (withScores === 'WITHSCORES') {
      const out: string[] = [];
      for (const e of slice) {
        out.push(e.member);
        out.push(String(e.score));
      }
      return out;
    }
    return slice.map((e) => e.member);
  }

  async hmget(key: string, ...fields: string[]): Promise<(string | null)[]> {
    const h = this.hashes.get(key) ?? {};
    return fields.map((f) => h[f] ?? null);
  }

  async hmset(key: string, ...kv: string[]): Promise<'OK'> {
    const h = this.hashes.get(key) ?? {};
    for (let i = 0; i < kv.length; i += 2) {
      h[kv[i] as string] = kv[i + 1] as string;
    }
    this.hashes.set(key, h);
    return 'OK';
  }

  async hset(key: string, field: string, value: string): Promise<number> {
    const h = this.hashes.get(key) ?? {};
    const existed = field in h;
    h[field] = value;
    this.hashes.set(key, h);
    return existed ? 0 : 1;
  }

  async hdel(key: string, ...fields: string[]): Promise<number> {
    const h = this.hashes.get(key) ?? {};
    let n = 0;
    for (const f of fields) {
      if (delete h[f]) n++;
    }
    this.hashes.set(key, h);
    return n;
  }

  // ----- Test helpers (not part of the real Redis API) -----

  /** Directly inserts an entry into a sorted set, bypassing Lua. Used by
   *  tests to seed the book before invoking the matching engine. */
  _zadd(key: string, score: number, member: string): void {
    const set = this.sortedSets.get(key) ?? [];
    set.push({ member, score });
    this.sortedSets.set(key, set);
  }

  _hsetAll(key: string, fields: Record<string, string>): void {
    // MERGE with existing fields, not replace — the orderbook stores
    // metadata for ALL orders in a single hash keyed by orderId.
    const existing = this.hashes.get(key) ?? {};
    this.hashes.set(key, { ...existing, ...fields });
  }

  _zrem(key: string, member: string): boolean {
    const set = this.sortedSets.get(key);
    if (!set) return false;
    const idx = set.findIndex((e) => e.member === member);
    if (idx === -1) return false;
    set.splice(idx, 1);
    return true;
  }

  _zcard(key: string): number {
    return this.sortedSets.get(key)?.length ?? 0;
  }

  pipeline() {
    const self = this;
    const ops: Array<() => Promise<unknown>> = [];
    return {
      del(...keys: string[]) {
        ops.push(() => self.del(...keys));
        return this;
      },
      hmget(key: string, ...fields: string[]) {
        ops.push(() => self.hmget(key, ...fields));
        return this;
      },
      async exec(): Promise<Array<[Error | null, unknown]>> {
        const results: Array<[Error | null, unknown]> = [];
        for (const op of ops) {
          try {
            results.push([null, await op()]);
          } catch (err) {
            results.push([err as Error, null]);
          }
        }
        return results;
      },
    };
  }

  on(_event: string, _handler: (err: Error) => void): void {
    // No-op — tests don't need to listen for Redis errors.
  }
}

// ---------------------------------------------------------------------------
// TEST SUITE
// ---------------------------------------------------------------------------

describe('MatchingEngineService', () => {
  let service: MatchingEngineService;
  let orderbook: OrderbookService;
  let ds: MockDataSource;
  let mockRedis: MockRedis;
  let broadcaster: RealtimeBroadcaster;

  // Per-test user fixtures.
  let makerUser: TestUser;
  let takerUser: TestUser;

  beforeEach(async () => {
    ds = new MockDataSource();
    mockRedis = new MockRedis();

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        MatchingEngineService,
        OrderbookService,
        EscrowService,
        RealtimeBroadcaster,
        I18nService,
        { provide: DataSource, useValue: ds },
        { provide: getRepositoryToken(Order), useValue: new MockRepository(ds, Order) },
        { provide: getRepositoryToken(Trade), useValue: new MockRepository(ds, Trade) },
        { provide: getRepositoryToken(User), useValue: new MockRepository(ds, User) },
        { provide: getRepositoryToken(Wallet), useValue: new MockRepository(ds, Wallet) },
        { provide: getRepositoryToken(WalletTransaction), useValue: new MockRepository(ds, WalletTransaction) },
      ],
    }).compile();

    service = module.get(MatchingEngineService);
    orderbook = module.get(OrderbookService);
    broadcaster = module.get(RealtimeBroadcaster);

    // Inject the mock Redis client into the orderbook.
    orderbook.setClientForTesting(mockRedis as unknown as Redis);

    // Stub the broadcaster so emit* calls are no-ops.
    broadcaster.initForTesting();

    // Seed two verified users with funded USD wallets.
    makerUser = await seedUser(ds, 'maker@etb.et', '1000.00', WalletCurrency.USD);
    takerUser = await seedUser(ds, 'taker@etb.et', '0', WalletCurrency.USD);
  });

  // ==========================================================================
  // HELPER: seed a user with an active status + verified KYC + a funded wallet
  // ==========================================================================
  async function seedUser(
    ds: MockDataSource,
    email: string,
    balance: string,
    currency: WalletCurrency,
  ): Promise<TestUser> {
    const user = new User();
    user.id = uuid();
    user.email = email;
    user.phoneNumber = '+2519' + Math.floor(10000000 + Math.random() * 89999999);
    user.passwordHash = 'mock';
    user.fullName = email.split('@')[0];
    user.role = UserRole.USER;
    user.status = UserStatus.ACTIVE;
    user.is2faEnabled = false;
    user.kycStatus = KycStatus.VERIFIED;
    user.preferredLanguage = 'en';
    user.timezone = 'Africa/Addis_Ababa';
    user.failedLoginAttempts = 0;
    user.createdAt = new Date();
    user.updatedAt = new Date();
    ds.users.set(user.id, user);

    const wallet = new Wallet();
    wallet.id = uuid();
    wallet.userId = user.id;
    wallet.currency = currency;
    wallet.availableBalance = balance;
    wallet.lockedBalance = '0';
    wallet.pendingBalance = '0';
    wallet.createdAt = new Date();
    wallet.updatedAt = new Date();
    ds.wallets.set(wallet.id, wallet);

    return { user, wallet };
  }

  // ==========================================================================
  // HELPER: directly seed a resting maker into the orderbook + DB
  // ==========================================================================
  async function seedRestingMaker(
    user: TestUser,
    side: OrderSide,
    price: string,
    quantity: string,
    pair: string = 'USD_ETB',
  ): Promise<Order> {
    const order = new Order();
    order.id = uuid();
    order.userId = user.user.id;
    order.pair = pair;
    order.side = side;
    order.type = OrderType.LIMIT;
    order.price = price;
    order.quantity = quantity;
    order.filledQuantity = '0';
    order.remainingQuantity = quantity;
    order.status = OrderStatus.OPEN;
    order.paymentWindowMinutes = 30;
    order.isMaker = true;
    order.createdAt = new Date();
    order.updatedAt = new Date();
    ds.orders.set(order.id, order);

    // Also seed the Redis book so the matching engine can find it.
    // We bypass OrderbookService.addMakerOrder() to avoid the Lua script
    // path (which our MockRedis doesn't truly execute).
    const ts = order.createdAt.getTime();
    const score = side === OrderSide.SELL
      ? Number(price) * 1e8 + ts / 1000
      : -Number(price) * 1e8 + ts / 1000;

    const sellKey = pair === 'USD_ETB' ? 'etb:orderbook:sell:USD_ETB' : 'etb:orderbook:sell:USDT_ETB';
    const buyKey = pair === 'USD_ETB' ? 'etb:orderbook:buy:USD_ETB' : 'etb:orderbook:buy:USDT_ETB';
    const metaKey = pair === 'USD_ETB' ? 'etb:orderbook:meta:USD_ETB' : 'etb:orderbook:meta:USDT_ETB';

    mockRedis._zadd(side === OrderSide.SELL ? sellKey : buyKey, score, order.id);
    mockRedis._hsetAll(metaKey, {
      [`${order.id}:price`]: price,
      [`${order.id}:qty`]: quantity,
      [`${order.id}:user`]: user.user.id,
      [`${order.id}:ts`]: String(ts),
    });

    return order;
  }

  // ==========================================================================
  // HELPER: monkey-patch OrderbookService methods that depend on Lua scripts.
  // The mock Redis can't run Lua, so we reimplement the methods directly
  // on top of the mock's zrange/hmget primitives.
  // ==========================================================================
  beforeEach(() => {
    // Override peekMatchableMakers to walk the book manually.
    (orderbook as unknown as { peekMatchableMakers: unknown }).peekMatchableMakers =
      async (
        pair: 'USD_ETB' | 'USDT_ETB',
        takerSide: OrderSide,
        takerPrice: string,
        maxResults: number,
      ): Promise<OrderbookEntry[]> => {
        const bookKey = takerSide === OrderSide.BUY
          ? `etb:orderbook:sell:${pair}`
          : `etb:orderbook:buy:${pair}`;
        const metaKey = `etb:orderbook:meta:${pair}`;
        const members = await mockRedis.zrange(bookKey, 0, maxResults - 1, 'WITHSCORES');
        const entries: OrderbookEntry[] = [];
        for (let i = 0; i < members.length; i += 2) {
          const orderId = members[i];
          if (!orderId) continue;
          const meta = await mockRedis.hmget(
            metaKey,
            `${orderId}:price`,
            `${orderId}:qty`,
            `${orderId}:user`,
            `${orderId}:ts`,
          );
          if (!meta[0] || !meta[1] || !meta[2] || !meta[3]) continue;
          const makerPrice = Number(meta[0]);
          const takerP = Number(takerPrice);
          const crosses = takerSide === OrderSide.BUY
            ? makerPrice <= takerP
            : makerPrice >= takerP;
          if (!crosses) break;
          entries.push({
            orderId,
            userId: meta[2] as string,
            pair,
            side: takerSide === OrderSide.BUY ? OrderSide.SELL : OrderSide.BUY,
            price: meta[0] as string,
            quantity: meta[1] as string,
            createdAt: Number(meta[3]),
          });
        }
        return entries;
      };

    (orderbook as unknown as { removeMakerOrder: unknown }).removeMakerOrder =
      async (pair: 'USD_ETB' | 'USDT_ETB', side: OrderSide, orderId: string): Promise<boolean> => {
        const bookKey = side === OrderSide.SELL
          ? `etb:orderbook:sell:${pair}`
          : `etb:orderbook:buy:${pair}`;
        const metaKey = `etb:orderbook:meta:${pair}`;
        const removed = mockRedis._zrem(bookKey, orderId);
        await mockRedis.hdel(
          metaKey,
          `${orderId}:price`,
          `${orderId}:qty`,
          `${orderId}:user`,
          `${orderId}:ts`,
        );
        return removed;
      };

    (orderbook as unknown as { updateRemainingQuantity: unknown }).updateRemainingQuantity =
      async (pair: 'USD_ETB' | 'USDT_ETB', orderId: string, newQty: string): Promise<void> => {
        await mockRedis.hset(`etb:orderbook:meta:${pair}`, `${orderId}:qty`, newQty);
      };

    (orderbook as unknown as { addMakerOrder: unknown }).addMakerOrder =
      async (entry: OrderbookEntry): Promise<void> => {
        const bookKey = entry.side === OrderSide.SELL
          ? `etb:orderbook:sell:${entry.pair}`
          : `etb:orderbook:buy:${entry.pair}`;
        const metaKey = `etb:orderbook:meta:${entry.pair}`;
        const ts = entry.createdAt;
        const score = entry.side === OrderSide.SELL
          ? Number(entry.price) * 1e8 + ts / 1000
          : -Number(entry.price) * 1e8 + ts / 1000;
        mockRedis._zadd(bookKey, score, entry.orderId);
        await mockRedis.hmset(
          metaKey,
          `${entry.orderId}:price`, entry.price,
          `${entry.orderId}:qty`, entry.quantity,
          `${entry.orderId}:user`, entry.userId,
          `${entry.orderId}:ts`, String(ts),
        );
      };

    (orderbook as unknown as { getClient: unknown }).getClient = () => mockRedis as unknown as Redis;
  });

  // ==========================================================================
  // TEST 1: A simple full match — taker BUY fully consumes maker SELL.
  // ==========================================================================
  it('fully matches a BUY taker against a single SELL maker at the same price', async () => {
    // Seed: maker sells 100 USD @ 120 ETB
    await seedRestingMaker(makerUser, OrderSide.SELL, '120', '100');

    const result = await service.placeOrder({
      userId: takerUser.user.id,
      pair: 'USD_ETB',
      side: OrderSide.BUY,
      type: OrderType.LIMIT,
      price: '120',
      quantity: '100',
      paymentWindowMinutes: 30,
    });

    expect(result.status).toBe(OrderStatus.FILLED);
    expect(result.filledQuantity).toBe('100');
    expect(result.remainingQuantity).toBe('0');
    expect(result.trades).toHaveLength(1);

    const trade = result.trades[0]!;
    expect(trade.price).toBe('120');
    expect(trade.quantity).toBe('100');
    expect(trade.totalValue).toBe('12000');

    // Trade row in DB should be ESCROWED.
    const tradeRow = ds.trades.get(trade.tradeId);
    expect(tradeRow?.status).toBe(TradeStatus.ESCROWED);
    expect(tradeRow?.cryptoLockedAmount).toBe('100');

    // Maker's wallet: 1000 → 900 available, 0 → 100 locked.
    const makerWallet = ds.wallets.get(makerUser.wallet.id)!;
    expect(makerWallet.availableBalance).toBe('900');
    expect(makerWallet.lockedBalance).toBe('100');

    // Orderbook should now be empty (maker fully consumed).
    expect(mockRedis._zcard('etb:orderbook:sell:USD_ETB')).toBe(0);
  });

  // ==========================================================================
  // TEST 2: Partial fill — taker BUY 60 USD when maker is selling 100 USD.
  //         Taker fully filled; maker has 40 USD remaining on the book.
  // ==========================================================================
  it('partially fills a maker when the taker quantity is smaller', async () => {
    await seedRestingMaker(makerUser, OrderSide.SELL, '120', '100');

    const result = await service.placeOrder({
      userId: takerUser.user.id,
      pair: 'USD_ETB',
      side: OrderSide.BUY,
      type: OrderType.LIMIT,
      price: '120',
      quantity: '60',
      paymentWindowMinutes: 30,
    });

    expect(result.status).toBe(OrderStatus.FILLED);
    expect(result.filledQuantity).toBe('60');
    expect(result.trades).toHaveLength(1);
    expect(result.trades[0]!.quantity).toBe('60');

    // Maker's wallet: 1000 → 940 available, 0 → 60 locked.
    const makerWallet = ds.wallets.get(makerUser.wallet.id)!;
    expect(makerWallet.availableBalance).toBe('940');
    expect(makerWallet.lockedBalance).toBe('60');

    // Maker's order should be PARTIALLY_FILLED.
    const makerOrder = ds.orders.get(result.trades[0]!.makerOrderId)!;
    expect(makerOrder.status).toBe(OrderStatus.PARTIALLY_FILLED);
    expect(makerOrder.filledQuantity).toBe('60');

    // Book should still have 40 USD at 120 ETB.
    expect(mockRedis._zcard('etb:orderbook:sell:USD_ETB')).toBe(1);
    const meta = await mockRedis.hmget(
      'etb:orderbook:meta:USD_ETB',
      `${makerOrder.id}:qty`,
    );
    expect(meta[0]).toBe('40');
  });

  // ==========================================================================
  // TEST 3: Multiple matches — taker BUY 200 against two makers (100 @ 119 + 100 @ 120).
  //         Trade 1: 100 @ 119 = 11,900 ETB. Trade 2: 100 @ 120 = 12,000 ETB.
  // ==========================================================================
  it('matches a single taker against multiple makers in price-time priority', async () => {
    // Maker A: 100 USD @ 120 ETB (older)
    const makerA = await seedRestingMaker(makerUser, OrderSide.SELL, '120', '100');

    // Maker B: another user, 100 USD @ 119 ETB (newer, but BETTER price)
    const makerBUser = await seedUser(ds, 'makerb@etb.et', '500', WalletCurrency.USD);
    const makerB = await seedRestingMaker(makerBUser, OrderSide.SELL, '119', '100');

    const result = await service.placeOrder({
      userId: takerUser.user.id,
      pair: 'USD_ETB',
      side: OrderSide.BUY,
      type: OrderType.LIMIT,
      price: '120', // willing to pay up to 120 — should match BOTH makers
      quantity: '200',
      paymentWindowMinutes: 30,
    });

    expect(result.status).toBe(OrderStatus.FILLED);
    expect(result.filledQuantity).toBe('200');
    expect(result.trades).toHaveLength(2);

    // The FIRST trade should be at the BETTER price (119), not the older 120.
    expect(result.trades[0]!.price).toBe('119');
    expect(result.trades[0]!.quantity).toBe('100');
    expect(result.trades[0]!.makerOrderId).toBe(makerB.id);

    // The SECOND trade at the older maker's price (120).
    expect(result.trades[1]!.price).toBe('120');
    expect(result.trades[1]!.makerOrderId).toBe(makerA.id);

    // Both makers' orders should be FILLED.
    expect(ds.orders.get(makerA.id)?.status).toBe(OrderStatus.FILLED);
    expect(ds.orders.get(makerB.id)?.status).toBe(OrderStatus.FILLED);

    // Book should be empty.
    expect(mockRedis._zcard('etb:orderbook:sell:USD_ETB')).toBe(0);
  });

  // ==========================================================================
  // TEST 4: No match — taker BUY @ 100 when best ask is 120. Order should
  //         rest on the book as a maker.
  // ==========================================================================
  it('rests a non-crossing LIMIT order on the book as a maker', async () => {
    await seedRestingMaker(makerUser, OrderSide.SELL, '120', '100');

    const result = await service.placeOrder({
      userId: takerUser.user.id,
      pair: 'USD_ETB',
      side: OrderSide.BUY,
      type: OrderType.LIMIT,
      price: '100', // below the 120 ask — no cross
      quantity: '50',
      paymentWindowMinutes: 30,
    });

    expect(result.status).toBe(OrderStatus.OPEN);
    expect(result.filledQuantity).toBe('0');
    expect(result.remainingQuantity).toBe('50');
    expect(result.trades).toHaveLength(0);

    // Book should now have BOTH the original SELL @ 120 and the new BUY @ 100.
    expect(mockRedis._zcard('etb:orderbook:sell:USD_ETB')).toBe(1);
    expect(mockRedis._zcard('etb:orderbook:buy:USD_ETB')).toBe(1);
  });

  // ==========================================================================
  // TEST 5: Self-match prevention — taker cannot match against their own maker.
  // ==========================================================================
  it('skips a maker order belonging to the taker themselves (self-match prevention)', async () => {
    // The maker is the SAME user as the taker.
    await seedRestingMaker(makerUser, OrderSide.SELL, '120', '100');

    const result = await service.placeOrder({
      userId: makerUser.user.id, // same user!
      pair: 'USD_ETB',
      side: OrderSide.BUY,
      type: OrderType.LIMIT,
      price: '120',
      quantity: '50',
      paymentWindowMinutes: 30,
    });

    // The self-match should be SKIPPED. The 50 USD becomes a resting BUY.
    expect(result.status).toBe(OrderStatus.OPEN);
    expect(result.filledQuantity).toBe('0');
    expect(result.trades).toHaveLength(0);

    // Book should now have the original SELL @ 120 AND the new BUY @ 120.
    expect(mockRedis._zcard('etb:orderbook:sell:USD_ETB')).toBe(1);
    expect(mockRedis._zcard('etb:orderbook:buy:USD_ETB')).toBe(1);
  });

  // ==========================================================================
  // TEST 6: Insufficient balance — maker doesn't have enough USD to sell.
  //         The matching engine should skip the maker and move on.
  // ==========================================================================
  it('skips a maker whose wallet has insufficient balance', async () => {
    // Maker with only 10 USD trying to sell 100 USD.
    const poorMaker = await seedUser(ds, 'poor@etb.et', '10', WalletCurrency.USD);
    await seedRestingMaker(poorMaker, OrderSide.SELL, '120', '100');

    // Rich maker right behind them.
    await seedRestingMaker(makerUser, OrderSide.SELL, '121', '50');

    const result = await service.placeOrder({
      userId: takerUser.user.id,
      pair: 'USD_ETB',
      side: OrderSide.BUY,
      type: OrderType.LIMIT,
      price: '125', // crosses both
      quantity: '50',
      paymentWindowMinutes: 30,
    });

    // The poor maker's escrow should FAIL → engine skips it and matches the rich one.
    expect(result.filledQuantity).toBe('50');
    expect(result.trades).toHaveLength(1);
    expect(result.trades[0]!.makerOrderId).not.toBe(poorMaker.user.id);

    // The poor maker's order should remain OPEN (escrow failed, no state change).
    // Its entry in Redis MAY have been left in place — the engine doesn't clean
    // up failed-escrow entries automatically (a future reconciliation job does).
    // For this test we only assert the happy-path maker was matched.
    expect(result.trades[0]!.price).toBe('121');
  });

  // ==========================================================================
  // TEST 7: Business-rule validation — order below minimum trade value.
  // ==========================================================================
  it('rejects an order whose value is below the minimum', async () => {
    // Original process.env carries MIN_ORDER_VALUE_ETB; if undefined, the
    // matching engine defaults it from env validation. We test that the
    // BusinessException surfaces with the right error code.
    // Force a low min via process.env stub.
    const original = process.env.MIN_ORDER_VALUE_ETB;
    process.env.MIN_ORDER_VALUE_ETB = '50000';
    _resetEnvCacheForTesting();

    try {
      await expect(
        service.placeOrder({
          userId: takerUser.user.id,
          pair: 'USD_ETB',
          side: OrderSide.BUY,
          type: OrderType.LIMIT,
          price: '120',
          quantity: '1', // 1 USD * 120 ETB = 120 ETB << 50000 min
          paymentWindowMinutes: 30,
        }),
      ).rejects.toMatchObject({
        errorCode: ErrorCode.ORDER_BELOW_MIN_VALUE,
      });
    } finally {
      process.env.MIN_ORDER_VALUE_ETB = original;
      _resetEnvCacheForTesting();
    }
  });

  // ==========================================================================
  // TEST 8: Business-rule validation — invalid pair.
  // ==========================================================================
  it('rejects an order with an unsupported pair', async () => {
    await expect(
      service.placeOrder({
        userId: takerUser.user.id,
        pair: 'EUR_USD', // not supported
        side: OrderSide.BUY,
        type: OrderType.LIMIT,
        price: '120',
        quantity: '100',
        paymentWindowMinutes: 30,
      }),
    ).rejects.toMatchObject({
      errorCode: ErrorCode.INVALID_PAIR,
    });
  });

  // ==========================================================================
  // TEST 9: Business-rule validation — KYC not verified.
  // ==========================================================================
  it('rejects an order from a user whose KYC is not verified', async () => {
    // Demote the taker's KYC status.
    takerUser.user.kycStatus = KycStatus.PENDING;
    ds.users.set(takerUser.user.id, takerUser.user);

    await expect(
      service.placeOrder({
        userId: takerUser.user.id,
        pair: 'USD_ETB',
        side: OrderSide.BUY,
        type: OrderType.LIMIT,
        price: '120',
        quantity: '100',
        paymentWindowMinutes: 30,
      }),
    ).rejects.toMatchObject({
      errorCode: ErrorCode.KYC_NOT_VERIFIED,
    });
  });

  // ==========================================================================
  // TEST 10: Cancel order — happy path.
  // ==========================================================================
  it('cancels an OPEN order and removes it from the book', async () => {
    // Place a non-crossing order so it rests on the book.
    const placeResult = await service.placeOrder({
      userId: takerUser.user.id,
      pair: 'USD_ETB',
      side: OrderSide.BUY,
      type: OrderType.LIMIT,
      price: '100',
      quantity: '50',
      paymentWindowMinutes: 30,
    });
    expect(placeResult.status).toBe(OrderStatus.OPEN);
    expect(mockRedis._zcard('etb:orderbook:buy:USD_ETB')).toBe(1);

    const cancelResult = await service.cancelOrder({
      userId: takerUser.user.id,
      orderId: placeResult.takerOrderId,
    });

    expect(cancelResult.orderId).toBe(placeResult.takerOrderId);

    // Order should be CANCELLED in DB.
    const order = ds.orders.get(placeResult.takerOrderId)!;
    expect(order.status).toBe(OrderStatus.CANCELLED);

    // Orderbook should be empty.
    expect(mockRedis._zcard('etb:orderbook:buy:USD_ETB')).toBe(0);
  });

  // ==========================================================================
  // TEST 11: Cancel order — wrong user (forbidden).
  // ==========================================================================
  it('forbids cancelling another user\'s order', async () => {
    const placeResult = await service.placeOrder({
      userId: takerUser.user.id,
      pair: 'USD_ETB',
      side: OrderSide.BUY,
      type: OrderType.LIMIT,
      price: '100',
      quantity: '50',
      paymentWindowMinutes: 30,
    });

    await expect(
      service.cancelOrder({
        userId: makerUser.user.id, // different user!
        orderId: placeResult.takerOrderId,
      }),
    ).rejects.toMatchObject({
      errorCode: ErrorCode.FORBIDDEN,
    });
  });

  // ==========================================================================
  // TEST 12: Cancel order — already FILLED (not cancellable).
  // ==========================================================================
  it('refuses to cancel an already-FILLED order', async () => {
    await seedRestingMaker(makerUser, OrderSide.SELL, '120', '100');

    const placeResult = await service.placeOrder({
      userId: takerUser.user.id,
      pair: 'USD_ETB',
      side: OrderSide.BUY,
      type: OrderType.LIMIT,
      price: '120',
      quantity: '100',
      paymentWindowMinutes: 30,
    });
    expect(placeResult.status).toBe(OrderStatus.FILLED);

    await expect(
      service.cancelOrder({
        userId: takerUser.user.id,
        orderId: placeResult.takerOrderId,
      }),
    ).rejects.toMatchObject({
      errorCode: ErrorCode.ORDER_NOT_CANCELLABLE,
    });
  });

  // ==========================================================================
  // TEST 13: Financial invariant — wallet (available + locked) never decreases
  //          beyond the original balance (no double-spend across multiple matches).
  // ==========================================================================
  it('preserves the (available + locked) wallet invariant across multiple matches', async () => {
    // Maker with 100 USD, listing THREE resting orders of 50 USD each at
    // progressively higher prices. A taker BUY 100 should match the two
    // cheapest (since the maker has 100 available).
    await seedRestingMaker(makerUser, OrderSide.SELL, '120', '50');
    await seedRestingMaker(makerUser, OrderSide.SELL, '121', '50');
    await seedRestingMaker(makerUser, OrderSide.SELL, '122', '50');

    const result = await service.placeOrder({
      userId: takerUser.user.id,
      pair: 'USD_ETB',
      side: OrderSide.BUY,
      type: OrderType.LIMIT,
      price: '125',
      quantity: '100',
      paymentWindowMinutes: 30,
    });

    expect(result.filledQuantity).toBe('100');
    expect(result.trades).toHaveLength(2);

    // Maker's wallet: 1000 → 900 available + 100 locked. Net = 1000. NO DOUBLE-SPEND.
    const makerWallet = ds.wallets.get(makerUser.wallet.id)!;
    const available = BigInt(makerWallet.availableBalance);
    const locked = BigInt(makerWallet.lockedBalance);
    expect(available + locked).toBe(BigInt('1000'));

    // The third maker order should remain OPEN (no funds left).
    const thirdOrder = [...ds.orders.values()]
      .filter((o) => o.userId === makerUser.user.id && o.price === '122')
      .pop();
    expect(thirdOrder?.status).toBe(OrderStatus.OPEN);
  });

  // ==========================================================================
  // TEST 14: Financial invariant — escrow lock fails cleanly if the maker's
  //          wallet has been drained by a parallel trade.
  // ==========================================================================
  it('rolls back cleanly when escrow lock fails mid-match', async () => {
    // Maker has only 30 USD but is offering to sell 100 USD.
    const poorMaker = await seedUser(ds, 'poor@etb.et', '30', WalletCurrency.USD);
    await seedRestingMaker(poorMaker, OrderSide.SELL, '120', '100');

    // Taker BUY 100 @ 125 — engine tries to lock 100 USD but maker only has 30.
    const result = await service.placeOrder({
      userId: takerUser.user.id,
      pair: 'USD_ETB',
      side: OrderSide.BUY,
      type: OrderType.LIMIT,
      price: '125',
      quantity: '100',
      paymentWindowMinutes: 30,
    });

    // No trades should have been recorded — the escrow failed, and the engine
    // skipped this maker rather than leaving a half-baked state.
    expect(result.trades).toHaveLength(0);

    // The taker's 100 USD order should rest on the book (no fill happened).
    expect(result.status).toBe(OrderStatus.OPEN);

    // The poor maker's wallet should be untouched (30 available, 0 locked).
    const poorWallet = ds.wallets.get(poorMaker.wallet.id)!;
    expect(poorWallet.availableBalance).toBe('30');
    expect(poorWallet.lockedBalance).toBe('0');

    // And no Trade rows should exist in the DB.
    expect(ds.trades.size).toBe(0);
  });

  // ==========================================================================
  // TEST 15: Decimal arithmetic — high-precision quantities don't drift.
  // ==========================================================================
  it('preserves precision when matching fractional quantities', async () => {
    // Override the minimum order value so the small fractional trade is allowed.
    const originalMin = process.env.MIN_ORDER_VALUE_ETB;
    process.env.MIN_ORDER_VALUE_ETB = '0';
    _resetEnvCacheForTesting();

    try {
      await seedRestingMaker(makerUser, OrderSide.SELL, '119.50', '0.12345678');

      const result = await service.placeOrder({
        userId: takerUser.user.id,
        pair: 'USD_ETB',
        side: OrderSide.BUY,
        type: OrderType.LIMIT,
        price: '120',
        quantity: '0.12345678',
        paymentWindowMinutes: 30,
      });

      expect(result.filledQuantity).toBe('0.12345678');
      expect(result.trades[0]!.price).toBe('119.50');
      expect(result.trades[0]!.quantity).toBe('0.12345678');
      // total_value = 0.12345678 × 119.50 = 14.7530852100
      expect(result.trades[0]!.totalValue).toBe('14.75308521');
    } finally {
      process.env.MIN_ORDER_VALUE_ETB = originalMin;
      _resetEnvCacheForTesting();
    }
  });

  // ==========================================================================
  // TEST 16: Order lifecycle — verify the trade state machine reaches ESCROWED.
  // ==========================================================================
  it('transitions the trade to ESCROWED state on a successful match', async () => {
    await seedRestingMaker(makerUser, OrderSide.SELL, '120', '100');

    const result = await service.placeOrder({
      userId: takerUser.user.id,
      pair: 'USD_ETB',
      side: OrderSide.BUY,
      type: OrderType.LIMIT,
      price: '120',
      quantity: '100',
      paymentWindowMinutes: 30,
    });

    const trade = ds.trades.get(result.trades[0]!.tradeId)!;
    expect(trade.status).toBe(TradeStatus.ESCROWED);
    expect(trade.paymentWindowExpiresAt.getTime()).toBeGreaterThan(Date.now());
    expect(trade.paymentWindowExpiresAt.getTime()).toBeLessThan(Date.now() + 31 * 60_000);
    expect(trade.makerUserId).toBe(makerUser.user.id);
    expect(trade.takerUserId).toBe(takerUser.user.id);
    expect(trade.side).toBe(OrderSide.BUY); // taker's side
  });
});
