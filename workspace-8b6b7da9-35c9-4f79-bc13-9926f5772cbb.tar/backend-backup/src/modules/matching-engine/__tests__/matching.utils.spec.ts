import {
  computeOrderScore,
  pricesCross,
  executionPrice,
  subtractDecimal,
  addDecimal,
  multiplyDecimal,
  lessThan,
  formatTradeNumber,
  isValidPair,
} from '../../../utils/matching.utils';
import { OrderSide } from '../../../database/entities';

describe('matching.utils', () => {
  // ==========================================================================
  // computeOrderScore
  // ==========================================================================
  describe('computeOrderScore', () => {
    it('scores SELL orders ASC by price (cheapest first)', () => {
      const ts = 1_700_000_000_000;
      const cheap = computeOrderScore(OrderSide.SELL, '100', ts);
      const expensive = computeOrderScore(OrderSide.SELL, '101', ts);
      expect(cheap).toBeLessThan(expensive);
    });

    it('scores BUY orders DESC by price (highest bidder first)', () => {
      const ts = 1_700_000_000_000;
      const high = computeOrderScore(OrderSide.BUY, '101', ts);
      const low = computeOrderScore(OrderSide.BUY, '100', ts);
      expect(high).toBeLessThan(low); // smaller score = earlier in the sorted set
    });

    it('breaks ties by FIFO (earlier createdAt wins)', () => {
      const earlier = computeOrderScore(OrderSide.SELL, '100', 1_700_000_000_000);
      const later = computeOrderScore(OrderSide.SELL, '100', 1_700_000_001_000);
      expect(earlier).toBeLessThan(later);
    });

    it('throws on non-positive prices', () => {
      expect(() => computeOrderScore(OrderSide.SELL, '0', 1)).toThrow();
      expect(() => computeOrderScore(OrderSide.SELL, '-5', 1)).toThrow();
      expect(() => computeOrderScore(OrderSide.BUY, 'NaN', 1)).toThrow();
    });

    it('preserves 8-decimal precision (no float drift)', () => {
      const ts = 1_700_000_000_000;
      const a = computeOrderScore(OrderSide.SELL, '100.12345678', ts);
      const b = computeOrderScore(OrderSide.SELL, '100.12345679', ts);
      expect(a).toBeLessThan(b);
      // Difference should be exactly 1 * 1e8 / 1e8 = 1 (in scaled units).
      // We just assert ordering, not exact value, to stay implementation-agnostic.
    });
  });

  // ==========================================================================
  // pricesCross
  // ==========================================================================
  describe('pricesCross', () => {
    it('BUY crosses SELL when taker price >= maker price', () => {
      expect(pricesCross(OrderSide.BUY, '120', '120')).toBe(true);
      expect(pricesCross(OrderSide.BUY, '125', '120')).toBe(true);
      expect(pricesCross(OrderSide.BUY, '119', '120')).toBe(false);
    });

    it('SELL crosses BUY when taker price <= maker price', () => {
      expect(pricesCross(OrderSide.SELL, '120', '120')).toBe(true);
      expect(pricesCross(OrderSide.SELL, '115', '120')).toBe(true);
      expect(pricesCross(OrderSide.SELL, '125', '120')).toBe(false);
    });

    it('handles NaN gracefully (no cross)', () => {
      expect(pricesCross(OrderSide.BUY, 'NaN', '120')).toBe(false);
      expect(pricesCross(OrderSide.SELL, '120', 'undefined')).toBe(false);
    });
  });

  // ==========================================================================
  // executionPrice
  // ==========================================================================
  describe('executionPrice', () => {
    it('returns the maker price (price-time priority convention)', () => {
      expect(executionPrice('120')).toBe('120');
      expect(executionPrice('119.50')).toBe('119.50');
    });

    it('throws on invalid maker prices', () => {
      expect(() => executionPrice('0')).toThrow();
      expect(() => executionPrice('-1')).toThrow();
    });
  });

  // ==========================================================================
  // subtractDecimal / addDecimal
  // ==========================================================================
  describe('subtractDecimal', () => {
    it('subtracts two positive decimals without float drift', () => {
      expect(subtractDecimal('100', '30')).toBe('70');
      expect(subtractDecimal('100.5', '0.5')).toBe('100');
      expect(subtractDecimal('1000.00000001', '0.00000001')).toBe('1000');
      expect(subtractDecimal('0.12345678', '0.12345678')).toBe('0');
    });

    it('handles different scales', () => {
      expect(subtractDecimal('100', '0.5')).toBe('99.5');
      expect(subtractDecimal('0.5', '100')).toBe('-99.5');
    });

    it('handles large numbers', () => {
      expect(subtractDecimal('9999999999999999', '1')).toBe('9999999999999998');
    });
  });

  describe('addDecimal', () => {
    it('adds two positive decimals', () => {
      expect(addDecimal('100', '30')).toBe('130');
      expect(addDecimal('0.5', '0.5')).toBe('1');
      expect(addDecimal('99.99999999', '0.00000001')).toBe('100');
    });

    it('handles negative operands', () => {
      expect(addDecimal('100', '-30')).toBe('70');
      expect(addDecimal('-50', '-30')).toBe('-80');
    });
  });

  // ==========================================================================
  // multiplyDecimal
  // ==========================================================================
  describe('multiplyDecimal', () => {
    it('multiplies without float drift', () => {
      expect(multiplyDecimal('100', '120')).toBe('12000');
      // 0.12345678 × 119.50 = 14.7530852100 (verified via Python)
      expect(multiplyDecimal('0.12345678', '119.50')).toBe('14.75308521');
      expect(multiplyDecimal('1.1', '1.1')).toBe('1.21');
    });

    it('handles zero', () => {
      expect(multiplyDecimal('0', '120')).toBe('0');
      expect(multiplyDecimal('120', '0')).toBe('0');
    });

    it('handles large precision', () => {
      // 0.00000001 * 0.00000001 = 0.0000000000000001
      expect(multiplyDecimal('0.00000001', '0.00000001')).toBe('0.0000000000000001');
    });
  });

  // ==========================================================================
  // lessThan
  // ==========================================================================
  describe('lessThan', () => {
    it('compares decimals correctly', () => {
      expect(lessThan('1', '2')).toBe(true);
      expect(lessThan('2', '1')).toBe(false);
      expect(lessThan('1', '1')).toBe(false);
      expect(lessThan('0.12345678', '0.12345679')).toBe(true);
      expect(lessThan('100', '99.99999999')).toBe(false);
    });

    it('handles negatives', () => {
      expect(lessThan('-1', '1')).toBe(true);
      expect(lessThan('-1', '0')).toBe(true);
      expect(lessThan('1', '-1')).toBe(false);
    });
  });

  // ==========================================================================
  // formatTradeNumber
  // ==========================================================================
  describe('formatTradeNumber', () => {
    it('formats as TRD-YYYYMMDD-XXXXX with zero-padded sequence', () => {
      const date = new Date('2026-06-25T10:00:00Z');
      expect(formatTradeNumber(date, 1)).toBe('TRD-20260625-00001');
      expect(formatTradeNumber(date, 42)).toBe('TRD-20260625-00042');
      expect(formatTradeNumber(date, 99999)).toBe('TRD-20260625-99999');
      expect(formatTradeNumber(date, 100000)).toBe('TRD-20260625-100000');
    });
  });

  // ==========================================================================
  // isValidPair
  // ==========================================================================
  describe('isValidPair', () => {
    it('accepts the two supported pairs', () => {
      expect(isValidPair('USD_ETB')).toBe(true);
      expect(isValidPair('USDT_ETB')).toBe(true);
    });
    it('rejects unsupported pairs', () => {
      expect(isValidPair('EUR_USD')).toBe(false);
      expect(isValidPair('')).toBe(false);
      expect(isValidPair('USD_ETB_ETB')).toBe(false);
    });
  });
});
