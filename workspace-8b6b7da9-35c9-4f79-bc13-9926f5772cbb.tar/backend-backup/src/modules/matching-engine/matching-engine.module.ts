import { Module } from '@nestjs/common';
import { MatchingEngineController } from './matching-engine.controller';
import { MatchingEngineService } from './matching-engine.service';
import { OrderbookModule } from '../orderbook/orderbook.module';
import { EscrowModule } from '../escrow/escrow.module';
import { WebSocketModule } from '../websocket/websocket.module';
import { I18nModule } from '../i18n/i18n.module';
import { AuthModule } from '../auth/auth.module';

@Module({
  imports: [OrderbookModule, EscrowModule, WebSocketModule, I18nModule, AuthModule],
  controllers: [MatchingEngineController],
  providers: [MatchingEngineService],
  exports: [MatchingEngineService],
})
export class MatchingEngineModule {}
