import {
  IsEnum,
  IsNumber,
  IsOptional,
  IsString,
  IsUUID,
  Max,
  Min,
  Matches,
  ValidateIf,
} from 'class-validator';
import { Type } from 'class-transformer';
import { OrderSide, OrderType } from '../../../database/entities';

/**
 * PlaceOrderDto — payload for POST /v1/orders.
 *
 * Strict validation lives here so we never reach the matching engine with
 * invalid input. Every field below is enforced before the controller hands
 * off to MatchingEngineService.
 */
export class PlaceOrderDto {
  @IsString()
  @Matches(/^(USD_ETB|USDT_ETB)$/, {
    message: 'pair must be USD_ETB or USDT_ETB',
  })
  pair: string;

  @IsEnum(OrderSide)
  side: OrderSide;

  @IsEnum(OrderType)
  @IsOptional()
  type?: OrderType;

  /**
   * Price in ETB per 1 unit of base currency.
   * Required for LIMIT orders; ignored for MARKET orders.
   * 8 decimal places max, > 0.
   */
  @IsString()
  @Matches(/^\d+(\.\d{1,8})?$/, { message: 'price must be a positive decimal with up to 8 fractional digits' })
  @ValidateIf((o: PlaceOrderDto) => o.type !== OrderType.MARKET)
  price: string;

  /**
   * Quantity of BASE currency (USD or USDT) to buy/sell.
   * Must be > 0 with up to 8 decimals.
   */
  @IsString()
  @Matches(/^\d+(\.\d{1,8})?$/, { message: 'quantity must be a positive decimal with up to 8 fractional digits' })
  quantity: string;

  /**
   * Optional payment method to use for this trade. If omitted, the matching
   * engine will use the user's default verified payment method.
   */
  @IsUUID('4')
  @IsOptional()
  paymentMethodId?: string;

  /**
   * Payment window in minutes. Defaults to 30 (env.DEFAULT_PAYMENT_WINDOW_MINUTES).
   * Min 5 min, max 1440 min (24h).
   */
  @Type(() => Number)
  @IsNumber()
  @Min(5)
  @Max(1440)
  @IsOptional()
  paymentWindowMinutes?: number;

  /**
   * Minimum trade value in ETB. If a maker order specifies this, the matching
   * engine will skip taker quantities that fall below it.
   */
  @IsString()
  @Matches(/^\d+(\.\d{1,8})?$/)
  @IsOptional()
  minOrderValue?: string;

  @IsString()
  @Matches(/^\d+(\.\d{1,8})?$/)
  @IsOptional()
  maxOrderValue?: string;

  @IsString()
  @IsOptional()
  terms?: string;
}

export class CancelOrderDto {
  @IsUUID('4')
  orderId: string;
}

export interface PlaceOrderResponse {
  orderId: string;
  status: string;
  filledQuantity: string;
  remainingQuantity: string;
  trades: ReadonlyArray<{
    tradeId: string;
    tradeNumber: string;
    price: string;
    quantity: string;
    totalValue: string;
    paymentWindowExpiresAt: string;
  }>;
}
