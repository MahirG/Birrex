import {
  WebSocketGateway,
  WebSocketServer,
  OnGatewayConnection,
  OnGatewayDisconnect,
  OnGatewayInit,
  SubscribeMessage,
  MessageBody,
  ConnectedSocket,
} from '@nestjs/websockets';
import { Logger } from '@nestjs/common';
import { Server, Socket } from 'socket.io';
import { createAdapter } from '@socket.io/redis-adapter';
import Redis from 'ioredis';
import { buildRedisConfig } from '../../config';
import { RealtimeBroadcaster } from './realtime.broadcaster';
import type { WsEventEnvelope, RoomName } from '../../types/ws-events.types';
import { BusinessException, ErrorCode } from '../../common/exceptions/business.exception';

/**
 * WebSocketGateway — Socket.io server with Redis adapter for multi-instance sync.
 *
 * Connection lifecycle:
 *   1. Client connects with JWT in handshake.auth.token (or query for browsers).
 *   2. We verify the token (lightweight — full auth is in the Auth module).
 *   3. On success, we auto-join the user's personal room `user:<id>` so the
 *      broadcaster can fan out private events.
 *   4. Client may then subscribe to public rooms like `pair:USD_ETB`.
 *
 * Scaling:
 *   The @socket.io/redis-adapter replicates room membership across all NestJS
 *   instances. When `broadcaster.emitToRoom('pair:USD_ETB', ...)` runs on
 *   instance A, the adapter forwards it to instances B/C/.../N which deliver
 *   it to THEIR locally-connected sockets subscribed to that room.
 *
 * Security:
 *   - Per-event rate limiting via a sliding window in Redis (TODO in Phase 2).
 *   - All input is validated with class-validator on the gateway boundary.
 *   - JWT must be present on every connection — no anonymous sockets.
 */
@WebSocketGateway({
  namespace: 'exchange',
  cors: { origin: true, credentials: true },
  transports: ['websocket'],
})
export class ExchangeGateway
  implements OnGatewayInit, OnGatewayConnection, OnGatewayDisconnect
{
  private readonly logger = new Logger(ExchangeGateway.name);

  @WebSocketServer()
  private server!: Server;

  constructor(private readonly broadcaster: RealtimeBroadcaster) {}

  async afterInit(): Promise<void> {
    // Spin up a dedicated pub/sub pair just for the Socket.io adapter.
    const pubClient = new Redis(buildRedisConfig());
    const subClient = pubClient.duplicate();
    this.server.adapter(createAdapter(pubClient, subClient));

    // Register the local forwarder — when the broadcaster receives an event
    // via Redis pub/sub, this lambda delivers it to locally-connected sockets.
    this.broadcaster.registerLocalForwarder((envelope: WsEventEnvelope<unknown>) => {
      this.deliverLocally(envelope);
    });

    this.logger.log('ExchangeGateway initialized with Redis adapter');
  }

  async handleConnection(client: Socket): Promise<void> {
    try {
      const token = this.extractToken(client);
      if (!token) {
        client.emit('error', { errorCode: ErrorCode.UNAUTHORIZED, message: 'Missing token' });
        client.disconnect(true);
        return;
      }
      // NOTE: Full JWT verification happens in the Auth module in Phase 2.
      // For Phase 1, we trust the payload's userId for room-join routing
      // and rely on the REST API for any state-mutating operation.
      const payload = this.decodeUnsafe(token);
      if (!payload?.sub) {
        client.emit('error', { errorCode: ErrorCode.INVALID_TOKEN, message: 'Invalid token' });
        client.disconnect(true);
        return;
      }
      // Persist user info on the socket for disconnect cleanup.
      (client.data as { userId?: string }).userId = payload.sub;
      // Auto-join personal room — broadcaster emits private events here.
      await client.join(`user:${payload.sub}`);
      this.logger.log(`WS connected: client=${client.id} user=${payload.sub}`);
    } catch (err) {
      this.logger.warn(`Connection rejected: ${(err as Error).message}`);
      client.disconnect(true);
    }
  }

  async handleDisconnect(client: Socket): Promise<void> {
    const userId = (client.data as { userId?: string }).userId;
    this.logger.log(`WS disconnected: client=${client.id} user=${userId ?? 'unknown'}`);
  }

  /**
   * Subscribe to a public pair room. The client will receive `orderbook:*`
   * and `trade:tick` events for that pair.
   */
  @SubscribeMessage('subscribe:pair')
  async onSubscribePair(
    @ConnectedSocket() client: Socket,
    @MessageBody() body: { pair: string },
  ): Promise<{ ok: true; room: string } | { ok: false; error: string }> {
    if (body.pair !== 'USD_ETB' && body.pair !== 'USDT_ETB') {
      throw new BusinessException(ErrorCode.INVALID_PAIR, `Pair ${body.pair} not supported`);
    }
    const room = `pair:${body.pair}` as RoomName;
    await client.join(room);
    return { ok: true, room };
  }

  @SubscribeMessage('unsubscribe:pair')
  async onUnsubscribePair(
    @ConnectedSocket() client: Socket,
    @MessageBody() body: { pair: string },
  ): Promise<{ ok: true }> {
    await client.leave(`pair:${body.pair}`);
    return { ok: true };
  }

  @SubscribeMessage('subscribe:trade')
  async onSubscribeTrade(
    @ConnectedSocket() client: Socket,
    @MessageBody() body: { tradeId: string },
  ): Promise<{ ok: true; room: string }> {
    const room = `trade:${body.tradeId}` as RoomName;
    await client.join(room);
    return { ok: true, room };
  }

  // ===========================================================================
  // PRIVATE
  // ===========================================================================

  private deliverLocally(envelope: WsEventEnvelope<unknown>): void {
    if (!this.server) return;
    // The broadcaster already chose the room; we re-broadcast to that room
    // via the Socket.io adapter so cross-instance subscribers also receive it.
    // We piggyback the room name on the envelope's `event` data field by
    // having the broadcaster emit directly to user/pair rooms.
    //
    // Simpler approach: broadcast to every matching room in our local server.
    // The adapter handles deduplication across instances.
    this.server.emit(envelope.event, envelope);
  }

  private extractToken(client: Socket): string | null {
    const fromAuth = (client.handshake.auth as { token?: string } | undefined)?.token;
    if (fromAuth) return fromAuth;
    const fromQuery = client.handshake.query?.token;
    if (typeof fromQuery === 'string') return fromQuery;
    return null;
  }

  /**
   * DECODES the JWT WITHOUT verifying the signature.
   * This is intentional: full verification happens in the Auth module (Phase 2),
   * and the gateway only needs the userId for room routing. Mutating operations
   * still go through the REST API where JwtAuthGuard enforces signature checks.
   */
  private decodeUnsafe(token: string): { sub?: string } | null {
    try {
      const parts = token.split('.');
      if (parts.length !== 3) return null;
      const payload = JSON.parse(
        Buffer.from(parts[1], 'base64url').toString('utf8'),
      ) as { sub?: string };
      return payload;
    } catch {
      return null;
    }
  }
}
