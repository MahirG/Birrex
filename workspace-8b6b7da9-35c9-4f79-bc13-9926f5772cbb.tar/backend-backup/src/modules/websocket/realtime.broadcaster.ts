import { Injectable, Logger } from '@nestjs/common';
import Redis from 'ioredis';
import { buildRedisConfig } from '../../config';
import {
  type WsEventEnvelope,
  type WsEventName,
  type RoomName,
  type TradeCreatedPayload,
  type OrderPlacedPayload,
  type OrderbookUpdatePayload,
  type TradeTickPayload,
} from '../../types/ws-events.types';
import { TradeStatus } from '../../database/entities';

/**
 * RealtimeBroadcaster — facade over Redis pub/sub for horizontal scaling.
 *
 * Each NestJS instance runs its own Socket.io server. When the matching
 * engine emits an event, we DON'T broadcast locally — we publish to a Redis
 * pub/sub channel. Every NestJS instance subscribes to that channel and
 * forwards the event to the WebSocket clients connected to IT.
 *
 * This means: if user A is connected to instance 1 and user B is connected
 * to instance 2, a trade matched on instance 1 still reaches both A and B
 * because instance 2 receives the event via Redis pub/sub and forwards it
 * to user B's local socket.
 *
 * The Socket.io Redis adapter (configured separately in the gateway module)
 * handles room-membership replication across instances. We use pub/sub here
 * for our application-level event envelope so we can attach traceId +
 * timestamps uniformly.
 */
export const REALTIME_CHANNEL = 'etb:realtime';

@Injectable()
export class RealtimeBroadcaster {
  private readonly logger = new Logger(RealtimeBroadcaster.name);
  private publisher!: Redis;
  private subscriber!: Redis;
  private localForward: ((envelope: WsEventEnvelope<unknown>) => void) | null = null;

  async onModuleInit(): Promise<void> {
    this.publisher = new Redis(buildRedisConfig());
    this.subscriber = new Redis(buildRedisConfig());

    await this.subscriber.subscribe(REALTIME_CHANNEL);
    this.subscriber.on('message', (_channel: string, message: string) => {
      try {
        const envelope = JSON.parse(message) as WsEventEnvelope<unknown>;
        if (this.localForward) this.localForward(envelope);
      } catch (err) {
        this.logger.error(`Failed to forward WS event: ${(err as Error).message}`);
      }
    });
  }

  /**
   * Registers the local Socket.io forwarder. Called once by the WebSocketGateway.
   */
  registerLocalForwarder(fn: (envelope: WsEventEnvelope<unknown>) => void): void {
    this.localForward = fn;
  }

  // ===========================================================================
  // PUBLIC API — used by the matching engine + escrow service.
  // ===========================================================================

  async emitToUser<TPayload>(
    userId: string,
    event: WsEventName,
    data: TPayload,
    traceId?: string,
  ): Promise<void> {
    const envelope: WsEventEnvelope<TPayload> = {
      event,
      traceId: traceId ?? 'system',
      timestamp: Date.now(),
      data,
    };
    const room: RoomName = `user:${userId}`;
    await this.publish({ room, envelope });
  }

  async emitToRoom<TPayload>(
    room: RoomName,
    event: WsEventName,
    data: TPayload,
    traceId?: string,
  ): Promise<void> {
    const envelope: WsEventEnvelope<TPayload> = {
      event,
      traceId: traceId ?? 'system',
      timestamp: Date.now(),
      data,
    };
    await this.publish({ room, envelope });
  }

  async emitOrderPlaced(userId: string, payload: OrderPlacedPayload, traceId?: string): Promise<void> {
    await this.emitToUser(userId, 'order:placed' as WsEventName, payload, traceId);
  }

  async emitTradeCreated(
    makerUserId: string,
    takerUserId: string,
    payload: TradeCreatedPayload,
    traceId?: string,
  ): Promise<void> {
    // Each user sees the SAME event but with THEIR counterpartyId set correctly.
    const makerPayload: TradeCreatedPayload = { ...payload, counterpartyId: takerUserId };
    const takerPayload: TradeCreatedPayload = { ...payload, counterpartyId: makerUserId };
    await Promise.all([
      this.emitToUser(makerUserId, 'trade:created' as WsEventName, makerPayload, traceId),
      this.emitToUser(takerUserId, 'trade:created' as WsEventName, takerPayload, traceId),
    ]);
  }

  async emitOrderbookUpdate(
    pair: string,
    payload: OrderbookUpdatePayload,
    traceId?: string,
  ): Promise<void> {
    await this.emitToRoom(`pair:${pair}` as RoomName, 'orderbook:update' as WsEventName, payload, traceId);
  }

  async emitTradeTick(pair: string, payload: TradeTickPayload, traceId?: string): Promise<void> {
    await this.emitToRoom(`pair:${pair}` as RoomName, 'trade:tick' as WsEventName, payload, traceId);
  }

  async emitTradeStatusChange(
    userId: string,
    tradeId: string,
    tradeNumber: string,
    status: TradeStatus,
    traceId?: string,
  ): Promise<void> {
    await this.emitToUser(
      userId,
      this.eventNameForStatus(status),
      { tradeId, tradeNumber, status, timestamp: Date.now() },
      traceId,
    );
  }

  // ===========================================================================
  // INTERNAL
  // ===========================================================================

  private eventNameForStatus(status: TradeStatus): WsEventName {
    switch (status) {
      case TradeStatus.ESCROWED:           return 'trade:escrowed' as WsEventName;
      case TradeStatus.PAYMENT_WINDOW_OPEN:return 'trade:payment_window_open' as WsEventName;
      case TradeStatus.PAYMENT_INITIATED:  return 'trade:payment_initiated' as WsEventName;
      case TradeStatus.PAYMENT_CONFIRMED:  return 'trade:payment_confirmed' as WsEventName;
      case TradeStatus.RELEASED:           return 'trade:released' as WsEventName;
      case TradeStatus.CANCELLED:          return 'trade:cancelled' as WsEventName;
      case TradeStatus.EXPIRED:            return 'trade:expired' as WsEventName;
      case TradeStatus.DISPUTED:           return 'dispute:opened' as WsEventName;
      default:                              return 'notification' as WsEventName;
    }
  }

  private async publish(message: { room: RoomName; envelope: WsEventEnvelope<unknown> }): Promise<void> {
    if (!this.publisher) {
      // Not yet initialized — log and drop. (Should never happen post-OnModuleInit.)
      this.logger.warn(`Publisher not initialized; dropping event for ${message.room}`);
      return;
    }
    const payload = JSON.stringify({ room: message.room, envelope: message.envelope });
    await this.publisher.publish(REALTIME_CHANNEL, payload);
  }

  /** Test-only: in-process bypass of Redis pub/sub for unit tests. */
  setInMemoryForwarder(fn: (envelope: WsEventEnvelope<unknown>) => void): void {
    this.localForward = fn;
  }

  /** Test-only: stub publisher so emit* calls don't crash. */
  initForTesting(): void {
    this.publisher = {
      publish: async () => 1,
    } as unknown as Redis;
    this.subscriber = {
      subscribe: async () => 1,
      on: () => undefined,
    } as unknown as Redis;
  }
}
