import { Module, Global } from '@nestjs/common';
import { RealtimeBroadcaster } from './realtime.broadcaster';
import { ExchangeGateway } from './websocket.gateway';

@Global()
@Module({
  providers: [RealtimeBroadcaster, ExchangeGateway],
  exports: [RealtimeBroadcaster],
})
export class WebSocketModule {}
