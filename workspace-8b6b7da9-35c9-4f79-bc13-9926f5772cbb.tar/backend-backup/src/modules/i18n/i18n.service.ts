import { Injectable } from '@nestjs/common';
import { SupportedLanguage } from '../../database/entities';

/**
 * Translation keys used across the platform.
 * Adding a new string:
 *   1. Add a key here (alphabetical).
 *   2. Add the same key to BOTH translations[en] and translations[am].
 *   3. Use placeholder tokens like {orderCount} for runtime substitution.
 */
export const TranslationKey = {
  // Auth
  AUTH_INVALID_CREDENTIALS: 'AUTH_INVALID_CREDENTIALS',
  AUTH_ACCOUNT_LOCKED: 'AUTH_ACCOUNT_LOCKED',
  AUTH_2FA_INVALID: 'AUTH_2FA_INVALID',
  AUTH_LOGGED_IN: 'AUTH_LOGGED_IN',

  // Wallet
  WALLET_INSUFFICIENT_BALANCE: 'WALLET_INSUFFICIENT_BALANCE',
  WALLET_DEPOSIT_SUCCESS: 'WALLET_DEPOSIT_SUCCESS',
  WALLET_WITHDRAWAL_REQUESTED: 'WALLET_WITHDRAWAL_REQUESTED',

  // Orderbook
  ORDER_PLACED: 'ORDER_PLACED',
  ORDER_PARTIALLY_FILLED: 'ORDER_PARTIALLY_FILLED',
  ORDER_FILLED: 'ORDER_FILLED',
  ORDER_CANCELLED: 'ORDER_CANCELLED',
  ORDER_PRICE_INVALID: 'ORDER_PRICE_INVALID',
  ORDER_QTY_INVALID: 'ORDER_QTY_INVALID',
  ORDER_BELOW_MIN: 'ORDER_BELOW_MIN',
  ORDER_ABOVE_MAX: 'ORDER_ABOVE_MAX',
  SELF_MATCH_FORBIDDEN: 'SELF_MATCH_FORBIDDEN',

  // Trade lifecycle
  TRADE_MATCHED: 'TRADE_MATCHED',
  TRADE_ESCROWED: 'TRADE_ESCROWED',
  TRADE_PAYMENT_WINDOW_OPEN: 'TRADE_PAYMENT_WINDOW_OPEN',
  TRADE_PAYMENT_WINDOW_EXPIRED: 'TRADE_PAYMENT_WINDOW_EXPIRED',
  TRADE_PAYMENT_INITIATED: 'TRADE_PAYMENT_INITIATED',
  TRADE_PAYMENT_CONFIRMED: 'TRADE_PAYMENT_CONFIRMED',
  TRADE_RELEASED: 'TRADE_RELEASED',
  TRADE_CANCELLED: 'TRADE_CANCELLED',
  TRADE_DISPUTED: 'TRADE_DISPUTED',

  // Dispute
  DISPUTE_OPENED: 'DISPUTE_OPENED',
  DISPUTE_RESOLVED_MAKER: 'DISPUTE_RESOLVED_MAKER',
  DISPUTE_RESOLVED_TAKER: 'DISPUTE_RESOLVED_TAKER',
  DISPUTE_RESOLVED_REFUND: 'DISPUTE_RESOLVED_REFUND',

  // KYC
  KYC_SUBMITTED: 'KYC_SUBMITTED',
  KYC_VERIFIED: 'KYC_VERIFIED',
  KYC_REJECTED: 'KYC_REJECTED',

  // Generic
  INTERNAL_ERROR: 'INTERNAL_ERROR',
  NOT_FOUND: 'NOT_FOUND',
} as const;

export type TranslationKeyType = (typeof TranslationKey)[keyof typeof TranslationKey];

type TranslationMap = Readonly<Record<TranslationKeyType, string>>;

const en: TranslationMap = {
  AUTH_INVALID_CREDENTIALS: 'Invalid email or password',
  AUTH_ACCOUNT_LOCKED: 'Account locked. Try again in {minutes} minutes.',
  AUTH_2FA_INVALID: 'Invalid 2FA code',
  AUTH_LOGGED_IN: 'Logged in successfully',

  WALLET_INSUFFICIENT_BALANCE: 'Insufficient {currency} balance. Required: {required}, available: {available}',
  WALLET_DEPOSIT_SUCCESS: 'Deposit of {amount} {currency} confirmed',
  WALLET_WITHDRAWAL_REQUESTED: 'Withdrawal of {amount} {currency} requested',

  ORDER_PLACED: 'Order placed: {side} {quantity} {pair} @ {price}',
  ORDER_PARTIALLY_FILLED: 'Order partially filled: {filledQuantity}/{quantity}',
  ORDER_FILLED: 'Order filled completely',
  ORDER_CANCELLED: 'Order cancelled',
  ORDER_PRICE_INVALID: 'Price must be greater than zero',
  ORDER_QTY_INVALID: 'Quantity must be greater than zero',
  ORDER_BELOW_MIN: 'Order value {value} ETB is below the minimum {min} ETB',
  ORDER_ABOVE_MAX: 'Order value {value} ETB exceeds the maximum {max} ETB',
  SELF_MATCH_FORBIDDEN: 'Cannot match against your own order',

  TRADE_MATCHED: 'Trade matched: {quantity} {pair} @ {price} ETB',
  TRADE_ESCROWED: 'Crypto escrowed — payment window is now open',
  TRADE_PAYMENT_WINDOW_OPEN: 'You have {minutes} minutes to send {amount} ETB via {provider}',
  TRADE_PAYMENT_WINDOW_EXPIRED: 'Payment window expired. Trade cancelled.',
  TRADE_PAYMENT_INITIATED: 'Payment marked as sent — awaiting confirmation',
  TRADE_PAYMENT_CONFIRMED: 'Payment confirmed — releasing escrow',
  TRADE_RELEASED: 'Trade complete. Crypto released to buyer.',
  TRADE_CANCELLED: 'Trade cancelled: {reason}',
  TRADE_DISPUTED: 'Dispute opened on trade {tradeNumber}',

  DISPUTE_OPENED: 'Dispute opened against trade {tradeNumber}',
  DISPUTE_RESOLVED_MAKER: 'Dispute resolved in favor of the seller — crypto returned',
  DISPUTE_RESOLVED_TAKER: 'Dispute resolved in favor of the buyer — crypto released',
  DISPUTE_RESOLVED_REFUND: 'Dispute resolved with partial refund',

  KYC_SUBMITTED: 'KYC documents submitted — under review',
  KYC_VERIFIED: 'KYC verification approved',
  KYC_REJECTED: 'KYC verification rejected: {reason}',

  INTERNAL_ERROR: 'An unexpected error occurred. Please contact support.',
  NOT_FOUND: 'Resource not found',
};

const am: TranslationMap = {
  AUTH_INVALID_CREDENTIALS: 'የተሳሳተ ኢሜይል ወይም የይለፍ ቃል',
  AUTH_ACCOUNT_LOCKED: 'መለያው ተቆልፏል። ከ{minutes} ደቂቃ በኋላ እንደገና ይሞክሩ።',
  AUTH_2FA_INVALID: 'የተሳሳተ የ2አጭበርባሪ ኮድ',
  AUTH_LOGGED_IN: 'በተሳካ ሁኔታ ገብተዋል',

  WALLET_INSUFFICIENT_BALANCE: 'የበቂ {currency} ሂሳብ የለም። የሚያስፈልገው: {required}፣ ያለው: {available}',
  WALLET_DEPOSIT_SUCCESS: 'የ{amount} {currency} ተወስኗል',
  WALLET_WITHDRAWAL_REQUESTED: 'የ{amount} {currency} መውሰጃ ተጠይቋል',

  ORDER_PLACED: 'ትዕዛዝ ተሰጥቷል: {side} {quantity} {pair} @ {price}',
  ORDER_PARTIALLY_FILLED: 'ትዕዛዝ ከፊል ተሞልቷል: {filledQuantity}/{quantity}',
  ORDER_FILLED: 'ትዕዛዝ ሙሉ በሙሉ ተሞልቷል',
  ORDER_CANCELLED: 'ትዕዛዝ ተሰርዟል',
  ORDER_PRICE_INVALID: 'ዋጋ ከዜሮ መብለጥ አለበት',
  ORDER_QTY_INVALID: 'ብዛት ከዜሮ መብለጥ አለበት',
  ORDER_BELOW_MIN: 'የትዕዛዝ ዋጋ {value} ብር ከመውሰኛ መጠን {min} ብር ዝቅተኛ ነው',
  ORDER_ABOVE_MAX: 'የትዕዛዝ ዋጋ {value} ብር ከከፍተኛ መጠን {max} ብር አልፏል',
  SELF_MATCH_FORBIDDEN: 'ከራስዎ ትዕዛዝ ጋር ማዛመድ አይቻልም',

  TRADE_MATCHED: 'ግብይት ተዛምዷል: {quantity} {pair} @ {price} ብር',
  TRADE_ESCROWED: 'ክሪፕቶ ተቆልፏል — የክፍያ ጊዜ ክፍት ነው',
  TRADE_PAYMENT_WINDOW_OPEN: '{amount} ብር በ{provider} ለመላክ {minutes} ደቂቃ ቀርቶዎታል',
  TRADE_PAYMENT_WINDOW_EXPIRED: 'የክፍያ ጊዜ አልፏል። ግብይት ተሰርዟል።',
  TRADE_PAYMENT_INITIATED: 'ክፍያ የተላከ ተደርጓል — ማረጋገጥ በመጠበቅ ላይ',
  TRADE_PAYMENT_CONFIRMED: 'ክፍያ ተረጋግጧል — ክሪፕቶ በመላክ ላይ',
  TRADE_RELEASED: 'ግብይት ተጠናቅቋል። ክሪፕቶ ለገዢ ተልኳል።',
  TRADE_CANCELLED: 'ግብይት ተሰርዟል: {reason}',
  TRADE_DISPUTED: 'በግብይት {tradeNumber} ላይ ክርክር ተከፈተ',

  DISPUTE_OPENED: 'በግብይት {tradeNumber} ላይ ክርክር ተከፈተ',
  DISPUTE_RESOLVED_MAKER: 'ክርክር በሻጭ በኩል ተፈቀደ — ክሪፕቶ ተመልሷል',
  DISPUTE_RESOLVED_TAKER: 'ክርክር በገዢ በኩል ተፈቀደ — ክሪፕቶ ተልኳል',
  DISPUTE_RESOLVED_REFUND: 'ክርክር በከፊል መመለሻ ተፈቀደ',

  KYC_SUBMITTED: 'የKYC ሰነዶች ቀርበዋል — በግምገማ ላይ',
  KYC_VERIFIED: 'የKYC ማረጋገጥ ተፈቅዷል',
  KYC_REJECTED: 'የKYC ማረጋገጥ ተከልክሏል: {reason}',

  INTERNAL_ERROR: 'ያልተጠበቀ ስህተት ተከስቷል። እባክዎ ድጋፍን ያነጋግሩ።',
  NOT_FOUND: 'ሀብት አልተገኘም',
};

const dictionaries: Readonly<Record<SupportedLanguage, TranslationMap>> = { en, am };

export type TranslationParams = Readonly<Record<string, string | number>>;

@Injectable()
export class I18nService {
  /**
   * Translate a key for the given language, substituting {placeholder} tokens.
   * Falls back to English if the key is missing for the requested language,
   * then to the key itself if missing from English too (defensive).
   */
  translate(
    key: TranslationKeyType,
    lang: SupportedLanguage = 'en',
    params?: TranslationParams,
  ): string {
    const map = dictionaries[lang] ?? dictionaries.en;
    const template = map[key] ?? dictionaries.en[key] ?? (key as string);
    if (!params) return template;

    return Object.entries(params).reduce<string>(
      (acc, [k, v]) => acc.replaceAll(`{${k}}`, String(v)),
      template,
    );
  }
}
