import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { DataSource, Repository } from 'typeorm';
import { v4 as uuid } from 'uuid';

import {
  User,
  KycStatus,
  UserRole,
  KycSubmission,
  KycDocument,
  KycDocType,
  KycDocumentSide,
  KycDocumentStatus,
} from '../../database/entities';
import { CryptoService } from '../../common/crypto.service';
import { StorageService } from '../../common/storage.service';
import { BusinessException, ErrorCode } from '../../common/exceptions/business.exception';
import {
  type SubmitKycDto,
  type KycSubmissionResponse,
  type KycStatusResponse,
} from './dto/kyc.dto';

/**
 * KycService — handles the KYC submission + review lifecycle.
 *
 * Submission lifecycle:
 *   1. User submits via POST /v1/kyc/submit with documents.
 *   2. Service validates the user hasn't already submitted (status PENDING).
 *   3. Service uploads each document to S3 via StorageService.
 *   4. Service compares the S3-side SHA-256 to the client-supplied hash.
 *      Mismatch → 400 (tamper detection).
 *   5. Service creates a KycSubmission + N KycDocument rows in a single tx.
 *   6. Service flips user.kyc_status to PENDING.
 *
 * Review lifecycle (moderator-only):
 *   1. Moderator lists PENDING submissions via GET /v1/admin/kyc/pending.
 *   2. Moderator reviews documents (downloads via StorageService).
 *   3. POST /v1/admin/kyc/:submissionId/approve → flips user.kyc_status to VERIFIED.
 *   POST /v1/admin/kyc/:submissionId/reject → flips user.kyc_status to REJECTED.
 *
 * Resubmission policy:
 *   A user whose latest submission is REJECTED can submit again. The
 *   previous submission is preserved for audit; only the latest one drives
 *   user.kyc_status. A user whose latest submission is PENDING cannot
 *   submit again until the moderator resolves it.
 *
 * Document validation:
 *   - Each submission requires at least FRONT side (BACK is optional for passports).
 *   - File types limited to image/png, image/jpeg, application/pdf.
 *   - Max file size 10MB (enforced in the controller via multipart limits).
 */
@Injectable()
export class KycService {
  private readonly logger = new Logger(KycService.name);

  constructor(
    @InjectRepository(KycSubmission)
    private readonly submissionRepo: Repository<KycSubmission>,
    @InjectRepository(User)
    private readonly userRepo: Repository<User>,
    private readonly crypto: CryptoService,
    private readonly storage: StorageService,
    private readonly dataSource: DataSource,
  ) {}

  // ===========================================================================
  // USER: submit + status
  // ===========================================================================

  /**
   * Creates a new KYC submission. The user's kyc_status flips to PENDING.
   * Fails if the user already has a PENDING submission.
   */
  async submitKyc(userId: string, dto: SubmitKycDto): Promise<KycSubmissionResponse> {
    // ---- 1. Validate user + check for existing PENDING submission ----
    const user = await this.userRepo.findOne({
      where: { id: userId },
      select: ['id', 'kycStatus', 'status'],
    });
    if (!user) {
      throw new BusinessException(ErrorCode.NOT_FOUND, 'User not found');
    }

    const existing = await this.submissionRepo.findOne({
      where: { userId, status: KycDocumentStatus.PENDING },
      select: ['id', 'status'],
    });
    if (existing) {
      throw new BusinessException(
        ErrorCode.KYC_ALREADY_SUBMITTED,
        'You already have a KYC submission under review — please wait for the moderator decision',
      );
    }

    // ---- 2. Validate documents ----
    if (dto.documents.length === 0) {
      throw new BusinessException(
        ErrorCode.BAD_REQUEST,
        'At least one document is required (FRONT side mandatory)',
      );
    }
    const hasFront = dto.documents.some((d) => d.side === KycDocumentSide.FRONT);
    if (!hasFront) {
      throw new BusinessException(
        ErrorCode.BAD_REQUEST,
        'FRONT side of the document is required',
      );
    }

    // ---- 3. Upload each file to storage + verify hash ----
    const uploadedFiles: Array<{
      side: KycDocumentSide;
      url: string;
      fileType: string;
      fileSizeBytes: string;
      fileHash: string;
    }> = [];
    for (const doc of dto.documents) {
      const uploaded = await this.storage.upload('kyc', doc.fileContentBase64, doc.fileType);

      // Tamper detection: client-supplied hash must match server-computed hash.
      if (uploaded.sha256 !== doc.fileHash) {
        throw new BusinessException(
          ErrorCode.BAD_REQUEST,
          `File hash mismatch for ${doc.side} side — file may have been tampered with during upload`,
          { clientHash: doc.fileHash, serverHash: uploaded.sha256 },
        );
      }

      uploadedFiles.push({
        side: doc.side,
        url: uploaded.url,
        fileType: doc.fileType,
        fileSizeBytes: uploaded.sizeBytes,
        fileHash: uploaded.sha256,
      });
    }

    // ---- 4. Encrypt the document number ----
    const encryptedDocNumber = this.crypto.encrypt(dto.documentNumber);

    // ---- 5. Persist submission + documents + flip user.kyc_status ----
    const submission = await this.dataSource.transaction(async (manager) => {
      const created = manager.create(KycSubmission, {
        userId,
        documentType: dto.documentType,
        documentNumberEncrypted: encryptedDocNumber,
        fullNameOnDocument: dto.fullNameOnDocument,
        dateOfBirth: new Date(dto.dateOfBirth),
        notes: dto.notes ?? null,
        status: KycDocumentStatus.PENDING,
      });
      const saved = await manager.save(created);

      for (const f of uploadedFiles) {
        const doc = manager.create(KycDocument, {
          submissionId: saved.id,
          side: f.side,
          fileUrl: f.url,
          fileType: f.fileType,
          fileSizeBytes: f.fileSizeBytes,
          fileHash: f.fileHash,
        });
        await manager.save(doc);
      }

      // Flip user.kyc_status → PENDING.
      await manager.update(User, { id: userId }, { kycStatus: KycStatus.PENDING, kycSubmittedAt: new Date() });

      return saved;
    });

    // ---- 6. Reload with documents for the response ----
    const full = await this.submissionRepo.findOne({
      where: { id: submission.id },
      relations: ['documents' as never],
    });
    if (!full) {
      throw new BusinessException(ErrorCode.INTERNAL_ERROR, 'Submission vanished after create');
    }

    this.logger.log(`KYC submitted: user=${userId} submission=${submission.id} type=${dto.documentType}`);
    return this.toResponse(full);
  }

  async getMyKyc(userId: string): Promise<KycStatusResponse> {
    const user = await this.userRepo.findOne({
      where: { id: userId },
      select: ['id', 'kycStatus'],
    });
    if (!user) {
      throw new BusinessException(ErrorCode.NOT_FOUND, 'User not found');
    }

    // Find the latest submission (by createdAt DESC).
    const latest = await this.submissionRepo.findOne({
      where: { userId },
      order: { createdAt: 'DESC' },
      relations: ['documents' as never],
    });

    return {
      kycStatus: user.kycStatus,
      latestSubmission: latest ? this.toResponse(latest) : null,
    };
  }

  // ===========================================================================
  // MODERATOR/ADMIN: list pending + approve/reject
  // ===========================================================================

  /**
   * Returns all PENDING submissions, oldest first (FIFO review queue).
   * Includes the user's name + email so the moderator can identify them.
   */
  async listPending(): Promise<KycSubmissionResponse[]> {
    const submissions = await this.submissionRepo.find({
      where: { status: KycDocumentStatus.PENDING },
      order: { createdAt: 'ASC' },
      relations: ['documents' as never],
      take: 50,
    });
    return submissions.map((s) => this.toResponse(s));
  }

  /**
   * Approves a submission. Flips user.kyc_status to VERIFIED.
   * Idempotent — approving an already-APPROVED submission is a no-op.
   */
  async approveSubmission(submissionId: string, reviewerId: string): Promise<KycSubmissionResponse> {
    return this.dataSource.transaction(async (manager) => {
      const submission = await manager.findOne(KycSubmission, {
        where: { id: submissionId },
        lock: { mode: 'pessimistic_write' },
      });
      if (!submission) {
        throw new BusinessException(ErrorCode.NOT_FOUND, `KYC submission ${submissionId} not found`);
      }
      if (submission.status === KycDocumentStatus.APPROVED) {
        // Idempotent — return as-is.
        const fresh = await this.submissionRepo.findOne({
          where: { id: submissionId },
          relations: ['documents' as never],
        });
        return this.toResponse(fresh!);
      }
      if (submission.status === KycDocumentStatus.REJECTED) {
        throw new BusinessException(
          ErrorCode.CONFLICT,
          'Cannot approve a rejected submission — ask the user to resubmit',
        );
      }

      submission.status = KycDocumentStatus.APPROVED;
      submission.reviewerId = reviewerId;
      submission.reviewedAt = new Date();
      await manager.save(submission);

      // Flip user.kyc_status → VERIFIED.
      await manager.update(
        User,
        { id: submission.userId },
        { kycStatus: KycStatus.VERIFIED, kycVerifiedAt: new Date() },
      );

      this.logger.log(`KYC APPROVED: submission=${submissionId} user=${submission.userId} by=${reviewerId}`);
      return this.toResponse(submission);
    });
  }

  /**
   * Rejects a submission. Flips user.kyc_status to REJECTED so they can
   * resubmit after addressing the rejection reason.
   */
  async rejectSubmission(
    submissionId: string,
    reviewerId: string,
    rejectionReason: string,
  ): Promise<KycSubmissionResponse> {
    return this.dataSource.transaction(async (manager) => {
      const submission = await manager.findOne(KycSubmission, {
        where: { id: submissionId },
        lock: { mode: 'pessimistic_write' },
      });
      if (!submission) {
        throw new BusinessException(ErrorCode.NOT_FOUND, `KYC submission ${submissionId} not found`);
      }
      if (submission.status === KycDocumentStatus.APPROVED) {
        throw new BusinessException(
          ErrorCode.CONFLICT,
          'Cannot reject an already-approved submission',
        );
      }
      if (submission.status === KycDocumentStatus.REJECTED) {
        // Idempotent — return as-is.
        const fresh = await this.submissionRepo.findOne({
          where: { id: submissionId },
          relations: ['documents' as never],
        });
        return this.toResponse(fresh!);
      }

      submission.status = KycDocumentStatus.REJECTED;
      submission.reviewerId = reviewerId;
      submission.reviewedAt = new Date();
      submission.rejectionReason = rejectionReason;
      await manager.save(submission);

      // Flip user.kyc_status → REJECTED.
      await manager.update(User, { id: submission.userId }, { kycStatus: KycStatus.REJECTED });

      this.logger.log(
        `KYC REJECTED: submission=${submissionId} user=${submission.userId} by=${reviewerId} reason="${rejectionReason}"`,
      );
      return this.toResponse(submission);
    });
  }

  // ===========================================================================
  // HELPERS
  // ===========================================================================

  private toResponse(submission: KycSubmission): KycSubmissionResponse {
    const docs = (submission as unknown as { documents?: KycDocument[] }).documents ?? [];
    return {
      id: submission.id,
      userId: submission.userId,
      documentType: submission.documentType,
      fullNameOnDocument: submission.fullNameOnDocument,
      dateOfBirth: submission.dateOfBirth.toISOString().slice(0, 10),
      notes: submission.notes,
      status: submission.status,
      rejectionReason: submission.rejectionReason,
      reviewerId: submission.reviewerId,
      reviewedAt: submission.reviewedAt ? submission.reviewedAt.toISOString() : null,
      createdAt: submission.createdAt.toISOString(),
      documents: docs.map((d) => ({
        id: d.id,
        side: d.side,
        fileUrl: d.fileUrl,
        fileType: d.fileType,
        fileSizeBytes: d.fileSizeBytes,
        fileHash: d.fileHash,
      })),
    };
  }
}

// Suppress unused-import warnings for types referenced via JSDoc only.
void uuid;
void UserRole;
void KycDocType;
