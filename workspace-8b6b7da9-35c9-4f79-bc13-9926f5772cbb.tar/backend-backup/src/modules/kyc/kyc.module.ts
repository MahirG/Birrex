import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User, KycSubmission, KycDocument } from '../../database/entities';
import { AuthModule } from '../auth/auth.module';
import { CryptoService } from '../../common/crypto.service';
import { StorageService } from '../../common/storage.service';
import { KycService } from './kyc.service';
import { KycController, AdminKycController } from './kyc.controller';

@Module({
  imports: [TypeOrmModule.forFeature([User, KycSubmission, KycDocument]), AuthModule],
  controllers: [KycController, AdminKycController],
  providers: [KycService, CryptoService, StorageService],
  exports: [KycService],
})
export class KycModule {}
