import {
  Body,
  Controller,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  Post,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { ThrottlerGuard } from '@nestjs/throttler';

import { KycService } from './kyc.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CsrfGuard } from '../auth/guards/csrf.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { CurrentUser, type AuthUser } from '../../common/decorators/current-user.decorator';
import { LoggingInterceptor } from '../../common/interceptors/logging.interceptor';
import {
  SubmitKycDto,
  RejectKycDto,
  type KycSubmissionResponse,
  type KycStatusResponse,
} from './dto/kyc.dto';
import { UserRole } from '../../database/entities';

/**
 * KycController — user-facing KYC endpoints.
 *
 *   POST /v1/kyc/submit    — submit a new KYC application
 *   GET  /v1/kyc/status    — get current status + latest submission
 *
 * Submit requires CSRF (state-changing). Status is read-only (CSRF-exempt).
 */
@Controller('v1/kyc')
@UseGuards(JwtAuthGuard, ThrottlerGuard)
@UseInterceptors(LoggingInterceptor)
export class KycController {
  constructor(private readonly kycService: KycService) {}

  @Post('submit')
  @HttpCode(HttpStatus.CREATED)
  @UseGuards(CsrfGuard)
  async submit(@CurrentUser() user: AuthUser, @Body() dto: SubmitKycDto): Promise<KycSubmissionResponse> {
    return this.kycService.submitKyc(user.id, dto);
  }

  @Get('status')
  @HttpCode(HttpStatus.OK)
  async status(@CurrentUser() user: AuthUser): Promise<KycStatusResponse> {
    return this.kycService.getMyKyc(user.id);
  }
}

/**
 * AdminKycController — moderator/admin-only KYC review endpoints.
 *
 *   GET  /v1/admin/kyc/pending                — list PENDING submissions
 *   POST /v1/admin/kyc/:submissionId/approve  — approve + verify user
 *   POST /v1/admin/kyc/:submissionId/reject   — reject with reason
 *
 * All routes require JWT + MODERATOR/ADMIN/SUPER_ADMIN role + CSRF token.
 */
@Controller('v1/admin/kyc')
@UseGuards(JwtAuthGuard, RolesGuard, CsrfGuard, ThrottlerGuard)
@UseInterceptors(LoggingInterceptor)
export class AdminKycController {
  constructor(private readonly kycService: KycService) {}

  @Get('pending')
  @HttpCode(HttpStatus.OK)
  @Roles(UserRole.MODERATOR, UserRole.ADMIN, UserRole.SUPER_ADMIN)
  async listPending(): Promise<KycSubmissionResponse[]> {
    return this.kycService.listPending();
  }

  @Post(':submissionId/approve')
  @HttpCode(HttpStatus.OK)
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN)
  async approve(
    @CurrentUser() user: AuthUser,
    @Param('submissionId') submissionId: string,
  ): Promise<KycSubmissionResponse> {
    return this.kycService.approveSubmission(submissionId, user.id);
  }

  @Post(':submissionId/reject')
  @HttpCode(HttpStatus.OK)
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN)
  async reject(
    @CurrentUser() user: AuthUser,
    @Param('submissionId') submissionId: string,
    @Body() dto: RejectKycDto,
  ): Promise<KycSubmissionResponse> {
    return this.kycService.rejectSubmission(submissionId, user.id, dto.rejectionReason);
  }
}
