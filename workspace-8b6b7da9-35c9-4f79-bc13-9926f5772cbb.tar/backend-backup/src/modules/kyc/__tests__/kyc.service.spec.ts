import { Test, type TestingModule } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { v4 as uuid } from 'uuid';
import { createHash } from 'crypto';

import { KycService } from '../kyc.service';
import { CryptoService } from '../../../common/crypto.service';
import { StorageService, type UploadedFile } from '../../../common/storage.service';
import {
  User,
  UserRole,
  UserStatus,
  KycStatus,
  KycSubmission,
  KycDocument,
  KycDocType,
  KycDocumentSide,
  KycDocumentStatus,
} from '../../../database/entities';
import {
  ErrorCode,
} from '../../../common/exceptions/business.exception';
import type { SubmitKycDto } from '../dto/kyc.dto';

/**
 * KYC tests verify:
 *   1. Happy-path submission: user uploads 2 docs → submission PENDING + user.kyc_status PENDING.
 *   2. Tamper detection: client hash ≠ server hash → 400.
 *   3. Duplicate submission: existing PENDING → 409.
 *   4. Missing FRONT side → 400.
 *   5. Approve flow: PENDING → APPROVED + user.kyc_status VERIFIED.
 *   6. Reject flow: PENDING → REJECTED + user.kyc_status REJECTED + reason stored.
 *   7. Idempotent approve (re-approving APPROVED is a no-op).
 *   8. Cannot reject an APPROVED submission.
 *   9. Resubmission after REJECTION succeeds.
 */

class MockState {
  users = new Map<string, User>();
  submissions = new Map<string, KycSubmission>();
  documents = new Map<string, KycDocument>();
}

class MockUserRepo {
  constructor(private readonly state: MockState) {}

  async findOne(options: { where: Record<string, unknown>; select?: string[] }): Promise<User | null> {
    const where = options.where;
    let matched: User | undefined;
    for (const u of this.state.users.values()) {
      let allMatch = true;
      for (const [k, v] of Object.entries(where)) {
        if ((u as unknown as Record<string, unknown>)[k] !== v) {
          allMatch = false;
          break;
        }
      }
      if (allMatch) {
        matched = u;
        break;
      }
    }
    if (!matched) return null;
    if (options.select) {
      const picked: Partial<User> = { id: matched.id };
      for (const s of options.select) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (picked as any)[s] = (matched as any)[s];
      }
      return picked as User;
    }
    return matched;
  }

  async update(criteria: { id: string }, partial: Partial<User>): Promise<{ affected: number }> {
    const u = this.state.users.get(criteria.id);
    if (!u) return { affected: 0 };
    Object.assign(u, partial);
    return { affected: 1 };
  }
}

class MockSubmissionRepo {
  constructor(private readonly state: MockState) {}

  async findOne(options: {
    where: Record<string, unknown>;
    order?: Record<string, 'ASC' | 'DESC'>;
    relations?: string[];
    select?: string[];
    lock?: unknown;
  }): Promise<KycSubmission | null> {
    const where = options.where;
    let matched: KycSubmission | undefined;
    for (const s of this.state.submissions.values()) {
      let allMatch = true;
      for (const [k, v] of Object.entries(where)) {
        if ((s as unknown as Record<string, unknown>)[k] !== v) {
          allMatch = false;
          break;
        }
      }
      if (allMatch) {
        matched = s;
        break;
      }
    }
    if (!matched) return null;
    // Hydrate relations — the service uses `relations: ['documents']`.
    if (options.relations?.includes('documents')) {
      (matched as unknown as { documents: KycDocument[] }).documents = [...this.state.documents.values()]
        .filter((d) => d.submissionId === matched!.id);
    }
    return matched;
  }

  async find(options: {
    where?: Record<string, unknown>;
    order?: Record<string, 'ASC' | 'DESC'>;
    relations?: string[];
    take?: number;
  }): Promise<KycSubmission[]> {
    let arr = [...this.state.submissions.values()];
    if (options.where) {
      arr = arr.filter((s) => {
        for (const [k, v] of Object.entries(options.where!)) {
          if ((s as unknown as Record<string, unknown>)[k] !== v) return false;
        }
        return true;
      });
    }
    if (options.order?.createdAt === 'ASC') {
      arr.sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
    } else if (options.order?.createdAt === 'DESC') {
      arr.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    }
    if (options.take) arr = arr.slice(0, options.take);
    if (options.relations?.includes('documents')) {
      for (const s of arr) {
        (s as unknown as { documents: KycDocument[] }).documents = [...this.state.documents.values()]
          .filter((d) => d.submissionId === s.id);
      }
    }
    return arr;
  }
}

class MockEntityManager {
  constructor(private readonly state: MockState) {}

  create<E extends object>(entity: new (...args: unknown[]) => E, data: Partial<E>): E {
    return Object.assign(new entity(), data) as E;
  }

  async save<E>(entity: E | E[]): Promise<E | E[]> {
    if (Array.isArray(entity)) {
      return Promise.all(entity.map((e) => this.save(e))) as unknown as Promise<E[]>;
    }
    const obj = entity as unknown as { id?: string };
    if (obj instanceof KycSubmission) {
      if (!obj.id) obj.id = uuid();
      if (!obj.createdAt) obj.createdAt = new Date();
      obj.updatedAt = new Date();
      this.state.submissions.set(obj.id, obj);
    } else if (obj instanceof KycDocument) {
      if (!obj.id) obj.id = uuid();
      if (!obj.createdAt) obj.createdAt = new Date();
      this.state.documents.set(obj.id, obj);
    }
    return entity;
  }

  async findOne(
    entity: new (...args: unknown[]) => unknown,
    options: { where: Record<string, unknown>; lock?: unknown },
  ): Promise<unknown | null> {
    if (entity === KycSubmission) {
      const id = options.where.id as string;
      return this.state.submissions.get(id) ?? null;
    }
    return null;
  }

  async update(
    entity: new (...args: unknown[]) => unknown,
    criteria: { id: string },
    partial: Record<string, unknown>,
  ): Promise<{ affected: number }> {
    if (entity === User) {
      const u = this.state.users.get(criteria.id);
      if (!u) return { affected: 0 };
      Object.assign(u, partial);
      return { affected: 1 };
    }
    if (entity === KycSubmission) {
      const s = this.state.submissions.get(criteria.id);
      if (!s) return { affected: 0 };
      Object.assign(s, partial);
      return { affected: 1 };
    }
    return { affected: 0 };
  }
}

class MockDataSource {
  state = new MockState();

  async transaction<T>(fn: (manager: MockEntityManager) => Promise<T>): Promise<T> {
    return fn(new MockEntityManager(this.state));
  }
}

describe('KycService', () => {
  let service: KycService;
  let ds: MockDataSource;
  let userRepo: MockUserRepo;
  let submissionRepo: MockSubmissionRepo;
  let crypto: CryptoService;
  let storage: StorageService;
  let userId: string;

  beforeEach(async () => {
    ds = new MockDataSource();
    userRepo = new MockUserRepo(ds.state);
    submissionRepo = new MockSubmissionRepo(ds.state);

    // CryptoService stub: round-trip plain text.
    crypto = {
      encrypt: (plaintext: string) => Buffer.from(plaintext, 'utf8'),
      decrypt: (blob: Buffer) => blob.toString('utf8'),
    } as unknown as CryptoService;

    // StorageService stub: returns a synthetic URL + computes real SHA-256.
    storage = {
      upload: async (namespace: 'kyc' | 'disputes', contentBase64: string, mimeType: string): Promise<UploadedFile> => {
        const bytes = Buffer.from(contentBase64, 'base64');
        const sha256 = createHash('sha256').update(bytes).digest('hex');
        return {
          url: `s3://${namespace}-bucket/${sha256.slice(0, 16)}`,
          sha256,
          sizeBytes: bytes.length.toString(),
          mimeType,
        };
      },
    } as unknown as StorageService;

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        KycService,
        { provide: getRepositoryToken(KycSubmission), useValue: submissionRepo },
        { provide: getRepositoryToken(User), useValue: userRepo },
        { provide: CryptoService, useValue: crypto },
        { provide: StorageService, useValue: storage },
        { provide: DataSource, useValue: ds },
      ],
    }).compile();

    service = module.get(KycService);

    // Seed a user with UNVERIFIED KYC.
    userId = uuid();
    const user: User = {
      id: userId,
      email: 'kycuser@example.com',
      phoneNumber: '+251911234567',
      passwordHash: 'x',
      fullName: 'KYC User',
      role: UserRole.USER,
      status: UserStatus.ACTIVE,
      kycStatus: KycStatus.UNVERIFIED,
      kycSubmittedAt: null,
      kycVerifiedAt: null,
      kycDocumentType: null,
      kycDocumentNumberEncrypted: null,
      is2faEnabled: false,
      totpSecretEncrypted: null,
      preferredLanguage: 'en',
      timezone: 'Africa/Addis_Ababa',
      lastLoginAt: null,
      lastLoginIp: null,
      failedLoginAttempts: 0,
      lockedUntil: null,
      createdAt: new Date(),
      updatedAt: new Date(),
      wallets: [] as unknown as User['wallets'],
    } as unknown as User;
    ds.state.users.set(userId, user);
  });

  // ===========================================================================
  // Helper: build a valid SubmitKycDto with matching client+server hashes
  // ===========================================================================
  function buildValidDto(overrides: Partial<SubmitKycDto> = {}): SubmitKycDto {
    const frontContent = Buffer.from('fake-id-front-image-bytes').toString('base64');
    const frontHash = createHash('sha256').update('fake-id-front-image-bytes').digest('hex');
    const backContent = Buffer.from('fake-id-back-image-bytes').toString('base64');
    const backHash = createHash('sha256').update('fake-id-back-image-bytes').digest('hex');
    return {
      documentType: KycDocType.ETHIOPIAN_ID,
      documentNumber: 'ID-12345678',
      fullNameOnDocument: 'KYC User',
      dateOfBirth: '1990-01-01',
      notes: undefined,
      documents: [
        { side: KycDocumentSide.FRONT, fileType: 'image/png', fileSizeBytes: '24', fileHash: frontHash, fileContentBase64: frontContent },
        { side: KycDocumentSide.BACK, fileType: 'image/png', fileSizeBytes: '23', fileHash: backHash, fileContentBase64: backContent },
      ],
      ...overrides,
    };
  }

  // ===========================================================================
  // SUBMIT
  // ===========================================================================
  describe('submitKyc', () => {
    it('creates a PENDING submission + flips user.kyc_status to PENDING', async () => {
      const dto = buildValidDto();
      const response = await service.submitKyc(userId, dto);

      expect(response.status).toBe(KycDocumentStatus.PENDING);
      expect(response.userId).toBe(userId);
      expect(response.documentType).toBe(KycDocType.ETHIOPIAN_ID);
      expect(response.fullNameOnDocument).toBe('KYC User');
      expect(response.dateOfBirth).toBe('1990-01-01');
      expect(response.documents).toHaveLength(2);

      // Verify documents have file hashes
      const front = response.documents.find((d) => d.side === KycDocumentSide.FRONT);
      expect(front?.fileHash).toMatch(/^[a-f0-9]{64}$/);

      // User's kyc_status should have flipped to PENDING.
      const user = ds.state.users.get(userId)!;
      expect(user.kycStatus).toBe(KycStatus.PENDING);
      expect(user.kycSubmittedAt).not.toBeNull();
    });

    it('rejects submission when user already has a PENDING one', async () => {
      // First submission succeeds.
      await service.submitKyc(userId, buildValidDto());

      // Second submission → must fail.
      await expect(
        service.submitKyc(userId, buildValidDto()),
      ).rejects.toMatchObject({ errorCode: ErrorCode.KYC_ALREADY_SUBMITTED });
    });

    it('rejects when no FRONT side is uploaded', async () => {
      const dto = buildValidDto({
        documents: [
          // Only BACK, no FRONT.
          {
            side: KycDocumentSide.BACK,
            fileType: 'image/png',
            fileSizeBytes: '23',
            fileHash: createHash('sha256').update('x').digest('hex'),
            fileContentBase64: Buffer.from('x').toString('base64'),
          },
        ],
      });
      await expect(service.submitKyc(userId, dto)).rejects.toMatchObject({
        errorCode: ErrorCode.BAD_REQUEST,
      });
    });

    it('detects tampering when client-supplied hash ≠ server-computed hash', async () => {
      const dto = buildValidDto();
      // Tamper with the client-side hash on the FRONT document.
      dto.documents[0]!.fileHash = 'a'.repeat(64); // wrong hash

      await expect(service.submitKyc(userId, dto)).rejects.toMatchObject({
        errorCode: ErrorCode.BAD_REQUEST,
        message: expect.stringContaining('hash mismatch'),
      });

      // User's kyc_status should be UNCHANGED.
      const user = ds.state.users.get(userId)!;
      expect(user.kycStatus).toBe(KycStatus.UNVERIFIED);
    });

    it('persists the document number through CryptoService.encrypt (never plaintext-direct)', async () => {
      const dto = buildValidDto({ documentNumber: 'MY-SECRET-ID-123' });
      const response = await service.submitKyc(userId, dto);

      const submission = ds.state.submissions.get(response.id)!;
      // The persisted buffer should decrypt back to the original via CryptoService.
      expect(crypto.decrypt(submission.documentNumberEncrypted)).toBe('MY-SECRET-ID-123');
      // And the document_number_encrypted column should be a Buffer (BYTEA),
      // not a string — so the storage layer treats it as opaque bytes.
      expect(Buffer.isBuffer(submission.documentNumberEncrypted)).toBe(true);
    });
  });

  // ===========================================================================
  // GET STATUS
  // ===========================================================================
  describe('getMyKyc', () => {
    it('returns UNVERIFIED + null submission for a fresh user', async () => {
      const result = await service.getMyKyc(userId);
      expect(result.kycStatus).toBe(KycStatus.UNVERIFIED);
      expect(result.latestSubmission).toBeNull();
    });

    it('returns PENDING + the latest submission after submit', async () => {
      await service.submitKyc(userId, buildValidDto());
      const result = await service.getMyKyc(userId);
      expect(result.kycStatus).toBe(KycStatus.PENDING);
      expect(result.latestSubmission).not.toBeNull();
      expect(result.latestSubmission!.status).toBe(KycDocumentStatus.PENDING);
    });
  });

  // ===========================================================================
  // APPROVE / REJECT
  // ===========================================================================
  describe('approveSubmission', () => {
    it('flips submission to APPROVED + user.kyc_status to VERIFIED', async () => {
      const submission = await service.submitKyc(userId, buildValidDto());
      const reviewerId = uuid();

      const result = await service.approveSubmission(submission.id, reviewerId);

      expect(result.status).toBe(KycDocumentStatus.APPROVED);
      expect(result.reviewerId).toBe(reviewerId);
      expect(result.reviewedAt).not.toBeNull();

      const user = ds.state.users.get(userId)!;
      expect(user.kycStatus).toBe(KycStatus.VERIFIED);
      expect(user.kycVerifiedAt).not.toBeNull();
    });

    it('is idempotent (re-approving APPROVED returns the same state)', async () => {
      const submission = await service.submitKyc(userId, buildValidDto());
      const reviewer1 = uuid();
      const reviewer2 = uuid();

      await service.approveSubmission(submission.id, reviewer1);
      const second = await service.approveSubmission(submission.id, reviewer2);

      // Reviewer should remain the first one (idempotent — no overwrite).
      expect(second.status).toBe(KycDocumentStatus.APPROVED);
      expect(second.reviewerId).toBe(reviewer1);
    });

    it('refuses to approve a REJECTED submission', async () => {
      const submission = await service.submitKyc(userId, buildValidDto());
      await service.rejectSubmission(submission.id, uuid(), 'Photo blurry');

      await expect(
        service.approveSubmission(submission.id, uuid()),
      ).rejects.toMatchObject({ errorCode: ErrorCode.CONFLICT });
    });
  });

  describe('rejectSubmission', () => {
    it('flips submission to REJECTED + user.kyc_status to REJECTED + stores reason', async () => {
      const submission = await service.submitKyc(userId, buildValidDto());
      const reviewerId = uuid();

      const result = await service.rejectSubmission(submission.id, reviewerId, 'ID number does not match photo');

      expect(result.status).toBe(KycDocumentStatus.REJECTED);
      expect(result.reviewerId).toBe(reviewerId);
      expect(result.reviewedAt).not.toBeNull();
      expect(result.rejectionReason).toBe('ID number does not match photo');

      const user = ds.state.users.get(userId)!;
      expect(user.kycStatus).toBe(KycStatus.REJECTED);
    });

    it('refuses to reject an APPROVED submission', async () => {
      const submission = await service.submitKyc(userId, buildValidDto());
      await service.approveSubmission(submission.id, uuid());

      await expect(
        service.rejectSubmission(submission.id, uuid(), 'oops'),
      ).rejects.toMatchObject({ errorCode: ErrorCode.CONFLICT });
    });
  });

  // ===========================================================================
  // RESUBMISSION
  // ===========================================================================
  describe('resubmission after rejection', () => {
    it('allows the user to submit again after a rejection', async () => {
      const first = await service.submitKyc(userId, buildValidDto());
      await service.rejectSubmission(first.id, uuid(), 'Bad photo');

      // Reset user's KYC status (the controller does this implicitly when
      // the user starts a new submission — the service flips it to PENDING).
      // Try submitting again.
      const second = await service.submitKyc(userId, buildValidDto({
        notes: 'Retaking with better lighting',
      }));

      expect(second.status).toBe(KycDocumentStatus.PENDING);
      expect(second.id).not.toBe(first.id);
      expect(second.notes).toBe('Retaking with better lighting');

      // User's kyc_status should now be PENDING (not REJECTED).
      const user = ds.state.users.get(userId)!;
      expect(user.kycStatus).toBe(KycStatus.PENDING);

      // The first submission should still be in the system (audit trail).
      expect(ds.state.submissions.has(first.id)).toBe(true);
    });
  });

  // ===========================================================================
  // LIST PENDING (moderator queue)
  // ===========================================================================
  describe('listPending', () => {
    it('returns only PENDING submissions, oldest first', async () => {
      // Three users submit KYC.
      const user1 = uuid();
      const user2 = uuid();
      const user3 = uuid();
      for (const id of [user1, user2, user3]) {
        const u: User = {
          id,
          email: `u${id}@example.com`,
          phoneNumber: '+251900000000',
          passwordHash: 'x',
          fullName: 'User',
          role: UserRole.USER,
          status: UserStatus.ACTIVE,
          kycStatus: KycStatus.UNVERIFIED,
          is2faEnabled: false,
          totpSecretEncrypted: null,
          kycSubmittedAt: null,
          kycVerifiedAt: null,
          kycDocumentType: null,
          kycDocumentNumberEncrypted: null,
          preferredLanguage: 'en',
          timezone: 'Africa/Addis_Ababa',
          lastLoginAt: null,
          lastLoginIp: null,
          failedLoginAttempts: 0,
          lockedUntil: null,
          createdAt: new Date(),
          updatedAt: new Date(),
          wallets: [] as unknown as User['wallets'],
        } as unknown as User;
        ds.state.users.set(id, u);
        await service.submitKyc(id, buildValidDto());
        // Add a small delay so createdAt timestamps differ.
        await new Promise((r) => setTimeout(r, 5));
      }

      // Approve user2's submission (so it's no longer PENDING).
      const user2Sub = [...ds.state.submissions.values()].find((s) => s.userId === user2)!;
      await service.approveSubmission(user2Sub.id, uuid());

      const pending = await service.listPending();
      expect(pending).toHaveLength(2);
      // Sorted oldest first → user1's submission should come first.
      expect(pending[0]!.userId).toBe(user1);
      expect(pending[1]!.userId).toBe(user3);
    });
  });
});
