import {
  IsEnum,
  IsDateString,
  IsOptional,
  IsString,
  IsArray,
  ValidateNested,
  MinLength,
  MaxLength,
  Matches,
} from 'class-validator';
import { Type } from 'class-transformer';
import {
  KycDocType,
  KycDocumentSide,
} from '../../../database/entities';

/**
 * KycDocumentUploadDto — metadata for a single uploaded file.
 *
 * The actual file bytes are uploaded separately via a presigned S3 URL
 * (Phase 3 concern). For Phase 2, the frontend uploads directly via multipart
 * form-data and the controller hands the parsed file metadata to the service.
 *
 * `fileHash` (SHA-256 hex) lets us:
 *   - Detect tampering (compare hash to re-computed hash on read)
 *   - Deduplicate uploads (same hash → same file)
 *   - Verify integrity across the S3 round-trip
 */
export class KycDocumentUploadDto {
  @IsEnum(KycDocumentSide)
  side: KycDocumentSide;

  @IsString()
  @Matches(/^(image\/(png|jpeg)|application\/pdf)$/, {
    message: 'fileType must be image/png, image/jpeg, or application/pdf',
  })
  fileType: string;

  @IsString()
  @Matches(/^\d+$/, { message: 'fileSizeBytes must be a positive integer string' })
  fileSizeBytes: string;

  @IsString()
  @Matches(/^[a-f0-9]{64}$/, { message: 'fileHash must be a SHA-256 hex digest (64 chars)' })
  fileHash: string;

  /**
   * Base64-encoded file contents. In production this would be a multipart
   * upload, but for the Phase 2 controller we accept base64 for simplicity.
   * The service uploads to S3 and stores the resulting URL.
   */
  @IsString()
  fileContentBase64: string;
}

export class SubmitKycDto {
  @IsEnum(KycDocType)
  documentType: KycDocType;

  @IsString()
  @MinLength(4)
  @MaxLength(64)
  documentNumber: string;

  @IsString()
  @MinLength(2)
  @MaxLength(255)
  fullNameOnDocument: string;

  @IsDateString()
  dateOfBirth: string;

  @IsOptional()
  @IsString()
  @MaxLength(1000)
  notes?: string;

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => KycDocumentUploadDto)
  documents: KycDocumentUploadDto[];
}

export class RejectKycDto {
  @IsString()
  @MinLength(5)
  @MaxLength(1000)
  rejectionReason: string;
}

export interface KycSubmissionResponse {
  id: string;
  userId: string;
  documentType: string;
  fullNameOnDocument: string;
  dateOfBirth: string;
  notes: string | null;
  status: string;
  rejectionReason: string | null;
  reviewerId: string | null;
  reviewedAt: string | null;
  createdAt: string;
  documents: Array<{
    id: string;
    side: string;
    fileUrl: string;
    fileType: string;
    fileSizeBytes: string;
    fileHash: string;
  }>;
}

export interface KycStatusResponse {
  kycStatus: string;
  latestSubmission: KycSubmissionResponse | null;
}
