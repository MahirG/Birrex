import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  Index,
  ManyToOne,
  JoinColumn,
  type Relation,
} from 'typeorm';
import { User } from './user.entity';

export enum PaymentProvider {
  TELEBIRR = 'TELEBIRR',
  MPESA = 'MPESA',
  CBE = 'CBE',
  AWASH = 'AWASH',
  DASHEN = 'DASHEN',
  ABAY = 'ABAY',
  HIBRET_BANK = 'HIBRET_BANK',
  BANK_OF_ABYSINIA = 'BANK_OF_ABYSINIA',
}

export enum PaymentMethodType {
  MOBILE_MONEY = 'MOBILE_MONEY',
  BANK_TRANSFER = 'BANK_TRANSFER',
  BANK_DEPOSIT = 'BANK_DEPOSIT',
}

@Entity('payment_methods')
@Index('idx_payment_methods_user_id', ['userId'])
@Index('idx_payment_methods_provider', ['provider'])
export class PaymentMethod {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ name: 'user_id', type: 'uuid' })
  userId: string;

  @ManyToOne(() => User, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'user_id' })
  user: Relation<User>;

  @Column({ type: 'enum', enum: PaymentProvider })
  provider: PaymentProvider;

  @Column({ type: 'enum', enum: PaymentMethodType })
  type: PaymentMethodType;

  // Encrypted at the application layer with RSA-256 before INSERT.
  @Column({ name: 'account_name_encrypted', type: 'bytea' })
  accountNameEncrypted: Buffer;

  @Column({ name: 'account_number_encrypted', type: 'bytea' })
  accountNumberEncrypted: Buffer;

  @Column({ name: 'bank_branch', type: 'varchar', length: 255, nullable: true })
  bankBranch: string | null;

  @Column({ name: 'is_verified', default: false })
  isVerified: boolean;

  @Column({ name: 'verified_at', type: 'timestamptz', nullable: true })
  verifiedAt: Date | null;

  @Column({ type: 'varchar', length: 100, nullable: true })
  label: string | null;

  @Column({ name: 'is_active', default: true })
  isActive: boolean;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}
