import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  Index,
  ManyToOne,
  JoinColumn,
  type Relation,
} from 'typeorm';
import { Wallet } from './wallet.entity';
import { Trade } from './trade.entity';

export enum TransactionType {
  DEPOSIT = 'DEPOSIT',
  WITHDRAWAL = 'WITHDRAWAL',
  TRADE_LOCK = 'TRADE_LOCK',
  TRADE_RELEASE = 'TRADE_RELEASE',
  TRADE_REFUND = 'TRADE_REFUND',
  FEE = 'FEE',
  ADJUSTMENT = 'ADJUSTMENT',
}

export enum TransactionStatus {
  PENDING = 'PENDING',
  COMPLETED = 'COMPLETED',
  FAILED = 'FAILED',
  REVERSED = 'REVERSED',
}

/**
 * WalletTransaction — immutable ledger entry.
 *
 * Every balance change is recorded here with before/after snapshots so we can
 * reconstruct any wallet's state at any point in time (NBE compliance).
 *
 * `amount` is SIGNED:
 *   positive = credit (deposit, trade release to this wallet)
 *   negative = debit (withdrawal, trade lock from this wallet)
 */
@Entity('wallet_transactions')
@Index('idx_wallet_tx_wallet_id', ['walletId'])
@Index('idx_wallet_tx_trade_id', ['relatedTradeId'])
@Index('idx_wallet_tx_reference', ['reference'])
export class WalletTransaction {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ name: 'wallet_id', type: 'uuid' })
  walletId: string;

  @ManyToOne(() => Wallet, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'wallet_id' })
  wallet: Relation<Wallet>;

  @Column({ name: 'related_trade_id', type: 'uuid', nullable: true })
  relatedTradeId: string | null;

  @ManyToOne(() => Trade, { onDelete: 'SET NULL', nullable: true })
  @JoinColumn({ name: 'related_trade_id' })
  relatedTrade: Relation<Trade | null>;

  @Column({ type: 'enum', enum: TransactionType })
  type: TransactionType;

  @Column({ type: 'enum', enum: TransactionStatus, default: TransactionStatus.PENDING })
  status: TransactionStatus;

  @Column({ type: 'numeric', precision: 20, scale: 8 })
  amount: string;

  @Column({ name: 'balance_before', type: 'numeric', precision: 20, scale: 8 })
  balanceBefore: string;

  @Column({ name: 'balance_after', type: 'numeric', precision: 20, scale: 8 })
  balanceAfter: string;

  @Column({ unique: true })
  reference: string;

  @Column({ type: 'text', nullable: true })
  description: string | null;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @Column({ name: 'completed_at', type: 'timestamptz', nullable: true })
  completedAt: Date | null;
}
