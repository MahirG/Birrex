import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  Index,
  ManyToOne,
  JoinColumn,
  OneToMany,
  type Relation,
} from 'typeorm';
import { User } from './user.entity';
import { Trade } from './trade.entity';

export enum DisputeStatus {
  OPEN = 'OPEN',
  UNDER_REVIEW = 'UNDER_REVIEW',
  RESOLVED_MAKER = 'RESOLVED_MAKER',
  RESOLVED_TAKER = 'RESOLVED_TAKER',
  RESOLVED_REFUND = 'RESOLVED_REFUND',
  ESCALATED = 'ESCALATED',
}

export enum DisputePriority {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH',
  CRITICAL = 'CRITICAL',
}

/**
 * Dispute — a ticket opened against a Trade when the maker/taker cannot
 * resolve the fiat payment themselves.
 *
 * Lifecycle:
 *   OPEN → UNDER_REVIEW (moderator self-assigns) →
 *     RESOLVED_MAKER (crypto returns to seller)
 *     RESOLVED_TAKER (crypto released to buyer)
 *     RESOLVED_REFUND (split settlement)
 *     ESCALATED (senior admin required)
 *
 * Resolution triggers EscrowService.refundEscrow() or .releaseEscrow()
 * based on the resolution type. The dispute row is the audit trail;
 * the actual financial state change happens in the EscrowService.
 */
@Entity('disputes')
@Index('idx_disputes_trade_id', ['tradeId'])
@Index('idx_disputes_status', ['status'])
@Index('idx_disputes_assigned', ['assignedModeratorId'])
export class Dispute {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ name: 'trade_id', type: 'uuid' })
  tradeId: string;

  @ManyToOne(() => Trade, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'trade_id' })
  trade: Relation<Trade>;

  @Column({ name: 'opened_by', type: 'uuid' })
  openedBy: string;

  @ManyToOne(() => User, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'opened_by' })
  opener: Relation<User>;

  @Column({ name: 'against_user_id', type: 'uuid' })
  againstUserId: string;

  @ManyToOne(() => User, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'against_user_id' })
  againstUser: Relation<User>;

  @Column({ type: 'text' })
  reason: string;

  @Column({ type: 'text', nullable: true })
  description: string | null;

  @Column({ type: 'enum', enum: DisputePriority, default: DisputePriority.MEDIUM })
  priority: DisputePriority;

  @Column({ name: 'assigned_moderator_id', type: 'uuid', nullable: true })
  assignedModeratorId: string | null;

  @ManyToOne(() => User, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'assigned_moderator_id' })
  assignedModerator: Relation<User | null>;

  @Column({ type: 'enum', enum: DisputeStatus, default: DisputeStatus.OPEN })
  status: DisputeStatus;

  @Column({ name: 'resolution_notes', type: 'text', nullable: true })
  resolutionNotes: string | null;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;

  @Column({ name: 'resolved_at', type: 'timestamptz', nullable: true })
  resolvedAt: Date | null;

  @Column({ name: 'resolved_by', type: 'uuid', nullable: true })
  resolvedBy: string | null;

  @ManyToOne(() => User, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'resolved_by' })
  resolver: Relation<User | null>;

  @OneToMany('DisputeEvidence', 'dispute')
  evidence: Relation<unknown[]>;
}

/**
 * DisputeEvidence — a screenshot/file uploaded by either party or the
 * moderator to support their claim (Telebirr transfer confirmation,
 * bank statement, chat log, etc.).
 *
 * `fileHash` is SHA-256 of the raw bytes — used to detect tampering and
 * deduplicate uploads. The original file lives in S3 (MinIO in dev);
 * this row holds the URL + metadata.
 */
@Entity('dispute_evidence')
@Index('idx_dispute_evidence_dispute_id', ['disputeId'])
export class DisputeEvidence {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ name: 'dispute_id', type: 'uuid' })
  disputeId: string;

  @ManyToOne(() => Dispute, (d) => d.evidence, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'dispute_id' })
  dispute: Relation<Dispute>;

  @Column({ name: 'uploaded_by', type: 'uuid' })
  uploadedBy: string;

  @ManyToOne(() => User, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'uploaded_by' })
  uploader: Relation<User>;

  @Column({ name: 'file_url', type: 'varchar', length: 500 })
  fileUrl: string;

  @Column({ name: 'file_type', type: 'varchar', length: 50 })
  fileType: string;

  @Column({ name: 'file_size_bytes', type: 'bigint' })
  fileSizeBytes: string;

  @Column({ name: 'file_hash', type: 'varchar', length: 64 })
  fileHash: string;

  @Column({ type: 'text', nullable: true })
  description: string | null;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;
}
