import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  Index,
  ManyToOne,
  JoinColumn,
  OneToMany,
  type Relation,
  Unique,
} from 'typeorm';
import { User } from './user.entity';

/**
 * WalletCurrency enumerates every asset the platform settles in.
 *  - USD / ETB : the core P2P pair for the Ethiopian market
 *  - USDT      : on-chain stablecoin settlement alternative
 *  - BTC / ETH : native crypto settlement
 */
export enum WalletCurrency {
  USD = 'USD',
  ETB = 'ETB',
  USDT = 'USDT',
  BTC = 'BTC',
  ETH = 'ETH',
}

@Entity('wallets')
@Unique('uq_wallets_user_currency', ['userId', 'currency'])
@Index('idx_wallets_user_id', ['userId'])
@Index('idx_wallets_currency', ['currency'])
export class Wallet {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ name: 'user_id', type: 'uuid' })
  userId: string;

  @ManyToOne(() => User, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'user_id' })
  user: Relation<User>;

  @Column({ type: 'enum', enum: WalletCurrency })
  currency: WalletCurrency;

  /**
   * available_balance: spendable right now (can be used for new orders or withdrawals)
   * locked_balance   : held by an active trade in escrow (cannot double-spend)
   * pending_balance  : incoming settlement awaiting blockchain/payment confirmation
   *
   * The (available + locked) >= 0 CHECK in the DB defends against application bugs.
   */
  @Column({ name: 'available_balance', type: 'numeric', precision: 20, scale: 8, default: 0 })
  availableBalance: string;

  @Column({ name: 'locked_balance', type: 'numeric', precision: 20, scale: 8, default: 0 })
  lockedBalance: string;

  @Column({ name: 'pending_balance', type: 'numeric', precision: 20, scale: 8, default: 0 })
  pendingBalance: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  address: string | null;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;

  @OneToMany('WalletTransaction', 'wallet')
  transactions: Relation<unknown[]>;
}
