import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  Index,
  ManyToOne,
  JoinColumn,
  type Relation,
} from 'typeorm';
import { User } from './user.entity';

/**
 * KycDocumentType — the document categories the platform accepts.
 *
 *  - ETHIOPIAN_ID      : Ethiopian Federal Democratic Republic national ID
 *  - PASSPORT          : Any government-issued passport (Ethiopian or foreign)
 *  - DRIVERS_LICENSE   : Ethiopian driver's license
 *
 * Each document is uploaded twice (front + back) and verified by a moderator
 * before the user's kyc_status flips to VERIFIED.
 */
export enum KycDocType {
  ETHIOPIAN_ID = 'ETHIOPIAN_ID',
  PASSPORT = 'PASSPORT',
  DRIVERS_LICENSE = 'DRIVERS_LICENSE',
}

export enum KycDocumentSide {
  FRONT = 'FRONT',
  BACK = 'BACK',
}

export enum KycDocumentStatus {
  PENDING = 'PENDING',
  APPROVED = 'APPROVED',
  REJECTED = 'REJECTED',
}

/**
 * KycSubmission — one submission per user per verification cycle.
 * A submission contains 1+ documents (front + back of ID, etc).
 *
 * Lifecycle:
 *   UNVERIFIED → (user submits docs) → PENDING → (moderator reviews) →
 *     APPROVED → user.kyc_status = VERIFIED
 *     REJECTED → user.kyc_status = REJECTED, user can submit again after fixes
 *
 * Resubmission policy:
 *   If a user has been REJECTED, they can submit a new KycSubmission. The
 *   previous submission is kept for audit; only the latest one drives the
 *   user.kyc_status field.
 */
@Entity('kyc_submissions')
@Index('idx_kyc_user', ['userId'])
@Index('idx_kyc_status', ['status'])
@Index('idx_kyc_reviewer', ['reviewerId'])
export class KycSubmission {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ name: 'user_id', type: 'uuid' })
  userId: string;

  @ManyToOne(() => User, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'user_id' })
  user: Relation<User>;

  /**
   * The document category for this submission. A user picks ONE category
   * per submission (e.g. "I'm submitting my Ethiopian ID"). Multiple files
   * are then uploaded as KycDocument rows linked to this submission.
   */
  @Column({ name: 'document_type', type: 'enum', enum: KycDocType })
  documentType: KycDocType;

  /**
   * The user-supplied document number (e.g. national ID number, passport #).
   * Encrypted at the application layer with RSA-256 before INSERT.
   */
  @Column({ name: 'document_number_encrypted', type: 'bytea' })
  documentNumberEncrypted: Buffer;

  @Column({ name: 'full_name_on_document', type: 'varchar', length: 255 })
  fullNameOnDocument: string;

  @Column({ name: 'date_of_birth', type: 'date' })
  dateOfBirth: Date;

  /**
   * Free-text notes from the user (e.g. "My ID number was recently changed").
   * Visible to moderators during review.
   */
  @Column({ type: 'text', nullable: true })
  notes: string | null;

  @Column({ type: 'enum', enum: KycDocumentStatus, default: KycDocumentStatus.PENDING })
  status: KycDocumentStatus;

  @Column({ name: 'reviewer_id', type: 'uuid', nullable: true })
  reviewerId: string | null;

  @ManyToOne(() => User, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'reviewer_id' })
  reviewer: Relation<User | null>;

  @Column({ name: 'reviewed_at', type: 'timestamptz', nullable: true })
  reviewedAt: Date | null;

  /**
   * Required when status = REJECTED. Free-text explanation that's shown to
   * the user so they know what to fix before resubmitting.
   */
  @Column({ name: 'rejection_reason', type: 'text', nullable: true })
  rejectionReason: string | null;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}

/**
 * KycDocument — an individual file uploaded as part of a KycSubmission.
 * A submission typically has 2 documents (front + back of the ID).
 *
 * Security:
 *   - file_hash is SHA-256 of the raw file bytes — used to detect tampering
 *     and to deduplicate uploads.
 *   - file_url is an S3 (MinIO in dev) URL with a signed access token.
 *     Only moderators + the user themselves can fetch the bytes.
 */
@Entity('kyc_documents')
@Index('idx_kyc_docs_submission', ['submissionId'])
export class KycDocument {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ name: 'submission_id', type: 'uuid' })
  submissionId: string;

  @ManyToOne(() => KycSubmission, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'submission_id' })
  submission: Relation<KycSubmission>;

  @Column({ name: 'side', type: 'enum', enum: KycDocumentSide })
  side: KycDocumentSide;

  @Column({ name: 'file_url', type: 'varchar', length: 500 })
  fileUrl: string;

  @Column({ name: 'file_type', type: 'varchar', length: 50 })
  fileType: string; // 'image/png' | 'image/jpeg' | 'application/pdf'

  @Column({ name: 'file_size_bytes', type: 'bigint' })
  fileSizeBytes: string;

  /** SHA-256 hex digest of the file's raw bytes — tamper detection + dedup. */
  @Column({ name: 'file_hash', type: 'varchar', length: 64 })
  fileHash: string;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;
}
