import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  Index,
  OneToMany,
  type Relation,
} from 'typeorm';

/**
 * User roles drive authorization across the entire platform.
 *  - USER         : standard trader
 *  - MODERATOR    : can review disputes + KYC submissions
 *  - ADMIN        : can adjust wallets + override trades
 *  - SUPER_ADMIN  : full system control + role assignment
 */
export enum UserRole {
  USER = 'USER',
  MODERATOR = 'MODERATOR',
  ADMIN = 'ADMIN',
  SUPER_ADMIN = 'SUPER_ADMIN',
}

export enum UserStatus {
  PENDING = 'PENDING',
  ACTIVE = 'ACTIVE',
  SUSPENDED = 'SUSPENDED',
  BANNED = 'BANNED',
}

export enum KycStatus {
  UNVERIFIED = 'UNVERIFIED',
  PENDING = 'PENDING',
  VERIFIED = 'VERIFIED',
  REJECTED = 'REJECTED',
}

export enum KycDocumentType {
  ETHIOPIAN_ID = 'ETHIOPIAN_ID',
  PASSPORT = 'PASSPORT',
  DRIVERS_LICENSE = 'DRIVERS_LICENSE',
}

export type SupportedLanguage = 'en' | 'am';

@Entity('users')
@Index('idx_users_email', ['email'])
@Index('idx_users_phone', ['phoneNumber'])
@Index('idx_users_kyc_status', ['kycStatus'])
@Index('idx_users_status', ['status'])
export class User {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ unique: true })
  email: string;

  @Column({ name: 'phone_number', unique: true })
  phoneNumber: string;

  @Column({ name: 'password_hash', select: false })
  passwordHash: string;

  @Column({ name: 'full_name' })
  fullName: string;

  @Column({ type: 'enum', enum: UserRole, default: UserRole.USER })
  role: UserRole;

  @Column({ type: 'enum', enum: UserStatus, default: UserStatus.PENDING })
  status: UserStatus;

  @Column({ name: 'totp_secret_encrypted', type: 'bytea', nullable: true, select: false })
  totpSecretEncrypted: Buffer | null;

  @Column({ name: 'is_2fa_enabled', default: false })
  is2faEnabled: boolean;

  @Column({ name: 'kyc_status', type: 'enum', enum: KycStatus, default: KycStatus.UNVERIFIED })
  kycStatus: KycStatus;

  @Column({ name: 'kyc_submitted_at', type: 'timestamptz', nullable: true })
  kycSubmittedAt: Date | null;

  @Column({ name: 'kyc_verified_at', type: 'timestamptz', nullable: true })
  kycVerifiedAt: Date | null;

  @Column({ name: 'kyc_document_type', type: 'varchar', nullable: true })
  kycDocumentType: KycDocumentType | null;

  @Column({ name: 'kyc_document_number_encrypted', type: 'bytea', nullable: true, select: false })
  kycDocumentNumberEncrypted: Buffer | null;

  @Column({ name: 'preferred_language', type: 'varchar', length: 10, default: 'en' })
  preferredLanguage: SupportedLanguage;

  @Column({ name: 'timezone', type: 'varchar', length: 50, default: 'Africa/Addis_Ababa' })
  timezone: string;

  @Column({ name: 'last_login_at', type: 'timestamptz', nullable: true })
  lastLoginAt: Date | null;

  @Column({ name: 'last_login_ip', type: 'inet', nullable: true })
  lastLoginIp: string | null;

  @Column({ name: 'failed_login_attempts', type: 'int', default: 0 })
  failedLoginAttempts: number;

  @Column({ name: 'locked_until', type: 'timestamptz', nullable: true })
  lockedUntil: Date | null;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;

  // Reverse relations — typed via `Relation<>` to avoid circular import issues.
  // Declared here for ORM-level join support; matching engine uses forward refs.
  @OneToMany('Wallet', 'user')
  wallets: Relation<unknown[]>;
}
