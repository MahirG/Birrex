import { User } from './user.entity';
import { Wallet } from './wallet.entity';
import { WalletTransaction } from './wallet-transaction.entity';
import { PaymentMethod } from './payment-method.entity';
import { Order } from './order.entity';
import { Trade } from './trade.entity';
import { KycSubmission, KycDocument } from './kyc.entity';
import { Dispute, DisputeEvidence } from './dispute.entity';

export const ENTITIES = [
  User,
  Wallet,
  WalletTransaction,
  PaymentMethod,
  Order,
  Trade,
  KycSubmission,
  KycDocument,
  Dispute,
  DisputeEvidence,
] as const;

export type EntityClass = (typeof ENTITIES)[number];

export {
  User,
  UserStatus,
  UserRole,
  KycStatus,
  KycDocumentType,
  SupportedLanguage,
} from './user.entity';

export {
  Wallet,
  WalletCurrency,
} from './wallet.entity';

export {
  WalletTransaction,
  TransactionType,
  TransactionStatus,
} from './wallet-transaction.entity';

export {
  PaymentMethod,
  PaymentProvider,
  PaymentMethodType,
} from './payment-method.entity';

export {
  Order,
  OrderSide,
  OrderType,
  OrderStatus,
} from './order.entity';

export {
  Trade,
  TradeStatus,
} from './trade.entity';

export {
  KycSubmission,
  KycDocument,
  KycDocType,
  KycDocumentSide,
  KycDocumentStatus,
} from './kyc.entity';

export {
  Dispute,
  DisputeEvidence,
  DisputeStatus,
  DisputePriority,
} from './dispute.entity';
