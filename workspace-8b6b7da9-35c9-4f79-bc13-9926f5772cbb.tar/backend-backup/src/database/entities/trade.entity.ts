import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  Index,
  ManyToOne,
  JoinColumn,
  type Relation,
} from 'typeorm';
import { User } from './user.entity';
import { Order } from './order.entity';
import { Wallet } from './wallet.entity';
import { PaymentMethod } from './payment-method.entity';
import { OrderSide } from './order.entity';

export enum TradeStatus {
  ESCROW_PENDING = 'ESCROW_PENDING',
  ESCROWED = 'ESCROWED',
  PAYMENT_WINDOW_OPEN = 'PAYMENT_WINDOW_OPEN',
  PAYMENT_INITIATED = 'PAYMENT_INITIATED',
  PAYMENT_CONFIRMED = 'PAYMENT_CONFIRMED',
  RELEASING = 'RELEASING',
  RELEASED = 'RELEASED',
  DISPUTED = 'DISPUTED',
  CANCELLED = 'CANCELLED',
  EXPIRED = 'EXPIRED',
  REFUNDED = 'REFUNDED',
}

/**
 * Trade entity — a matched execution between a maker order and a taker order.
 *
 * The state machine is the financial contract between the two parties:
 *
 *   ESCROW_PENDING
 *        │  (atomic DB tx: lock maker crypto → record trade)
 *        ▼
 *   ESCROWED  ─────────────► CANCELLED   (only valid before escrow)
 *        │
 *        ▼
 *   PAYMENT_WINDOW_OPEN ──► EXPIRED      (30 min elapsed, no payment)
 *        │
 *        ▼
 *   PAYMENT_INITIATED  ───► DISPUTED     (taker claims sent, maker disagrees)
 *        │
 *        ▼
 *   PAYMENT_CONFIRMED
 *        │
 *        ▼
 *   RELEASING
 *        │  (atomic DB tx: deduct escrow, credit taker, log ledger x2)
 *        ▼
 *   RELEASED  (terminal success)
 *
 * Disputes resolve to one of: RESOLVED_MAKER (crypto returns),
 * RESOLVED_TAKER (crypto released), or RESOLVED_REFUND (split).
 */
@Entity('trades')
@Index('idx_trades_maker_user', ['makerUserId'])
@Index('idx_trades_taker_user', ['takerUserId'])
@Index('idx_trades_status', ['status'])
@Index('idx_trades_trade_number', ['tradeNumber'])
export class Trade {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ name: 'trade_number', unique: true })
  tradeNumber: string;

  @Column({ name: 'maker_order_id', type: 'uuid' })
  makerOrderId: string;

  @ManyToOne(() => Order, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'maker_order_id' })
  makerOrder: Relation<Order>;

  @Column({ name: 'taker_order_id', type: 'uuid' })
  takerOrderId: string;

  @ManyToOne(() => Order, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'taker_order_id' })
  takerOrder: Relation<Order>;

  @Column({ name: 'maker_user_id', type: 'uuid' })
  makerUserId: string;

  @ManyToOne(() => User, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'maker_user_id' })
  makerUser: Relation<User>;

  @Column({ name: 'taker_user_id', type: 'uuid' })
  takerUserId: string;

  @ManyToOne(() => User, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'taker_user_id' })
  takerUser: Relation<User>;

  @Column({ type: 'varchar', length: 20 })
  pair: string;

  @Column({ type: 'enum', enum: OrderSide })
  side: OrderSide; // From the taker's perspective

  @Column({ type: 'numeric', precision: 20, scale: 8 })
  price: string;

  @Column({ type: 'numeric', precision: 20, scale: 8 })
  quantity: string;

  // Generated column in DB; read-only in TypeORM.
  @Column({
    name: 'total_value',
    type: 'numeric',
    precision: 20,
    scale: 8,
    insert: false,
    update: false,
  })
  totalValue: string;

  @Column({ name: 'escrow_wallet_id', type: 'uuid', nullable: true })
  escrowWalletId: string | null;

  @ManyToOne(() => Wallet, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'escrow_wallet_id' })
  escrowWallet: Relation<Wallet | null>;

  @Column({ name: 'crypto_locked_amount', type: 'numeric', precision: 20, scale: 8, default: 0 })
  cryptoLockedAmount: string;

  @Column({ name: 'payment_method_id', type: 'uuid', nullable: true })
  paymentMethodId: string | null;

  @ManyToOne(() => PaymentMethod, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'payment_method_id' })
  paymentMethod: Relation<PaymentMethod | null>;

  @Column({ name: 'payment_reference', type: 'varchar', length: 255, nullable: true })
  paymentReference: string | null;

  @Column({ name: 'payment_screenshot_url', type: 'varchar', length: 500, nullable: true })
  paymentScreenshotUrl: string | null;

  @Column({ name: 'payment_initiated_at', type: 'timestamptz', nullable: true })
  paymentInitiatedAt: Date | null;

  @Column({ name: 'payment_confirmed_at', type: 'timestamptz', nullable: true })
  paymentConfirmedAt: Date | null;

  @Column({ name: 'payment_window_minutes', type: 'int', default: 30 })
  paymentWindowMinutes: number;

  @Column({ name: 'payment_window_expires_at', type: 'timestamptz' })
  paymentWindowExpiresAt: Date;

  @Column({ type: 'enum', enum: TradeStatus, default: TradeStatus.ESCROW_PENDING })
  status: TradeStatus;

  @Column({ name: 'maker_fee', type: 'numeric', precision: 20, scale: 8, default: 0 })
  makerFee: string;

  @Column({ name: 'taker_fee', type: 'numeric', precision: 20, scale: 8, default: 0 })
  takerFee: string;

  @Column({ name: 'disputed_at', type: 'timestamptz', nullable: true })
  disputedAt: Date | null;

  @Column({ name: 'dispute_reason', type: 'text', nullable: true })
  disputeReason: string | null;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;

  @Column({ name: 'completed_at', type: 'timestamptz', nullable: true })
  completedAt: Date | null;

  @Column({ name: 'cancelled_at', type: 'timestamptz', nullable: true })
  cancelledAt: Date | null;

  @Column({ name: 'cancelled_by', type: 'uuid', nullable: true })
  cancelledBy: string | null;

  @Column({ name: 'cancel_reason', type: 'text', nullable: true })
  cancelReason: string | null;
}
