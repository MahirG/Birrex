-- =============================================================================
-- P2-001: KYC submissions + documents
-- -----------------------------------------------------------------------------
-- Adds the kyc_submissions and kyc_documents tables introduced in Phase 2.
-- The original 0001_init.sql migration is unchanged; this is an additive
-- migration that runs after it.
-- =============================================================================

CREATE TYPE kyc_doc_type     AS ENUM ('ETHIOPIAN_ID', 'PASSPORT', 'DRIVERS_LICENSE');
CREATE TYPE kyc_doc_side     AS ENUM ('FRONT', 'BACK');
CREATE TYPE kyc_doc_status   AS ENUM ('PENDING', 'APPROVED', 'REJECTED');

-- =============================================================================
-- KYC SUBMISSIONS — one per (user, verification cycle)
-- =============================================================================
CREATE TABLE kyc_submissions (
    id                              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id                         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    document_type                   kyc_doc_type NOT NULL,

    -- RSA-256 encrypted at the application layer
    document_number_encrypted       BYTEA NOT NULL,
    full_name_on_document           VARCHAR(255) NOT NULL,
    date_of_birth                   DATE NOT NULL,
    notes                           TEXT,

    status                          kyc_doc_status NOT NULL DEFAULT 'PENDING',
    reviewer_id                     UUID REFERENCES users(id) ON DELETE SET NULL,
    reviewed_at                     TIMESTAMPTZ,
    rejection_reason                TEXT,

    created_at                      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at                      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_kyc_user      ON kyc_submissions(user_id);
CREATE INDEX idx_kyc_status    ON kyc_submissions(status);
CREATE INDEX idx_kyc_reviewer  ON kyc_submissions(reviewer_id);

-- =============================================================================
-- KYC DOCUMENTS — individual files attached to a submission
-- =============================================================================
CREATE TABLE kyc_documents (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    submission_id       UUID NOT NULL REFERENCES kyc_submissions(id) ON DELETE CASCADE,

    side                kyc_doc_side NOT NULL,
    file_url            VARCHAR(500) NOT NULL,
    file_type           VARCHAR(50)  NOT NULL,
    file_size_bytes     BIGINT       NOT NULL,
    file_hash           VARCHAR(64)  NOT NULL,        -- SHA-256 hex

    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_kyc_docs_submission ON kyc_documents(submission_id);

-- =============================================================================
-- UPDATED_AT TRIGGERS
-- =============================================================================
CREATE TRIGGER update_kyc_submissions_updated_at
    BEFORE UPDATE ON kyc_submissions
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- =============================================================================
-- END 0002_kyc.sql
-- =============================================================================
