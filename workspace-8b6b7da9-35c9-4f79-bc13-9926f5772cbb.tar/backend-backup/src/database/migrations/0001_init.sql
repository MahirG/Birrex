-- =============================================================================
-- P2P ETB/USD Exchange — PostgreSQL Schema (0001_init.sql)
-- -----------------------------------------------------------------------------
-- Design Goals:
--   1. ACID compliance for all financial state transitions (orders, trades, wallets).
--   2. Immutable audit trail via wallet_transactions ledger.
--   3. Encrypt PII at column level (account numbers, KYC docs, TOTP secrets).
--   4. Support Ethiopian-local payment providers (Telebirr, M-PESA, CBE, Awash,
--      Dashen) and NBE compliance reporting.
--   5. Optimized indexes for the orderbook query path (pair/side/status/price).
-- =============================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- =============================================================================
-- ENUM TYPES
-- =============================================================================
CREATE TYPE user_role        AS ENUM ('USER', 'MODERATOR', 'ADMIN', 'SUPER_ADMIN');
CREATE TYPE user_status      AS ENUM ('PENDING', 'ACTIVE', 'SUSPENDED', 'BANNED');
CREATE TYPE kyc_status       AS ENUM ('UNVERIFIED', 'PENDING', 'VERIFIED', 'REJECTED');
CREATE TYPE wallet_currency  AS ENUM ('USD', 'ETB', 'USDT', 'BTC', 'ETH');
CREATE TYPE txn_type         AS ENUM ('DEPOSIT', 'WITHDRAWAL', 'TRADE_LOCK',
                                       'TRADE_RELEASE', 'TRADE_REFUND', 'FEE',
                                       'ADJUSTMENT');
CREATE TYPE txn_status       AS ENUM ('PENDING', 'COMPLETED', 'FAILED', 'REVERSED');
CREATE TYPE payment_provider AS ENUM ('TELEBIRR', 'MPESA', 'CBE', 'AWASH',
                                       'DASHEN', 'ABAY', 'HIBRET_BANK',
                                       'BANK_OF_ABYSINIA');
CREATE TYPE payment_type     AS ENUM ('MOBILE_MONEY', 'BANK_TRANSFER', 'BANK_DEPOSIT');
CREATE TYPE order_side       AS ENUM ('BUY', 'SELL');
CREATE TYPE order_type       AS ENUM ('LIMIT', 'MARKET');
CREATE TYPE order_status     AS ENUM ('OPEN', 'PARTIALLY_FILLED', 'FILLED',
                                       'CANCELLED', 'EXPIRED');
CREATE TYPE trade_status     AS ENUM (
    'ESCROW_PENDING',         -- Trade just created; crypto not yet locked.
    'ESCROWED',               -- Maker's crypto locked in DB escrow (atomic tx).
    'PAYMENT_WINDOW_OPEN',    -- 30-min fiat payment window started.
    'PAYMENT_INITIATED',      -- Taker marked payment as sent (Telebirr/Bank).
    'PAYMENT_CONFIRMED',      -- Maker confirmed receipt of fiat.
    'RELEASING',              -- Crypto transfer in-flight (settlement).
    'RELEASED',               -- Final state: crypto released to taker.
    'DISPUTED',               -- Either party opened a dispute ticket.
    'CANCELLED',              -- Trade cancelled (pre-escrow only).
    'EXPIRED',                -- Payment window elapsed with no payment.
    'REFUNDED'                -- Crypto returned to maker (dispute resolved).
);
CREATE TYPE dispute_status   AS ENUM ('OPEN', 'UNDER_REVIEW', 'RESOLVED_MAKER',
                                       'RESOLVED_TAKER', 'RESOLVED_REFUND',
                                       'ESCALATED');
CREATE TYPE dispute_priority AS ENUM ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL');
CREATE TYPE notif_type       AS ENUM (
    'ORDER_MATCHED', 'PAYMENT_WINDOW_STARTED', 'PAYMENT_RECEIVED',
    'TRADE_COMPLETED', 'TRADE_CANCELLED', 'TRADE_EXPIRED',
    'DISPUTE_OPENED', 'DISPUTE_UPDATED', 'DISPUTE_RESOLVED',
    'KYC_UPDATE', 'DEPOSIT_CONFIRMED', 'WITHDRAWAL_PROCESSED'
);

-- =============================================================================
-- USERS
-- =============================================================================
CREATE TABLE users (
    id                          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email                       VARCHAR(255) UNIQUE NOT NULL,
    phone_number                VARCHAR(20)  UNIQUE NOT NULL,
    password_hash               VARCHAR(255) NOT NULL,
    full_name                   VARCHAR(255) NOT NULL,
    role                        user_role    NOT NULL DEFAULT 'USER',
    status                      user_status  NOT NULL DEFAULT 'PENDING',

    -- 2FA (TOTP secret stored encrypted — never plaintext)
    totp_secret_encrypted       BYTEA,
    is_2fa_enabled              BOOLEAN NOT NULL DEFAULT FALSE,

    -- KYC (Ethiopian national ID, passport, driver's license)
    kyc_status                  kyc_status  NOT NULL DEFAULT 'UNVERIFIED',
    kyc_submitted_at            TIMESTAMPTZ,
    kyc_verified_at             TIMESTAMPTZ,
    kyc_document_type           VARCHAR(50),                 -- 'ETHIOPIAN_ID' | 'PASSPORT' | 'DRIVERS_LICENSE'
    kyc_document_number_encrypted BYTEA,

    -- Localization
    preferred_language          VARCHAR(10) NOT NULL DEFAULT 'en',  -- 'en' | 'am'
    timezone                    VARCHAR(50) NOT NULL DEFAULT 'Africa/Addis_Ababa',

    -- Security
    last_login_at               TIMESTAMPTZ,
    last_login_ip               INET,
    failed_login_attempts       INT NOT NULL DEFAULT 0,
    locked_until                TIMESTAMPTZ,

    created_at                  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at                  TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT email_format  CHECK (email ~* '^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'),
    CONSTRAINT phone_format  CHECK (phone_number ~* '^\+?[0-9]{10,15}$')
);
CREATE INDEX idx_users_email       ON users(email);
CREATE INDEX idx_users_phone       ON users(phone_number);
CREATE INDEX idx_users_kyc_status  ON users(kyc_status);
CREATE INDEX idx_users_status      ON users(status);

-- =============================================================================
-- WALLETS  (double-entry: available + locked + pending)
--   available: spendable balance
--   locked:    held in escrow for active trades
--   pending:   incoming settlement awaiting confirmation
-- =============================================================================
CREATE TABLE wallets (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id             UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    currency            wallet_currency NOT NULL,

    available_balance   NUMERIC(20,8) NOT NULL DEFAULT 0 CHECK (available_balance >= 0),
    locked_balance      NUMERIC(20,8) NOT NULL DEFAULT 0 CHECK (locked_balance      >= 0),
    pending_balance     NUMERIC(20,8) NOT NULL DEFAULT 0 CHECK (pending_balance     >= 0),

    address             VARCHAR(255),                       -- crypto address (USD stablecoin / BTC / ETH)
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    UNIQUE(user_id, currency)
);
CREATE INDEX idx_wallets_user_id   ON wallets(user_id);
CREATE INDEX idx_wallets_currency  ON wallets(currency);

-- =============================================================================
-- WALLET TRANSACTIONS (immutable ledger — every balance change is recorded)
-- =============================================================================
CREATE TABLE wallet_transactions (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    wallet_id           UUID NOT NULL REFERENCES wallets(id) ON DELETE RESTRICT,
    related_trade_id    UUID,                                -- FK added after trades table
    type                txn_type NOT NULL,
    status              txn_status NOT NULL DEFAULT 'PENDING',

    amount              NUMERIC(20,8) NOT NULL CHECK (amount != 0),  -- signed: +credit / -debit
    balance_before      NUMERIC(20,8) NOT NULL,
    balance_after       NUMERIC(20,8) NOT NULL,

    reference           VARCHAR(255) UNIQUE NOT NULL,        -- e.g. 'TXN-20260625-AB12CD'
    description         TEXT,

    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at        TIMESTAMPTZ
);
CREATE INDEX idx_wallet_tx_wallet_id  ON wallet_transactions(wallet_id);
CREATE INDEX idx_wallet_tx_trade_id   ON wallet_transactions(related_trade_id);
CREATE INDEX idx_wallet_tx_reference  ON wallet_transactions(reference);

-- =============================================================================
-- PAYMENT METHODS (user's preferred Ethiopian banks + mobile money)
-- =============================================================================
CREATE TABLE payment_methods (
    id                          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id                     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    provider                    payment_provider NOT NULL,
    type                        payment_type     NOT NULL,

    -- RSA-256 encrypted at the application layer before INSERT
    account_name_encrypted      BYTEA NOT NULL,
    account_number_encrypted    BYTEA NOT NULL,
    bank_branch                 VARCHAR(255),

    is_verified                 BOOLEAN NOT NULL DEFAULT FALSE,
    verified_at                 TIMESTAMPTZ,

    label                       VARCHAR(100),
    is_active                   BOOLEAN NOT NULL DEFAULT TRUE,

    created_at                  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at                  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_payment_methods_user_id    ON payment_methods(user_id);
CREATE INDEX idx_payment_methods_provider   ON payment_methods(provider);

-- =============================================================================
-- ORDERS  (Maker/Taker)
--   A "maker" order sits in the orderbook waiting to be matched.
--   A "taker" order crosses the spread and matches immediately.
--   The matching engine moves orders from OPEN → PARTIALLY_FILLED → FILLED.
-- =============================================================================
CREATE TABLE orders (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id                 UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,

    pair                    VARCHAR(20) NOT NULL,           -- 'USD_ETB' | 'USDT_ETB'
    side                    order_side  NOT NULL,
    type                    order_type  NOT NULL DEFAULT 'LIMIT',

    price                   NUMERIC(20,8) NOT NULL CHECK (price > 0),
    quantity                NUMERIC(20,8) NOT NULL CHECK (quantity > 0),
    filled_quantity         NUMERIC(20,8) NOT NULL DEFAULT 0 CHECK (filled_quantity >= 0),
    remaining_quantity      NUMERIC(20,8) GENERATED ALWAYS AS (quantity - filled_quantity) STORED,

    -- Payment constraints (Ethiopian market: min/max ETB trade sizes)
    min_order_value         NUMERIC(20,8),
    max_order_value         NUMERIC(20,8),
    payment_method_id       UUID REFERENCES payment_methods(id),
    payment_window_minutes  INT NOT NULL DEFAULT 30 CHECK (payment_window_minutes BETWEEN 5 AND 1440),

    terms                   TEXT,                           -- user-defined trade terms (free-text)

    status                  order_status NOT NULL DEFAULT 'OPEN',

    maker_order_id          UUID,                           -- set when this order matches a maker
    is_maker                BOOLEAN NOT NULL DEFAULT TRUE,

    expires_at              TIMESTAMPTZ,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    cancelled_at            TIMESTAMPTZ,
    filled_at               TIMESTAMPTZ,

    CONSTRAINT filled_not_exceed_quantity CHECK (filled_quantity <= quantity)
);
CREATE INDEX idx_orders_user_id              ON orders(user_id);
CREATE INDEX idx_orders_pair_side_status     ON orders(pair, side, status);
CREATE INDEX idx_orders_pair_side_price      ON orders(pair, side, status, price);
CREATE INDEX idx_orders_status_created       ON orders(status, created_at);

ALTER TABLE orders
    ADD CONSTRAINT fk_orders_maker FOREIGN KEY (maker_order_id)
    REFERENCES orders(id) ON DELETE SET NULL;

-- =============================================================================
-- TRADES  (executed matches between a maker and a taker)
--   Status lifecycle: ESCROW_PENDING → ESCROWED → PAYMENT_WINDOW_OPEN →
--                     PAYMENT_INITIATED → PAYMENT_CONFIRMED → RELEASING → RELEASED
--   Side branches:    DISPUTED → (RESOLVED_MAKER | RESOLVED_TAKER | RESOLVED_REFUND)
--                     EXPIRED → REFUNDED
--                     CANCELLED (pre-escrow only)
-- =============================================================================
CREATE TABLE trades (
    id                          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    trade_number                VARCHAR(20) UNIQUE NOT NULL,    -- 'TRD-YYYYMMDD-XXXXX'

    maker_order_id              UUID NOT NULL REFERENCES orders(id) ON DELETE RESTRICT,
    taker_order_id              UUID NOT NULL REFERENCES orders(id) ON DELETE RESTRICT,
    maker_user_id               UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    taker_user_id               UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,

    pair                        VARCHAR(20) NOT NULL,
    side                        order_side  NOT NULL,           -- from the taker's perspective

    price                       NUMERIC(20,8) NOT NULL CHECK (price > 0),
    quantity                    NUMERIC(20,8) NOT NULL CHECK (quantity > 0),
    total_value                 NUMERIC(20,8) GENERATED ALWAYS AS (price * quantity) STORED,

    escrow_wallet_id            UUID REFERENCES wallets(id),
    crypto_locked_amount        NUMERIC(20,8) NOT NULL DEFAULT 0,

    payment_method_id           UUID REFERENCES payment_methods(id),
    payment_reference           VARCHAR(255),                   -- Telebirr/Bank TX ref
    payment_screenshot_url      VARCHAR(500),
    payment_initiated_at        TIMESTAMPTZ,
    payment_confirmed_at        TIMESTAMPTZ,

    payment_window_minutes      INT NOT NULL DEFAULT 30,
    payment_window_expires_at   TIMESTAMPTZ NOT NULL,

    status                      trade_status NOT NULL DEFAULT 'ESCROW_PENDING',

    maker_fee                   NUMERIC(20,8) NOT NULL DEFAULT 0,
    taker_fee                   NUMERIC(20,8) NOT NULL DEFAULT 0,

    disputed_at                 TIMESTAMPTZ,
    dispute_reason              TEXT,

    created_at                  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at                  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at                TIMESTAMPTZ,
    cancelled_at                TIMESTAMPTZ,
    cancelled_by                UUID REFERENCES users(id),
    cancel_reason               TEXT
);
CREATE INDEX idx_trades_maker_user       ON trades(maker_user_id);
CREATE INDEX idx_trades_taker_user       ON trades(taker_user_id);
CREATE INDEX idx_trades_status           ON trades(status);
CREATE INDEX idx_trades_trade_number     ON trades(trade_number);
CREATE INDEX idx_trades_payment_expires  ON trades(payment_window_expires_at)
    WHERE status IN ('ESCROWED', 'PAYMENT_WINDOW_OPEN', 'PAYMENT_INITIATED');

-- Now that trades exists, link wallet_transactions back to it
ALTER TABLE wallet_transactions
    ADD CONSTRAINT fk_wallet_tx_trade FOREIGN KEY (related_trade_id)
    REFERENCES trades(id) ON DELETE SET NULL;

-- =============================================================================
-- DISPUTES  (ticketing + role-based review for moderators/admins)
-- =============================================================================
CREATE TABLE disputes (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    trade_id                UUID NOT NULL REFERENCES trades(id) ON DELETE RESTRICT,
    opened_by               UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    against_user_id         UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,

    reason                  TEXT NOT NULL,
    description             TEXT,
    priority                dispute_priority NOT NULL DEFAULT 'MEDIUM',

    assigned_moderator_id   UUID REFERENCES users(id),
    status                  dispute_status NOT NULL DEFAULT 'OPEN',
    resolution_notes        TEXT,

    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    resolved_at             TIMESTAMPTZ,
    resolved_by             UUID REFERENCES users(id)
);
CREATE INDEX idx_disputes_trade_id   ON disputes(trade_id);
CREATE INDEX idx_disputes_status     ON disputes(status);
CREATE INDEX idx_disputes_assigned   ON disputes(assigned_moderator_id);

-- Uploaded screenshots (Telebirr/Bank transfer proof). Hash for tamper detection.
CREATE TABLE dispute_evidence (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    dispute_id          UUID NOT NULL REFERENCES disputes(id) ON DELETE CASCADE,
    uploaded_by         UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,

    file_url            VARCHAR(500) NOT NULL,
    file_type           VARCHAR(50)  NOT NULL,         -- 'image/png' | 'image/jpeg' | 'application/pdf'
    file_size_bytes     BIGINT       NOT NULL,
    file_hash           VARCHAR(64)  NOT NULL,          -- SHA-256

    description         TEXT,

    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_dispute_evidence_dispute_id ON dispute_evidence(dispute_id);

-- =============================================================================
-- TRADE CHAT  (messages encrypted with RSA-256 per trade)
-- =============================================================================
CREATE TABLE trade_messages (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    trade_id            UUID NOT NULL REFERENCES trades(id) ON DELETE CASCADE,
    sender_id           UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,

    encrypted_content   BYTEA NOT NULL,                  -- RSA-256 ciphertext
    is_system_message   BOOLEAN NOT NULL DEFAULT FALSE,
    message_type        VARCHAR(30) NOT NULL DEFAULT 'TEXT',   -- 'TEXT' | 'SYSTEM' | 'PAYMENT_NOTIFICATION'

    read_at             TIMESTAMPTZ,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_trade_messages_trade_id ON trade_messages(trade_id, created_at);

-- =============================================================================
-- NOTIFICATIONS
-- =============================================================================
CREATE TABLE notifications (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type        notif_type NOT NULL,
    title       VARCHAR(255) NOT NULL,
    body        TEXT NOT NULL,
    data        JSONB,

    is_read     BOOLEAN NOT NULL DEFAULT FALSE,
    read_at     TIMESTAMPTZ,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_notifications_user_id ON notifications(user_id, is_read, created_at);

-- =============================================================================
-- AUDIT LOG  (source of truth for NBE compliance reporting)
-- =============================================================================
CREATE TABLE audit_logs (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    actor_id        UUID REFERENCES users(id),
    action          VARCHAR(100) NOT NULL,
    entity_type     VARCHAR(50)  NOT NULL,
    entity_id       UUID,

    old_values      JSONB,
    new_values      JSONB,

    ip_address      INET,
    user_agent      TEXT,

    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_audit_logs_actor   ON audit_logs(actor_id);
CREATE INDEX idx_audit_logs_entity  ON audit_logs(entity_type, entity_id);
CREATE INDEX idx_audit_logs_created ON audit_logs(created_at);

-- =============================================================================
-- UPDATED_AT TRIGGER  (single function reused across all tables)
-- =============================================================================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_users_updated_at           BEFORE UPDATE ON users           FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_wallets_updated_at         BEFORE UPDATE ON wallets         FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_orders_updated_at          BEFORE UPDATE ON orders          FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_trades_updated_at          BEFORE UPDATE ON trades          FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_payment_methods_updated_at BEFORE UPDATE ON payment_methods FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_disputes_updated_at        BEFORE UPDATE ON disputes        FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- =============================================================================
-- NUMERIC SANITY: prevent negative net balance via CHECK on (available + locked)
--   A wallet can never have (available + locked) < 0 — defends against double-spend
--   even if application-layer logic has a bug.
-- =============================================================================
ALTER TABLE wallets
    ADD CONSTRAINT wallet_no_negative_net_balance
    CHECK (available_balance + locked_balance >= 0);

-- =============================================================================
-- END 0001_init.sql
-- =============================================================================
