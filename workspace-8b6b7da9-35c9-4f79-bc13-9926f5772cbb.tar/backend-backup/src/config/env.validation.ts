import {
  IsEnum,
  IsNumber,
  IsString,
  IsBoolean,
  IsOptional,
  Max,
  Min,
  validateSync,
} from 'class-validator';

export enum NodeEnv {
  DEVELOPMENT = 'development',
  TEST = 'test',
  STAGING = 'staging',
  PRODUCTION = 'production',
}

/**
 * EnvironmentConfig — strongly-typed env access.
 *
 * The config module exposes a single `env` object so the rest of the codebase
 * never touches `process.env` directly. This makes everything testable and
 * gives us compile-time guarantees that every var we read actually exists.
 */
class EnvironmentConfig {
  @IsEnum(NodeEnv)
  NODE_ENV: NodeEnv = NodeEnv.DEVELOPMENT;

  @IsNumber()
  @Min(1) @Max(65535)
  PORT = 3000;

  @IsString()
  APP_NAME = 'etb-p2p-exchange';

  // Postgres
  @IsString() POSTGRES_HOST = '127.0.0.1';
  @IsNumber() POSTGRES_PORT = 5432;
  @IsString() POSTGRES_USER = 'etb_exchange';
  @IsString() POSTGRES_PASSWORD = '';
  @IsString() POSTGRES_DATABASE = 'etb_p2p_exchange';
  @IsNumber() POSTGRES_POOL_SIZE = 20;
  @IsBoolean() POSTGRES_SYNC = false;

  // Redis
  @IsString() REDIS_HOST = '127.0.0.1';
  @IsNumber() REDIS_PORT = 6379;
  @IsString() @IsOptional() REDIS_PASSWORD?: string;
  @IsNumber() REDIS_DB = 0;
  @IsString() REDIS_KEY_PREFIX = 'etb:';
  @IsNumber() REDIS_ORDERBOOK_TTL_SECONDS = 86400;

  // JWT
  @IsString() JWT_ACCESS_SECRET = '';
  @IsString() JWT_ACCESS_TTL = '15m';
  @IsString() JWT_REFRESH_SECRET = '';
  @IsString() JWT_REFRESH_TTL = '7d';
  @IsNumber() BCRYPT_ROUNDS = 12;

  // RSA
  @IsString() RSA_PRIVATE_KEY_PATH = '';
  @IsString() RSA_PUBLIC_KEY_PATH = '';

  // Business rules
  @IsNumber() DEFAULT_PAYMENT_WINDOW_MINUTES = 30;
  @IsNumber() MIN_ORDER_VALUE_ETB = 500;
  @IsNumber() MAX_ORDER_VALUE_ETB = 500000;
  @IsNumber() MAKER_FEE_BPS = 0;
  @IsNumber() TAKER_FEE_BPS = 50;
  @IsNumber() ESCROW_RELEASE_CONFIRMATIONS = 0;

  // Rate limit
  @IsNumber() RATE_LIMIT_TTL = 60;
  @IsNumber() RATE_LIMIT_LOGIN = 5;
  @IsNumber() RATE_LIMIT_ORDER_PLACE = 30;
  @IsNumber() RATE_LIMIT_API = 300;

  // S3
  @IsString() S3_ENDPOINT = '';
  @IsString() S3_REGION = 'us-east-1';
  @IsString() S3_ACCESS_KEY = '';
  @IsString() S3_SECRET_KEY = '';
  @IsString() S3_BUCKET_KYC = '';
  @IsString() S3_BUCKET_DISPUTES = '';

  // Payment providers — all optional because they're only used in Phase 2
  @IsString() @IsOptional() TELEBIRR_API_BASE?: string;
  @IsString() @IsOptional() TELEBIRR_APP_ID?: string;
  @IsString() @IsOptional() TELEBIRR_APP_KEY?: string;
  @IsString() @IsOptional() TELEBIRR_SHORT_CODE?: string;

  @IsString() @IsOptional() MPESA_API_BASE?: string;
  @IsString() @IsOptional() MPESA_CONSUMER_KEY?: string;
  @IsString() @IsOptional() MPESA_CONSUMER_SECRET?: string;
  @IsString() @IsOptional() MPESA_SHORT_CODE?: string;

  @IsString() @IsOptional() CBE_API_BASE?: string;
  @IsString() @IsOptional() CBE_CLIENT_ID?: string;
  @IsString() @IsOptional() CBE_CLIENT_SECRET?: string;

  @IsString() @IsOptional() AWASH_API_BASE?: string;
  @IsString() @IsOptional() AWASH_CLIENT_ID?: string;
  @IsString() @IsOptional() AWASH_CLIENT_SECRET?: string;

  @IsString() @IsOptional() DASHEN_API_BASE?: string;
  @IsString() @IsOptional() DASHEN_CLIENT_ID?: string;
  @IsString() @IsOptional() DASHEN_CLIENT_SECRET?: string;

  // NBE
  @IsString() @IsOptional() NBE_REPORTING_API_BASE?: string;
  @IsString() @IsOptional() NBE_REPORTING_API_KEY?: string;
  @IsString() NBE_DAILY_REPORT_CRON = '0 22 * * *';
}

export type StrictEnvironmentConfig = EnvironmentConfig;

let cached: EnvironmentConfig | null = null;

/**
 * Loads + validates env. Throws synchronously on first invalid value so the
 * app fails fast at boot instead of with cryptic errors later.
 */
export function loadEnvironment(): StrictEnvironmentConfig {
  if (cached) return cached;

  // Start from class defaults, then overlay process.env values with type coercion.
  // We do NOT use plainToInstance for this because class-transformer's
  // implicit conversion is unreliable for boolean/number fields when the
  // source is `process.env` (which is all strings | undefined).
  const instance = new EnvironmentConfig();
  const target = instance as unknown as Record<string, unknown>;
  for (const [key, value] of Object.entries(process.env)) {
    if (value === undefined) continue;
    if (!(key in target)) continue;
    const current = target[key];
    if (typeof current === 'number') {
      const n = Number(value);
      if (!Number.isFinite(n)) continue; // skip non-numeric env values
      target[key] = n;
    } else if (typeof current === 'boolean') {
      target[key] = value === 'true' || value === '1';
    } else {
      target[key] = value;
    }
  }

  const errors = validateSync(instance, { skipMissingProperties: false });
  if (errors.length > 0) {
    const messages = errors
      .map((e) => `  - ${e.property}: ${Object.values(e.constraints ?? {}).join(', ')}`)
      .join('\n');
    throw new Error(`Invalid environment configuration:\n${messages}`);
  }

  cached = instance;
  return cached;
}

export function getEnv(): StrictEnvironmentConfig {
  if (!cached) loadEnvironment();
  return cached as StrictEnvironmentConfig;
}

/**
 * TEST-ONLY: clears the env cache so the next `getEnv()` call re-reads
 * `process.env`. NEVER call this in production code.
 */
export function _resetEnvCacheForTesting(): void {
  cached = null;
}
