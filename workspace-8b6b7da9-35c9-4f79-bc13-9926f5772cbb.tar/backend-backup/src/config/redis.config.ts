import type { RedisOptions } from 'ioredis';
import { getEnv } from './env.validation';

/**
 * Redis config — single shared client factory.
 *
 * ioredis is used (not node-redis) because we need:
 *   - Cluster support for horizontal scaling
 *   - Lua script eval caching (the orderbook places orders atomically via Lua)
 *   - Pipelining for batched sorted-set ops
 */
export function buildRedisConfig(): RedisOptions {
  const env = getEnv();
  return {
    host: env.REDIS_HOST,
    port: env.REDIS_PORT,
    password: env.REDIS_PASSWORD || undefined,
    db: env.REDIS_DB,
    keyPrefix: env.REDIS_KEY_PREFIX,
    enableReadyCheck: true,
    maxRetriesPerRequest: 3,
    lazyConnect: false,
    retryStrategy: (times: number): number => Math.min(times * 200, 2000),
    reconnectOnError: (err: Error): boolean => {
      // READONLY = cluster failover; reconnect.
      return err.message.includes('READONLY');
    },
  };
}

/** Redis key namespace helpers — every key the orderbook touches lives here. */
export const RedisKeys = {
  /** Sorted set of SELL orders for a pair, scored by (price, createdAt). */
  sellBook: (pair: string): string => `orderbook:sell:${pair}`,
  /** Sorted set of BUY orders for a pair, scored by (-price, createdAt). */
  buyBook: (pair: string): string => `orderbook:buy:${pair}`,
  /** Hash of order metadata (id → {price, qty, userId}) for O(1) lookup. */
  orderMeta: (pair: string): string => `orderbook:meta:${pair}`,
  /** Per-user lock preventing two concurrent order placements. */
  userOrderLock: (userId: string): string => `lock:user-order:${userId}`,
  /** Distributed lock for a specific pair's matching pass. */
  pairMatchLock: (pair: string): string => `lock:pair-match:${pair}`,
  /** WebSocket session map (userId → Set<sessionId>) for fan-out. */
  wsSessions: (userId: string): string => `ws:sessions:${userId}`,
} as const;
