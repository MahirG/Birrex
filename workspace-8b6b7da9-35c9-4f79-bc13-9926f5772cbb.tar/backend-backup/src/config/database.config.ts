import { TypeOrmModuleOptions } from '@nestjs/typeorm';
import { getEnv } from './env.validation';
import { ENTITIES } from '../database/entities';

/**
 * TypeORM config — Postgres with a pooled driver.
 *
 * `synchronize` is FORBIDDEN in production; migrations own schema changes.
 * Read-replica routing is intentionally omitted from Phase 1; the matching
 * engine reads from Redis so DB load stays low.
 */
export function buildTypeOrmConfig(): TypeOrmModuleOptions {
  const env = getEnv();
  return {
    type: 'postgres',
    host: env.POSTGRES_HOST,
    port: env.POSTGRES_PORT,
    username: env.POSTGRES_USER,
    password: env.POSTGRES_PASSWORD,
    database: env.POSTGRES_DATABASE,
    entities: [...ENTITIES],
    synchronize: env.POSTGRES_SYNC, // dev-only — migrations own schema in prod
    extra: {
      poolSize: env.POSTGRES_POOL_SIZE,
      connectionTimeoutMillis: 5000,
    },
    logging: env.NODE_ENV === 'development' ? ['error', 'warn'] : ['error'],
  };
}
