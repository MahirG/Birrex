// Config barrel — single import surface for the rest of the codebase.
// Re-exports everything that other modules need from the config layer.

export {
  loadEnvironment,
  getEnv,
  NodeEnv,
  type StrictEnvironmentConfig,
  _resetEnvCacheForTesting,
} from './env.validation';

export { buildTypeOrmConfig } from './database.config';
export { buildRedisConfig, RedisKeys } from './redis.config';
