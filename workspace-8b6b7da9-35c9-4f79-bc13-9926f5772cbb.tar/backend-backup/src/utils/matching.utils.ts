import type { TradingPair } from '../types/orderbook.types';
import type { OrderSide } from '../database/entities';

/**
 * Pure-function helpers for the matching engine.
 * Keeping these in a separate file makes them trivially unit-testable.
 */

/**
 * Redis sorted-set score for a resting order.
 *
 * For SELL orders: score = price * 1e8 + (createdAt / 1000)
 *   (cheaper price first, then FIFO at same price)
 *
 * For BUY orders: score = (-price * 1e8) + (createdAt / 1000)
 *   (highest price first, then FIFO at same price)
 *
 * The 1e8 multiplier preserves 8-decimal precision (matches DB NUMERIC(20,8)).
 * createdAt is in seconds (4-digit years fit comfortably in float64).
 */
const PRICE_SCALE = 1e8;

export function computeOrderScore(
  side: OrderSide,
  price: string,
  createdAtMs: number,
): number {
  const priceNum = Number(price);
  if (!Number.isFinite(priceNum) || priceNum <= 0) {
    throw new Error(`Invalid price for score: ${price}`);
  }
  const scaledPrice = priceNum * PRICE_SCALE;
  const ts = createdAtMs / 1000;
  return side === 'SELL' ? scaledPrice + ts : -scaledPrice + ts;
}

/**
 * Does `takerSide` BUY match `makerSide` SELL at the given prices?
 * Yes, iff takerPrice >= makerPrice (buyer willing to pay at least the ask).
 *
 * Does `takerSide` SELL match `makerSide` BUY?
 * Yes, iff takerPrice <= makerPrice (seller willing to accept at most the bid).
 */
export function pricesCross(
  takerSide: OrderSide,
  takerPrice: string,
  makerPrice: string,
): boolean {
  const t = Number(takerPrice);
  const m = Number(makerPrice);
  if (!Number.isFinite(t) || !Number.isFinite(m)) return false;
  return takerSide === 'BUY' ? t >= m : t <= m;
}

/**
 * The execution price when a taker crosses a maker.
 *
 * Per standard exchange convention (price-time priority), the trade executes
 * at the MAKER's price — the maker was there first, so they get to keep their
 * quoted price. The taker pays/receives whatever the maker advertised.
 */
export function executionPrice(makerPrice: string): string {
  const n = Number(makerPrice);
  if (!Number.isFinite(n) || n <= 0) {
    throw new Error(`Invalid maker price: ${makerPrice}`);
  }
  return makerPrice;
}

/**
 * Subtracts bignum-style decimal strings without floating-point error.
 * Both inputs MUST be valid decimal strings (may be negative).
 * Returns a decimal string (no leading zeros, may be negative).
 *
 * Implementation: convert both to BigInt at a common scale, subtract, reformat.
 */
export function subtractDecimal(a: string, b: string): string {
  const aScale = (a.split('.')[1] ?? '').length;
  const bScale = (b.split('.')[1] ?? '').length;
  const scale = Math.max(aScale, bScale);
  const aBig = toScaledBigInt(a, scale);
  const bBig = toScaledBigInt(b, scale);
  const result = aBig - bBig;

  const sign = result < 0n ? '-' : '';
  const absResult = result < 0n ? -result : result;
  const absStr = absResult.toString().padStart(scale + 1, '0');

  if (scale === 0) return sign + absStr;
  const intPart = absStr.slice(0, -scale) || '0';
  const fracPart = absStr.slice(-scale);
  return `${sign}${intPart}.${fracPart}`.replace(/\.?0+$/, '') || '0';
}

/**
 * Adds two decimal strings (same approach as subtractDecimal).
 */
export function addDecimal(a: string, b: string): string {
  return subtractDecimal(a, negate(b));
}

function negate(s: string): string {
  if (s === '0') return '0';
  return s.startsWith('-') ? s.slice(1) : '-' + s;
}

/**
 * Multiplies two decimal strings using BigInt on the scaled integer representation.
 * Preserves precision; useful for computing total_value = price * quantity.
 */
export function multiplyDecimal(a: string, b: string): string {
  const aScale = (a.split('.')[1] ?? '').length;
  const bScale = (b.split('.')[1] ?? '').length;
  const scale = aScale + bScale;
  const aInt = BigInt(a.replace('.', ''));
  const bInt = BigInt(b.replace('.', ''));
  const product = aInt * bInt;
  const sign = product < 0n ? '-' : '';
  const absStr = (product < 0n ? -product : product)
    .toString()
    .padStart(scale + 1, '0');
  if (scale === 0) return sign + absStr;
  const intPart = absStr.slice(0, -scale) || '0';
  const fracPart = absStr.slice(-scale);
  return `${sign}${intPart}.${fracPart}`.replace(/\.?0+$/, '') || '0';
}

/**
 * True if `a` < `b`, comparing decimal strings without float error.
 */
export function lessThan(a: string, b: string): boolean {
  const aScale = (a.split('.')[1] ?? '').length;
  const bScale = (b.split('.')[1] ?? '').length;
  const scale = Math.max(aScale, bScale);
  const aBig = toScaledBigInt(a, scale);
  const bBig = toScaledBigInt(b, scale);
  return aBig < bBig;
}

/**
 * Converts a decimal string to a BigInt at the given scale (number of
 * fractional digits). Handles negatives and missing fractional parts.
 *
 * Example: toScaledBigInt('100', 8) = 10_000_000_000n  (i.e. 100 * 10^8)
 *          toScaledBigInt('99.99999999', 8) = 9_999_999_999n
 */
function toScaledBigInt(s: string, scale: number): bigint {
  const negative = s.startsWith('-');
  const abs = negative ? s.slice(1) : s;
  const dotIdx = abs.indexOf('.');
  const intPart = dotIdx === -1 ? abs : abs.slice(0, dotIdx);
  const fracPart = dotIdx === -1 ? '' : abs.slice(dotIdx + 1);
  // Pad fractional part to exactly `scale` digits (truncating if longer).
  const paddedFrac = fracPart.padEnd(scale, '0').slice(0, scale);
  const combined = (intPart || '0') + paddedFrac;
  const big = BigInt(combined || '0');
  return negative ? -big : big;
}

/**
 * Generates the human-readable trade number: TRD-YYYYMMDD-XXXXX
 * where XXXXX is a zero-padded per-day counter (resets at midnight UTC).
 */
export function formatTradeNumber(date: Date, dailyCounter: number): string {
  const ymd = date.toISOString().slice(0, 10).replaceAll('-', '');
  const seq = String(dailyCounter).padStart(5, '0');
  return `TRD-${ymd}-${seq}`;
}

export function isValidPair(pair: string): pair is TradingPair {
  return pair === 'USD_ETB' || pair === 'USDT_ETB';
}
