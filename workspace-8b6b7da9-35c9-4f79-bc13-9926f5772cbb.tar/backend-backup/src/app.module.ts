import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ThrottlerModule, ThrottlerGuard } from '@nestjs/throttler';
import { ScheduleModule } from '@nestjs/schedule';
import { APP_FILTER, APP_GUARD, APP_INTERCEPTOR } from '@nestjs/core';

import { loadEnvironment } from './config';
import { buildTypeOrmConfig } from './config';
import { getEnv } from './config';

import { AllExceptionsFilter } from './common/exceptions/all-exceptions.filter';
import { LoggingInterceptor } from './common/interceptors/logging.interceptor';

import { I18nModule } from './modules/i18n/i18n.module';
import { OrderbookModule } from './modules/orderbook/orderbook.module';
import { EscrowModule } from './modules/escrow/escrow.module';
import { WebSocketModule } from './modules/websocket/websocket.module';
import { MatchingEngineModule } from './modules/matching-engine/matching-engine.module';
import { AuthModule } from './modules/auth/auth.module';
import { WalletsModule } from './modules/wallets/wallets.module';
import { KycModule } from './modules/kyc/kyc.module';
import { DisputesModule } from './modules/disputes/disputes.module';
import { PaymentsModule } from './modules/payments/payments.module';
import { NbeComplianceModule } from './modules/nbe-compliance/nbe-compliance.module';

/**
 * AppModule — root composition.
 *
 * Global providers registered here:
 *   - AllExceptionsFilter (catches every exception + standardizes the response envelope)
 *   - LoggingInterceptor  (attaches traceId + emits structured logs)
 *   - ThrottlerGuard      (rate-limits every endpoint by default)
 *
 * ThrottlerModule is configured with two throttlers:
 *   - Default: 300 req / 60s per IP (general API)
 *   - Tighter per-route limits are added via @Throttle() on sensitive endpoints
 *     (login, place-order) — see their respective controllers.
 */
@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      validate: () => loadEnvironment(),
    }),
    TypeOrmModule.forRoot(buildTypeOrmConfig()),
    ThrottlerModule.forRoot([
      { name: 'default', ttl: 60_000, limit: () => getEnv().RATE_LIMIT_API },
    ]),
    ScheduleModule.forRoot(),

    I18nModule,
    OrderbookModule,
    EscrowModule,
    WebSocketModule,
    MatchingEngineModule,
    AuthModule,
    WalletsModule,
    KycModule,
    DisputesModule,
    PaymentsModule,
    NbeComplianceModule,
  ],
  providers: [
    { provide: APP_FILTER, useClass: AllExceptionsFilter },
    { provide: APP_INTERCEPTOR, useClass: LoggingInterceptor },
    { provide: APP_GUARD, useClass: ThrottlerGuard },
  ],
})
export class AppModule {}
