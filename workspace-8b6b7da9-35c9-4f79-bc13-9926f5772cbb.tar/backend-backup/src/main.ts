import { NestFactory } from '@nestjs/core';
import { ValidationPipe, Logger } from '@nestjs/common';
import helmet from 'helmet';
import compression from 'compression';
import { AppModule } from './app.module';
import { getEnv } from './config';
import { OrderbookService } from './modules/orderbook/orderbook.service';

/**
 * Boot sequence:
 *   1. Validate env (loadEnvironment() runs once inside ConfigModule.forRoot).
 *   2. Create the Nest app with a global ValidationPipe that:
 *        - Strips unknown properties (whitelist)
 *        - Rejects requests with validation errors (forbidNonWhitelisted)
 *        - Auto-transforms payloads to their DTO types
 *   3. Helmet for security headers + compression for bandwidth.
 *   4. CORS for the Next.js frontend + mobile clients.
 *   5. On startup, rebuild the Redis orderbook from Postgres so we recover
 *      gracefully from a Redis flush or app restart.
 *   6. Listen on the configured PORT.
 *
 * The app is fully stateless — horizontal scaling is achieved by running
 * N instances behind a load balancer with sticky WebSocket sessions
 * (Socket.io's Redis adapter handles cross-instance fan-out).
 */
async function bootstrap(): Promise<void> {
  const env = getEnv();
  const logger = new Logger('Bootstrap');

  const app = await NestFactory.create(AppModule, {
    bufferLogs: true,
    cors: {
      origin: env.NODE_ENV === 'production' ? false : true,
      credentials: true,
    },
  });

  app.use(helmet());
  app.use(compression());

  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,           // strip unknown properties
      forbidNonWhitelisted: true, // 400 if unknown props are present
      transform: true,           // auto-convert payloads to DTO instances
      transformOptions: { enableImplicitConversion: true },
    }),
  );

  app.setGlobalPrefix('api');

  // Rebuild the orderbook cache from Postgres on startup.
  // This is idempotent and safe to run on every boot.
  try {
    const orderbook = app.get(OrderbookService);
    const result = await orderbook.rebuildFromDatabase();
    logger.log(`Orderbook rebuilt: ${result.orders} orders across ${result.pairs} pairs`);
  } catch (err) {
    logger.error(`Failed to rebuild orderbook: ${(err as Error).message}`);
    // Continue booting — the matching engine will lazily repopulate the book
    // as users place new orders. We log the failure loudly for ops to investigate.
  }

  await app.listen(env.PORT);
  logger.log(`🚀 ETB/USD P2P Exchange listening on http://0.0.0.0:${env.PORT}`);
  logger.log(`   Environment: ${env.NODE_ENV}`);
  logger.log(`   Pair support: USD_ETB, USDT_ETB`);
  logger.log(`   Default payment window: ${env.DEFAULT_PAYMENT_WINDOW_MINUTES} min`);
  logger.log(`   Min/Max order value: ${env.MIN_ORDER_VALUE_ETB} / ${env.MAX_ORDER_VALUE_ETB} ETB`);
}

bootstrap().catch((err: unknown) => {
  // eslint-disable-next-line no-console
  console.error('Fatal boot error:', err);
  process.exit(1);
});
