import { Injectable, OnModuleInit } from '@nestjs/common';
import { readFileSync } from 'fs';
import {
  createPrivateKey,
  createPublicKey,
  constants,
  publicEncrypt,
  privateDecrypt,
  randomBytes,
  createCipheriv,
  createDecipheriv,
  type KeyObject,
} from 'crypto';
import { getEnv } from '../config';

/**
 * CryptoService — RSA-256 / AES-256 helpers for PII at rest.
 *
 * Use cases:
 *   - Encrypt TOTP secrets before writing to users.totp_secret_encrypted
 *   - Encrypt bank account numbers before writing to payment_methods
 *   - Encrypt KYC document numbers
 *   - Encrypt trade chat messages
 *
 * Strategy: hybrid encryption.
 *   - Generate a random 256-bit AES key per record.
 *   - Encrypt the payload with AES-256-GCM (handles arbitrary length).
 *   - Encrypt the AES key with RSA-OAEP-256 (2048-bit RSA).
 *   - Store: iv (12B) || ciphertext || tag (16B) || wrappedKey (256B).
 *
 * This pattern avoids RSA's 190-byte payload limit while keeping the
 * per-record cost of RSA operations to a single encryption.
 */
interface EncryptedBlob {
  /** 12-byte initialization vector (base64) */
  iv: string;
  /** ciphertext (base64) */
  ciphertext: string;
  /** 16-byte GCM auth tag (base64) */
  tag: string;
  /** RSA-OAEP-wrapped AES key (base64) */
  wrappedKey: string;
}

@Injectable()
export class CryptoService implements OnModuleInit {
  private privateKey!: KeyObject;
  private publicKey!: KeyObject;

  onModuleInit(): void {
    const env = getEnv();
    if (!env.RSA_PRIVATE_KEY_PATH || !env.RSA_PUBLIC_KEY_PATH) {
      // For tests, allow lazy init. Production boot will fail when keys are needed.
      return;
    }
    this.loadKeys(env.RSA_PRIVATE_KEY_PATH, env.RSA_PUBLIC_KEY_PATH);
  }

  /** Test-only hook to inject in-memory keys. */
  loadKeys(privateKeyPath: string, publicKeyPath: string): void {
    this.privateKey = createPrivateKey({
      key: readFileSync(privateKeyPath),
      format: 'pem',
      type: 'pkcs8',
    });
    this.publicKey = createPublicKey({
      key: readFileSync(publicKeyPath),
      format: 'pem',
      type: 'spki',
    });
  }

  /**
   * Encrypts a UTF-8 string into a single Buffer ready for a BYTEA column.
   * Format: iv(12) || tag(16) || wrappedKey(256) || ciphertext
   */
  encrypt(plaintext: string): Buffer {
    if (!this.publicKey) {
      throw new Error('CryptoService.publicKey not initialized');
    }
    // AES-256 key + GCM IV.
    const aesKey = randomBytes(32);
    const iv = randomBytes(12);

    // AES-256-GCM cipher.
    const cipher = createCipheriv('aes-256-gcm', aesKey, iv);
    const ct = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
    const tag = cipher.getAuthTag();

    // Wrap AES key with RSA-OAEP-SHA256.
    // NOTE: `publicEncrypt` with RSA-OAEP encrypts using the public key,
    // which is what we want — anyone can encrypt, only the holder of the
    // private key can decrypt.
    const wrappedKey = publicEncrypt(
      {
        key: this.publicKey,
        padding: constants.RSA_PKCS1_OAEP_PADDING,
        oaepHash: 'sha256',
      },
      aesKey,
    );

    // Layout: iv || tag || wrappedKey || ciphertext
    return Buffer.concat([iv, tag, wrappedKey, ct]);
  }

  /**
   * Decrypts a Buffer produced by `encrypt()`. Returns UTF-8 string.
   */
  decrypt(blob: Buffer): string {
    if (!this.privateKey) {
      throw new Error('CryptoService.privateKey not initialized');
    }
    if (blob.length < 12 + 16 + 256) {
      throw new Error('Encrypted blob too short');
    }
    const iv = blob.subarray(0, 12);
    const tag = blob.subarray(12, 28);
    const wrappedKey = blob.subarray(28, 28 + 256);
    const ct = blob.subarray(28 + 256);

    // Unwrap AES key with RSA-OAEP-SHA256.
    // `privateDecrypt` is the inverse of `publicEncrypt`.
    const aesKey = privateDecrypt(
      {
        key: this.privateKey,
        padding: constants.RSA_PKCS1_OAEP_PADDING,
        oaepHash: 'sha256',
      },
      wrappedKey,
    );

    const decipher = createDecipheriv('aes-256-gcm', aesKey, iv);
    decipher.setAuthTag(tag);
    const pt = Buffer.concat([decipher.update(ct), decipher.final()]);
    return pt.toString('utf8');
  }

  /**
   * Convenience helper for tests / debugging — serializes to JSON fields.
   */
  encryptToJson(plaintext: string): EncryptedBlob {
    const buf = this.encrypt(plaintext);
    const iv = buf.subarray(0, 12).toString('base64');
    const tag = buf.subarray(12, 28).toString('base64');
    const wrappedKey = buf.subarray(28, 28 + 256).toString('base64');
    const ciphertext = buf.subarray(28 + 256).toString('base64');
    return { iv, ciphertext, tag, wrappedKey };
  }
}
