import { createParamDecorator, ExecutionContext } from '@nestjs/common';

/**
 * Authenticated user payload attached to `request.user` by JwtAuthGuard.
 * Keep this strict — never expose password_hash or totp_secret here.
 */
export interface AuthUser {
  id: string;
  email: string;
  role: string;
  kycStatus: string;
}

export const CurrentUser = createParamDecorator(
  (data: keyof AuthUser | undefined, ctx: ExecutionContext): AuthUser | unknown => {
    const request = ctx.switchToHttp().getRequest<{ user?: AuthUser }>();
    const user = request.user;
    if (!user) {
      // This should never happen — JwtAuthGuard must run first.
      return undefined;
    }
    return data ? user[data] : user;
  },
);
