import { SetMetadata } from '@nestjs/common';
import { UserRole } from '../../database/entities';

export const ROLES_KEY = 'roles';

/**
 * @Roles(...) — attach the required roles to a route. Combine with RolesGuard.
 *
 * Example:
 *   @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN)
 *   @UseGuards(JwtAuthGuard, RolesGuard)
 */
export const Roles = (...roles: UserRole[]): MethodDecorator & ClassDecorator =>
  SetMetadata(ROLES_KEY, roles) as MethodDecorator & ClassDecorator;
