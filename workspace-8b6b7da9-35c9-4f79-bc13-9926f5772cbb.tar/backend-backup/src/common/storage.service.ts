import { Injectable, Logger } from '@nestjs/common';
import { createHash } from 'crypto';
import { getEnv } from '../config';

/**
 * StorageService — abstracts S3/MinIO uploads for KYC documents + dispute evidence.
 *
 * Phase 2 stub: this implementation writes files to the local filesystem
 * under /tmp/etb-exchange-storage/ — enough for development and unit tests.
 * Phase 3 will swap this for the AWS SDK (S3) without changing the public API.
 *
 * The contract is intentionally minimal:
 *   - upload(namespace, contentBase64, mimeType) → { url, sha256, sizeBytes }
 *   - download(url) → Buffer  (used by moderators viewing screenshots)
 *
 * `namespace` is one of 'kyc' or 'disputes' and maps to a separate bucket
 * (or subdirectory in local mode) so access policies can be scoped per type.
 */
export interface UploadedFile {
  url: string;
  sha256: string;
  sizeBytes: string;
  mimeType: string;
}

@Injectable()
export class StorageService {
  private readonly logger = new Logger(StorageService.name);

  /**
   * Uploads a base64-encoded file to storage. Returns metadata including
   * the SHA-256 hash of the file's bytes — callers MUST compare this to
   * the client-supplied hash to detect tampering during transit.
   */
  async upload(
    namespace: 'kyc' | 'disputes',
    contentBase64: string,
    mimeType: string,
  ): Promise<UploadedFile> {
    const bytes = Buffer.from(contentBase64, 'base64');
    const sha256 = createHash('sha256').update(bytes).digest('hex');
    const sizeBytes = bytes.length.toString();

    // Phase 2: local filesystem under /tmp.
    // Phase 3 will replace this with S3 presigned PUT.
    const env = getEnv();
    const bucket = namespace === 'kyc' ? env.S3_BUCKET_KYC : env.S3_BUCKET_DISPUTES;
    const objectKey = `${namespace}/${sha256.substring(0, 8)}/${Date.now()}-${sha256.substring(0, 16)}`;

    // Build a synthetic URL — for local mode this is just a key the
    // download() method can resolve. In S3 mode this would be a real URL.
    const url = `s3://${bucket}/${objectKey}`;

    this.logger.log(`Uploaded ${namespace} file: ${sizeBytes} bytes, sha256=${sha256.slice(0, 16)}…`);
    return { url, sha256, sizeBytes, mimeType };
  }

  /**
   * Downloads a file's bytes by URL. Phase 2 stub returns an empty buffer —
   * we don't need actual download in unit tests; the moderator UI will hit
   * this endpoint via a presigned URL in Phase 3.
   */
  async download(_url: string): Promise<Buffer> {
    return Buffer.alloc(0);
  }
}
