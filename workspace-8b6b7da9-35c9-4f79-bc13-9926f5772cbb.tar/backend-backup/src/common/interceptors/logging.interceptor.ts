import {
  CallHandler,
  ExecutionContext,
  Injectable,
  NestInterceptor,
  Logger,
} from '@nestjs/common';
import { Observable, tap } from 'rxjs';
import { randomUUID } from 'crypto';

interface TrackedRequest extends Record<string, unknown> {
  method: string;
  url: string;
  ip: string;
  headers: Record<string, string | undefined>;
  traceId?: string;
}

/**
 * LoggingInterceptor — attaches a per-request traceId and emits a single
 * structured log line per HTTP request. Pairs with AllExceptionsFilter so
 * the same traceId flows through both success and error paths.
 */
@Injectable()
export class LoggingInterceptor implements NestInterceptor {
  private readonly logger = new Logger('HTTP');

  intercept(ctx: ExecutionContext, next: CallHandler): Observable<unknown> {
    const request = ctx.switchToHttp().getRequest<TrackedRequest>();
    const traceId = (request.headers['x-trace-id'] as string | undefined) ?? randomUUID();
    request.traceId = traceId;

    const { method, url, ip } = request;
    const start = Date.now();

    return next.handle().pipe(
      tap({
        next: () => {
          const duration = Date.now() - start;
          this.logger.log(`[${traceId}] ${method} ${url} ${ip} → ${duration}ms`);
        },
        error: () => {
          const duration = Date.now() - start;
          this.logger.warn(`[${traceId}] ${method} ${url} ${ip} → failed after ${duration}ms`);
        },
      }),
    );
  }
}
