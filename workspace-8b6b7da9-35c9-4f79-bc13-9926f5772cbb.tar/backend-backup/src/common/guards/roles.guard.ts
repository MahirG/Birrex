import {
  Injectable,
  CanActivate,
  ExecutionContext,
  ForbiddenException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { ROLES_KEY } from '../decorators/roles.decorator';
import { UserRole } from '../../database/entities';
import { BusinessException, ErrorCode } from '../exceptions/business.exception';
import type { AuthUser } from '../decorators/current-user.decorator';

/**
 * RolesGuard — must be placed AFTER JwtAuthGuard so request.user is populated.
 * Returns true if the user has at least one of the roles allowed by @Roles().
 */
@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}

  canActivate(ctx: ExecutionContext): boolean {
    const required = this.reflector.getAllAndOverride<UserRole[]>(ROLES_KEY, [
      ctx.getHandler(),
      ctx.getClass(),
    ]);

    if (!required || required.length === 0) {
      return true;
    }

    const request = ctx.switchToHttp().getRequest<{ user?: AuthUser }>();
    const user = request.user;
    if (!user) {
      throw new BusinessException(ErrorCode.UNAUTHORIZED, 'Authentication required');
    }

    const hasRole = required.includes(user.role as UserRole);
    if (!hasRole) {
      throw new ForbiddenException('Insufficient role for this action');
    }
    return true;
  }
}
