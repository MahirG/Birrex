import {
  Injectable,
  CanActivate,
  ExecutionContext,
  UnauthorizedException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import type { AuthUser } from '../decorators/current-user.decorator';
import { BusinessException, ErrorCode } from '../exceptions/business.exception';

interface JwtPayload extends AuthUser {
  iat?: number;
  exp?: number;
}

interface GuardedRequest extends Record<string, unknown> {
  headers: Record<string, string | undefined>;
  user?: AuthUser;
}

/**
 * JwtAuthGuard — validates the `Authorization: Bearer <token>` header.
 *
 * Stateless by design: it only validates the JWT signature and expiration.
 * Session revocation / refresh-token rotation is handled by the Auth module.
 *
 * On success, attaches the decoded payload to `request.user` for downstream
 * guards (@Roles) and the @CurrentUser() decorator.
 */
@Injectable()
export class JwtAuthGuard implements CanActivate {
  constructor(private readonly jwtService: JwtService) {}

  async canActivate(ctx: ExecutionContext): Promise<boolean> {
    const request = ctx.switchToHttp().getRequest<GuardedRequest>();
    const header = request.headers?.['authorization'];
    if (!header || !header.startsWith('Bearer ')) {
      throw new BusinessException(ErrorCode.UNAUTHORIZED, 'Missing Bearer token');
    }

    const token = header.slice('Bearer '.length).trim();
    try {
      const payload = await this.jwtService.verifyAsync<JwtPayload>(token);
      if (!payload || !payload.id) {
        throw new BusinessException(ErrorCode.INVALID_TOKEN, 'Invalid token payload');
      }
      request.user = {
        id: payload.id,
        email: payload.email,
        role: payload.role,
        kycStatus: payload.kycStatus,
      };
      return true;
    } catch (err) {
      if (err instanceof BusinessException) throw err;
      // JwtService throws an Error on expired/invalid signature
      throw new UnauthorizedException('Token expired or invalid');
    }
  }
}
