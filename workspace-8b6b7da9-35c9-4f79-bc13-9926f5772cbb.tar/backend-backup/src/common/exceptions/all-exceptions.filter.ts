import {
  ArgumentsHost,
  Catch,
  ExceptionFilter,
  HttpException,
  HttpStatus,
  Logger,
} from '@nestjs/common';
import { Response } from 'express';
import { randomUUID } from 'crypto';
import { BusinessException, ErrorCode, type ApiExceptionPayload } from './business.exception';

interface SafeRequest {
  method: string;
  url: string;
  ip: string;
  headers: Record<string, string | undefined>;
  user?: { id?: string };
  body?: unknown;
}

/**
 * AllExceptionsFilter — the single catch-all error translator.
 *
 * Behavior:
 *  1. BusinessException → preserve errorCode + details, attach traceId.
 *  2. HttpException     → translate to our standard envelope.
 *  3. Everything else   → log full stack, return INTERNAL_ERROR with traceId
 *                          so support can grep logs without leaking internals.
 *
 * The traceId is echoed back to the client AND logged so the support team
 * can pivot from "the user got error X with trace Y" to "here is the stack".
 */
@Catch()
export class AllExceptionsFilter implements ExceptionFilter {
  private readonly logger = new Logger(AllExceptionsFilter.name);

  catch(exception: unknown, host: ArgumentsHost): void {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();
    const request = ctx.getRequest<SafeRequest>();
    const traceId = randomUUID();

    let status: number;
    let payload: ApiExceptionPayload;

    if (exception instanceof BusinessException) {
      status = exception.getStatus();
      const original = exception.getResponse() as ApiExceptionPayload;
      payload = {
        errorCode: original.errorCode,
        message: original.message,
        details: original.details,
        traceId,
      };
      this.logger.warn(
        `[${traceId}] BusinessException ${payload.errorCode}: ${payload.message}`,
        exception.stack,
      );
    } else if (exception instanceof HttpException) {
      status = exception.getStatus();
      const original = exception.getResponse();
      const message =
        typeof original === 'string'
          ? original
          : (original as { message?: string | string[] }).message instanceof Array
            ? ((original as { message: string[] }).message[0] ?? exception.message)
            : (exception.message ?? 'HTTP error');
      payload = {
        errorCode: ErrorCode.BAD_REQUEST,
        message,
        traceId,
      };
      this.logger.warn(`[${traceId}] HttpException ${status}: ${message}`);
    } else {
      // Unknown / system error — never leak internals to the client.
      status = HttpStatus.INTERNAL_SERVER_ERROR;
      payload = {
        errorCode: ErrorCode.INTERNAL_ERROR,
        message: 'An unexpected error occurred. Please contact support with the traceId.',
        traceId,
      };
      this.logger.error(
        `[${traceId}] Unhandled exception on ${request.method} ${request.url}`,
        exception instanceof Error ? exception.stack : String(exception),
      );
    }

    response.status(status).json(payload);
  }
}
