import { HttpException, HttpStatus } from '@nestjs/common';

/**
 * Error codes used both in the API response payload and in the audit log.
 * Adding a new code? Update `ERROR_CODE_HTTP_STATUS` below so the global
 * exception filter can map it to the correct HTTP status.
 */
export enum ErrorCode {
  // Generic
  INTERNAL_ERROR = 'INTERNAL_ERROR',
  BAD_REQUEST = 'BAD_REQUEST',
  UNAUTHORIZED = 'UNAUTHORIZED',
  FORBIDDEN = 'FORBIDDEN',
  NOT_FOUND = 'NOT_FOUND',
  CONFLICT = 'CONFLICT',
  RATE_LIMITED = 'RATE_LIMITED',
  SERVICE_UNAVAILABLE = 'SERVICE_UNAVAILABLE',

  // Auth
  INVALID_CREDENTIALS = 'INVALID_CREDENTIALS',
  ACCOUNT_LOCKED = 'ACCOUNT_LOCKED',
  ACCOUNT_NOT_ACTIVE = 'ACCOUNT_NOT_ACTIVE',
  INVALID_2FA_CODE = 'INVALID_2FA_CODE',
  INVALID_TOKEN = 'INVALID_TOKEN',
  TOKEN_EXPIRED = 'TOKEN_EXPIRED',

  // KYC
  KYC_NOT_VERIFIED = 'KYC_NOT_VERIFIED',
  KYC_ALREADY_SUBMITTED = 'KYC_ALREADY_SUBMITTED',

  // Wallet
  INSUFFICIENT_BALANCE = 'INSUFFICIENT_BALANCE',
  INSUFFICIENT_LOCKED_BALANCE = 'INSUFFICIENT_LOCKED_BALANCE',
  WALLET_NOT_FOUND = 'WALLET_NOT_FOUND',
  INVALID_CURRENCY = 'INVALID_CURRENCY',

  // Orderbook / matching
  INVALID_ORDER_PRICE = 'INVALID_ORDER_PRICE',
  INVALID_ORDER_QUANTITY = 'INVALID_ORDER_QUANTITY',
  ORDER_BELOW_MIN_VALUE = 'ORDER_BELOW_MIN_VALUE',
  ORDER_ABOVE_MAX_VALUE = 'ORDER_ABOVE_MAX_VALUE',
  ORDER_NOT_FOUND = 'ORDER_NOT_FOUND',
  ORDER_NOT_CANCELLABLE = 'ORDER_NOT_CANCELLABLE',
  SELF_MATCH_FORBIDDEN = 'SELF_MATCH_FORBIDDEN',
  INVALID_PAIR = 'INVALID_PAIR',

  // Trade / escrow
  TRADE_NOT_FOUND = 'TRADE_NOT_FOUND',
  INVALID_TRADE_STATE_TRANSITION = 'INVALID_TRADE_STATE_TRANSITION',
  PAYMENT_WINDOW_EXPIRED = 'PAYMENT_WINDOW_EXPIRED',
  ESCROW_LOCK_FAILED = 'ESCROW_LOCK_FAILED',
  ESCROW_RELEASE_FAILED = 'ESCROW_RELEASE_FAILED',

  // Payment method
  PAYMENT_METHOD_NOT_FOUND = 'PAYMENT_METHOD_NOT_FOUND',
  PAYMENT_METHOD_NOT_VERIFIED = 'PAYMENT_METHOD_NOT_VERIFIED',

  // Dispute
  DISPUTE_NOT_FOUND = 'DISPUTE_NOT_FOUND',
  DISPUTE_ALREADY_OPEN = 'DISPUTE_ALREADY_OPEN',
  DISPUTE_ALREADY_RESOLVED = 'DISPUTE_ALREADY_RESOLVED',
}

const ERROR_CODE_HTTP_STATUS: Readonly<Record<ErrorCode, HttpStatus>> = {
  [ErrorCode.INTERNAL_ERROR]:                  HttpStatus.INTERNAL_SERVER_ERROR,
  [ErrorCode.BAD_REQUEST]:                     HttpStatus.BAD_REQUEST,
  [ErrorCode.UNAUTHORIZED]:                    HttpStatus.UNAUTHORIZED,
  [ErrorCode.FORBIDDEN]:                       HttpStatus.FORBIDDEN,
  [ErrorCode.NOT_FOUND]:                       HttpStatus.NOT_FOUND,
  [ErrorCode.CONFLICT]:                        HttpStatus.CONFLICT,
  [ErrorCode.RATE_LIMITED]:                    HttpStatus.TOO_MANY_REQUESTS,
  [ErrorCode.SERVICE_UNAVAILABLE]:             HttpStatus.SERVICE_UNAVAILABLE,

  [ErrorCode.INVALID_CREDENTIALS]:             HttpStatus.UNAUTHORIZED,
  [ErrorCode.ACCOUNT_LOCKED]:                  HttpStatus.TOO_MANY_REQUESTS,
  [ErrorCode.ACCOUNT_NOT_ACTIVE]:              HttpStatus.FORBIDDEN,
  [ErrorCode.INVALID_2FA_CODE]:                HttpStatus.UNAUTHORIZED,
  [ErrorCode.INVALID_TOKEN]:                   HttpStatus.UNAUTHORIZED,
  [ErrorCode.TOKEN_EXPIRED]:                   HttpStatus.UNAUTHORIZED,

  [ErrorCode.KYC_NOT_VERIFIED]:                HttpStatus.FORBIDDEN,
  [ErrorCode.KYC_ALREADY_SUBMITTED]:           HttpStatus.CONFLICT,

  [ErrorCode.INSUFFICIENT_BALANCE]:            HttpStatus.UNPROCESSABLE_ENTITY,
  [ErrorCode.INSUFFICIENT_LOCKED_BALANCE]:     HttpStatus.UNPROCESSABLE_ENTITY,
  [ErrorCode.WALLET_NOT_FOUND]:                HttpStatus.NOT_FOUND,
  [ErrorCode.INVALID_CURRENCY]:                HttpStatus.BAD_REQUEST,

  [ErrorCode.INVALID_ORDER_PRICE]:             HttpStatus.BAD_REQUEST,
  [ErrorCode.INVALID_ORDER_QUANTITY]:          HttpStatus.BAD_REQUEST,
  [ErrorCode.ORDER_BELOW_MIN_VALUE]:           HttpStatus.BAD_REQUEST,
  [ErrorCode.ORDER_ABOVE_MAX_VALUE]:           HttpStatus.BAD_REQUEST,
  [ErrorCode.ORDER_NOT_FOUND]:                 HttpStatus.NOT_FOUND,
  [ErrorCode.ORDER_NOT_CANCELLABLE]:           HttpStatus.CONFLICT,
  [ErrorCode.SELF_MATCH_FORBIDDEN]:            HttpStatus.BAD_REQUEST,
  [ErrorCode.INVALID_PAIR]:                    HttpStatus.BAD_REQUEST,

  [ErrorCode.TRADE_NOT_FOUND]:                 HttpStatus.NOT_FOUND,
  [ErrorCode.INVALID_TRADE_STATE_TRANSITION]:  HttpStatus.CONFLICT,
  [ErrorCode.PAYMENT_WINDOW_EXPIRED]:          HttpStatus.CONFLICT,
  [ErrorCode.ESCROW_LOCK_FAILED]:              HttpStatus.CONFLICT,
  [ErrorCode.ESCROW_RELEASE_FAILED]:           HttpStatus.CONFLICT,

  [ErrorCode.PAYMENT_METHOD_NOT_FOUND]:        HttpStatus.NOT_FOUND,
  [ErrorCode.PAYMENT_METHOD_NOT_VERIFIED]:     HttpStatus.FORBIDDEN,

  [ErrorCode.DISPUTE_NOT_FOUND]:               HttpStatus.NOT_FOUND,
  [ErrorCode.DISPUTE_ALREADY_OPEN]:            HttpStatus.CONFLICT,
  [ErrorCode.DISPUTE_ALREADY_RESOLVED]:        HttpStatus.CONFLICT,
} as const;

export interface ApiExceptionPayload {
  errorCode: ErrorCode;
  message: string;
  details?: Readonly<Record<string, unknown>>;
  traceId?: string;
}

/**
 * BusinessException — every domain error in the platform MUST extend this.
 * Throwing raw `HttpException` is forbidden; only the global filter does that
 * for truly unexpected errors.
 */
export class BusinessException extends HttpException {
  public readonly errorCode: ErrorCode;
  public readonly details: Readonly<Record<string, unknown>> | undefined;

  constructor(
    errorCode: ErrorCode,
    message: string,
    details?: Readonly<Record<string, unknown>>,
  ) {
    const status = ERROR_CODE_HTTP_STATUS[errorCode] ?? HttpStatus.INTERNAL_SERVER_ERROR;
    const payload: ApiExceptionPayload = { errorCode, message, details };
    super(payload, status);
    this.errorCode = errorCode;
    this.details = details;
  }

  /** Convenience factory — used by the matching engine for the most common case. */
  static fromCode(code: ErrorCode, message?: string, details?: Record<string, unknown>): BusinessException {
    return new BusinessException(code, message ?? code, details);
  }
}
