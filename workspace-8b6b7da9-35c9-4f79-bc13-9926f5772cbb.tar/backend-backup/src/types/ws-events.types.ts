import type { TradeStatus } from '../database/entities';

/**
 * WebSocket event names emitted by the gateway. Clients subscribe to these.
 * Kept in a single file so the frontend can import the same constants and
 * get compile-time safety on event names.
 */
export const WsEvent = {
  // Orderbook events — broadcast to all subscribers of a pair room.
  ORDERBOOK_UPDATE:   'orderbook:update',
  ORDERBOOK_SNAPSHOT: 'orderbook:snapshot',
  TRADE_TICK:         'trade:tick',          // public, anonymized recent trade

  // User-private events — only emitted to the user's personal room.
  ORDER_PLACED:       'order:placed',
  ORDER_PARTIALLY_FILLED: 'order:partially_filled',
  ORDER_FILLED:       'order:filled',
  ORDER_CANCELLED:    'order:cancelled',

  TRADE_CREATED:      'trade:created',
  TRADE_ESCROWED:     'trade:escrowed',
  TRADE_PAYMENT_WINDOW_OPEN: 'trade:payment_window_open',
  TRADE_PAYMENT_INITIATED: 'trade:payment_initiated',
  TRADE_PAYMENT_CONFIRMED: 'trade:payment_confirmed',
  TRADE_RELEASED:     'trade:released',
  TRADE_CANCELLED:    'trade:cancelled',
  TRADE_EXPIRED:      'trade:expired',

  TRADE_MESSAGE:      'trade:message',

  DISPUTE_OPENED:     'dispute:opened',
  DISPUTE_UPDATED:    'dispute:updated',
  DISPUTE_RESOLVED:   'dispute:resolved',

  NOTIFICATION:       'notification',
} as const;

export type WsEventName = (typeof WsEvent)[keyof typeof WsEvent];

/**
 * Standard payload envelope for every WS event. traceId flows from the
 * initiating REST request so support can pivot from API → WS → DB logs.
 */
export interface WsEventEnvelope<TPayload> {
  event: WsEventName;
  traceId: string;
  timestamp: number;
  data: TPayload;
}

/**
 * Strongly-typed payloads for the most common events. Use these when emitting
 * from the matching engine / escrow service to keep the WS contract explicit.
 */
export interface OrderPlacedPayload {
  orderId: string;
  pair: string;
  side: string;
  price: string;
  quantity: string;
  status: string;
}

export interface TradeCreatedPayload {
  tradeId: string;
  tradeNumber: string;
  pair: string;
  side: string;
  price: string;
  quantity: string;
  totalValue: string;
  counterpartyId: string;          // the OTHER user (for the recipient of this event)
  paymentWindowMinutes: number;
  paymentWindowExpiresAt: number;
  status: TradeStatus;
}

export interface OrderbookUpdatePayload {
  pair: string;
  side: string;
  price: string;
  quantityDelta: string;           // signed: +added / -removed
}

export interface TradeTickPayload {
  pair: string;
  price: string;
  quantity: string;
  side: string;
  timestamp: number;
}

export type RoomName = `user:${string}` | `pair:${string}` | `trade:${string}`;
