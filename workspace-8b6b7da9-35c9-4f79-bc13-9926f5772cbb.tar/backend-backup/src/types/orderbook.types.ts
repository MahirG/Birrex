import type { OrderSide, OrderStatus } from '../database/entities';

/**
 * Canonical trading pair representation.
 *   - `USD_ETB` : US Dollar vs Ethiopian Birr
 *   - `USDT_ETB`: Tether stablecoin vs Ethiopian Birr
 *
 * Convention: BASE_QUOTE. Base is what's being bought/sold; quote is the price currency.
 * A BUY order on USD_ETB = "buy USD, pay ETB".
 */
export const TRADING_PAIRS = ['USD_ETB', 'USDT_ETB'] as const;
export type TradingPair = (typeof TRADING_PAIRS)[number];

export function isTradingPair(value: string): value is TradingPair {
  return (TRADING_PAIRS as readonly string[]).includes(value);
}

/**
 * OrderbookEntry — the in-memory / Redis representation of a resting order.
 * This is what we store in the Redis sorted set; the DB row is the source of
 * truth but the Redis snapshot is what the matching engine reads at O(log N).
 */
export interface OrderbookEntry {
  orderId: string;
  userId: string;
  pair: TradingPair;
  side: OrderSide;
  price: string;       // numeric string for arbitrary precision
  quantity: string;    // remaining quantity
  createdAt: number;   // epoch millis — used as the secondary sort key
}

/**
 * The best bid/ask snapshot returned by OrderbookService.getTopOfBook().
 */
export interface TopOfBook {
  pair: TradingPair;
  bestBid: { price: string; quantity: string } | null;
  bestAsk: { price: string; quantity: string } | null;
  spread: string | null;
}

/**
 * Full L2 orderbook snapshot (aggregated by price level).
 */
export interface OrderbookSnapshot {
  pair: TradingPair;
  bids: ReadonlyArray<{ price: string; quantity: string; orderCount: number }>;
  asks: ReadonlyArray<{ price: string; quantity: string; orderCount: number }>;
  timestamp: number;
}

/**
 * The result of a single order placement. The matching engine fills this in
 * before broadcasting events to the websocket gateway.
 */
export interface PlaceOrderResult {
  takerOrderId: string;
  status: OrderStatus;
  filledQuantity: string;
  remainingQuantity: string;
  trades: ReadonlyArray<MatchedTrade>;
}

/**
 * One matched trade between the incoming taker order and a resting maker.
 */
export interface MatchedTrade {
  tradeId: string;
  tradeNumber: string;
  makerOrderId: string;
  takerOrderId: string;
  makerUserId: string;
  takerUserId: string;
  pair: TradingPair;
  side: OrderSide;      // taker's side
  price: string;
  quantity: string;
  totalValue: string;
  paymentWindowMinutes: number;
  paymentWindowExpiresAt: number; // epoch millis
}
